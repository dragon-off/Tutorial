if(sys[0]*1==1)
	{
	var n=0;
	for(var i=1;i<=10;i++)
		{
		for(var j=0;j<group[i].lenght;j++)
			{
			if(group[i][0]==c)
				n=1;
			if(group[i][0]==c+100)
				n=1;
			}
		}
	if(n==0)
		return 0;
	if(sys[1]*1==1)
		setarray(350,0);
	else
		{
		var l=sys[2]*1;
		var a=sys[3];
		var v=sys[4]; //!!!!
		var t=0,n=0,s=0,u=1,y=1,o=0;
		for(var i=1;i<=10;i++)
			{
			q=sys[5]*1;//!!!!!!!
			if(q==1)
				q=2;
			else if(q==2)
				q=1;
			if(q>0)
				{
				var j=i;
				
				}
			}
		}
	}