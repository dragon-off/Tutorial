if (!window.console) console = {log: function() {},info: function() {},error: function() {},warn: function() {}}; //Если нет конслои то не обращаем внимание...
var LoginName = null; //Имя пользователя
var admin = 0; //InstallAdmin

var UserGroups = new Array();
var ErrCodeFour = 0;
LoginName="InstallAdmin";
var LoginCode = 0; //Логин код
var LogoutTimeout;
function getLogout(res) // Если открыта сессия, закрываем ее
{
$('#roleForm').hide(); 
$('.ltable').css("height","235px");
$('.rtable').css("height","235px");
$("#loginForm").show();

if( res.search("good")>=0)
	{
	$.ajax({
		url : "/logout.action",
		type : 'GET',	
		success : function (txt) {
			console.log("Сессия закрыта!");	
		},
		error : function ($xhr) {
			console.log($xhr,"err");
			console.log("Ошибка закрытия сессии, повтор через 5 секунд!");
			LogoutTimeout = setTimout("checkLogout()",5000); 
		}
	});	
	}
}

function open_page(ad) { //Открытие страниц
	
	window.location=ad;
};

function checkLogout()	//Смотрим есть ли открытая сессия
{

	$.ajax({
		url : "/touchscreens/ping.qsp",
		type : 'GET',	
		success : function (txt) {
			getLogout(txt);
		},
		error : function(txt) {
			console.log("err",txt);
		}
	});	
}

function resultLogin(res) //Проверка залогинивания на ошибки
{
var err_code = -1;
//console.log(res);
if(res.length>1)
	{
	var inx = res.search("Error code:");
	
	if(inx>=0)
		{
		err_code = res.substr(inx+12,2)*1;
		console.log(err_code);
		
		}
	}
return err_code;
}

var xmlHttp = new XMLHttpRequest(); //ajax

function tryLogin()	//Нажатие на Вход
{
if($("#login").val()=="retailasp")
{
	$("#loginForm").hide();
	$('#roleForm').hide();
	$("#loader").show();
	updPage();
}
else
{
alert("Не правильный пароль!");
$("#login").val("");

}
}

function createAjax(){  //функция ajax
   var obj; 
   try{
      obj=new XMLHttpRequest();
   }catch(e){alert('e: '+e.toString());
        try{
          obj=new ActiveXObject("Msxml2.XMLHTTP");		
        } catch(e1){alert('e1: '+e1.toString());
          try{
	        obj=new ActiveXObject("Microsoft.XMLHTTP");		
          } catch(e2){alert('e2: '+e2.toString());
	        obj=false;
          }   
	   }	  
   }
   if(!obj) alert("Объект xmlHttp не создан");
   else return obj;
} 

function LoginNow(DisplayName) //Добавление или изменение пользователя в qwin и залогинивание в систему
{

var loginSend = "login.action?username=InstallAdmin";

clearTimeout(LogoutTimeout);
$.ajax({
	url : loginSend,
	type : 'GET',
	success : function (txt) {
		
		var errCode = resultLogin(txt);
		if(errCode!=-1)
			{
			if(errCode==4 && ErrCodeFour<3)
				{
				console.log("errCode==4!!",DisplayName);
				ErrCodeFour++;
				setTimeout(function(){LoginNow(DisplayName);},3000);
				}
			else
				{
				ErrCodeFour=0;
				$("#loginForm").show();
				$("#loader").hide();
				$('#roleForm').hide();
				alert("Ошибка входа! (Код ошибки:"+errCode+")");
				}
			}
		else
		{
			$('.ltable').css("height","417px");
			$('.rtable').css("height","417px");
			$("#loader").hide();
			$("#loginForm").hide();
			$('#roleForm').show();
		}					
								
	},
	error : function ($xhr) {
		console.log($xhr,"err");
		alert("Ошибка входа! Не удалось войти в систему. (Код ошибки: 99)");
		$.post( "/logout.action");
		$("#loginForm").show();
		$('#roleForm').hide();
		$("#loader").hide();
	}
});			


}
function showRole(role)	//Показ нужной кнопки в зависимости от роли
{
	
switch(role)
	{
	case 0: {$('#role-button-1').show();UserGroups[UserGroups.length] = 0; break;}
	case 1: {$('#role-button-2').show();UserGroups[UserGroups.length] = 1; break;}
	case 2: {$('#role-button-3').show();UserGroups[UserGroups.length] = 2; break;}
	case 3: {$('#role-button-4').show();UserGroups[UserGroups.length] = 3; break;}
	case 4: {$('#role-button-5').show();UserGroups[UserGroups.length] = 4; break;}
	case 5: {$('#role-button-6').show();UserGroups[UserGroups.length] = 5; break;}
	}
}

function checkRoles(roles,DisplayName) //Проверка ролей
{
var mark=false;
if(roles!=null)
	{
	for(var i=0;i<roles.length;i++)
		{
		for(var j=0;j<ADGroups.length;j++)
			{
			if(roles[i]['Name'].toLowerCase()==ADGroups[j].toLowerCase())
				{
				mark=true;
				if(j==1) admin = 1;
				showRole(j);
				}
			}
		}
	}
if(mark==true)
	{
	
	LoginNow(DisplayName);
	
	var UserGroupsTxt = "";
	for(var i=0;i<UserGroups.length;i++)
		UserGroupsTxt+=ADGroups[UserGroups[i]]+",";
	UserGroupsTxt = UserGroupsTxt.substr(0, UserGroupsTxt.length-1);
	console.log(UserGroupsTxt);
	var dat = new Date();
	var liveTime = 23*3600+59*60-(dat.getSeconds()+dat.getMinutes()*60+dat.getHours()*3600);
	docCookies.setItem('suoPermissions', UserGroupsTxt, liveTime, "/");
	}
else
	{
	$("#loader").hide();
	$('#roleForm').hide();	
	$("#loginForm").show();
	alert("Ошибка! У Вас нет прав на использование СУО. Обртитесь за помощью к Вашему Системному администратору.");
	}
}

function updPage() {	//Возврат AJAX с порта 8080

var resText = "{\"Name\":\"InstallAdmin\",\"Groups\":[{\"Name\":\"Suo_Operator\"},{\"Name\":\"suo_trm\"},{\"Name\":\"suo_dir\"},{\"Name\":\"suo_root_user\"},{\"Name\":\"suo_branchadmin\"}],\"sAMAccountName\":\"InstallAdmin\",\"DisplayName\":\"InstallAdmin\"}";
var txt=eval( '('+resText+')' );
checkRoles(txt['Groups'],"InstallAdmin");	
}

