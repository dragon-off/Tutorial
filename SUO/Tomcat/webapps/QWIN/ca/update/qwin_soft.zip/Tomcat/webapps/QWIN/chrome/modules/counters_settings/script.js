var module = new module();

function module()
{
var _instance = this;
this.name = 'counters_settings';
this.title = 'Настройка ТРМ';

this.stop = function ()
	{
	console.log("stop module "+_instance.name+"...");
	//clearTimeout(_instance.timers[0]);
	};	
this.load = function() 
	{

	$.ajax({
		url : "modules/"+_instance.name+"/module.html",
		success : function (txt) {
		$('.container').html(txt);
		_instance.LoadData();
		
		
		},
		error : function ($xhr) {console.log($xhr,"err");}
	});

	}


this.LoadData = function () {
$.ajax({
	url: "modules/"+_instance.name+"/data.qsp",                 
	success: function(json) {
	clearBug();
	json = json.split("<hr>");
	json[0] = json[0].split("<br>");
	json[1] = json[1].split("<br>");
	json[0].length--;
	json[1].length--;
	json[0].sort();
	for(var i=0;i<json[0].length;i++)
		{
		json[0][i] = json[0][i].split("|");	
		if(json[0][i].length ==4)
			{
			if(json[0][i][3]*1<11) 
				{
				json[0][i][0] = json[0][i][0].substr(1, json[0][i][0].length -1);	
				json[0][i][0] = "Роль "+json[0][i][0];
				}
			}
		}
	for(var i=0;i<json[1].length;i++)
		{
		json[1][i] = json[1][i].split("|");	
		}
	
	console.log(json);
	_instance.createTable(json);

	
	},
	error : function ($xhr) {
		console.log($xhr,"err");
		bugAdd();
		
	}
	});
}

this.createElement = function (typeElement,classElement,idElement,parentElement)
	{
	var element;
	if(document.getElementById(idElement) && typeElement!="i")
		element = document.getElementById(idElement);
	else
		{
		element = document.createElement(typeElement);
		if(classElement)
			element.className = classElement;
		if(idElement)
			element.id = idElement;
		parentElement.appendChild(element);	
		}
	return element;
	}

this.save = function (id)
{
var val = $('#'+id).val();
var counter = id.split('-')[2]*1+1; 
console.log(val,counter);

console.log(val);
var params = "modules/"+_instance.name+"/save.qsp?";
	params+="trm="+val+"&counter="+counter;
console.log(params);
$.ajax({
	url: params, 
	type: "POST",		
	success: function(json) {
	alert("ТРМ на Окно №"+counter+" назначен!");
	//_instance.LoadData();
	
	},
	error: function() {
	alert("Ошибка назначения!");		
	
	}
});	

};
this.colTR = 0;

this.createTable = function (txt)
	{
	var disable = "";
	var counterList = txt[1];
	var TRMList = txt[0];
	txt = null;
	if(_instance.edit == true) disable = " disabled";
	for(var i=0;i<counterList.length;i++)
		{

		var idTR = "tr-trmsettings-"+i;
		var trmsettingsTR = _instance.createElement('tr','table-white',idTR,document.getElementById('trmsettings-tbody'));	
		var trmsettingsTD = new Array();
		trmsettingsTD[0] = _instance.createElement('td','td-trmsettings-1','td-trmsettings-'+i+'-1',trmsettingsTR);

		trmsettingsTD[0].innerHTML = counterList[i][0];
		trmsettingsTD[1] = _instance.createElement('td','td-trmsettings-2','td-trmsettings-'+i+'-2',trmsettingsTR);
		trmsettingsSelect = _instance.createElement('select','browser-default','td-trmsettings-'+i+'-select',trmsettingsTD[1]);
		trmsettingsSelect.onchange = function () {_instance.save(this.id)}; 
		
		trmsettingsOption = new Array();
		trmsettingsOption[0] = _instance.createElement('option',null,null,trmsettingsSelect);
		trmsettingsOption[0].innerHTML = '- Не назначено -';
		trmsettingsOption[0].value = '0';
		//trmsettingsOption[0].setAttribute("disabled", "disabled");
		if(counterList[i][1]*1 == 0)
			trmsettingsOption[0].setAttribute("selected", "selected");
		for(var j=0;j<TRMList.length;j++)
			{
			if(TRMList[j].length == 4)
				{

				trmsettingsOption[j+1] = _instance.createElement('option',null,null,trmsettingsSelect);
				trmsettingsOption[j+1].innerHTML = TRMList[j][0];
				trmsettingsOption[j+1].value = TRMList[j][3];

				if(counterList[i][1]*1 == TRMList[j][3]*1)
					trmsettingsOption[j+1].setAttribute("selected", "selected");
				}
			}	
		
		}

	_instance.width();
	};
this.height = function ()
	{
	var sh = $( window ).height()*1;
	sh = sh-220;
	var lentr = $('#trmsettings-tbody tr').length;
	var tbodyH = $('#trmsettings-tbody tr:first-child').height()*lentr;
	//console.log(tbodyH);
	
	var fh = 0;
	tbodyH = tbodyH +fh+35+2;
	if(tbodyH<sh)
		sh = tbodyH;
	sh = sh+"px"
	var tbsh = sh.replace("px", "")*1;
	
	tbsh = tbsh -35-fh;
	
	tbsh = tbsh+"px";
	$('.card').css("height",sh);
	$('#trmsettings-tbody').css("height",tbsh);
	};
	
this.width = function() {
	var wh = $(".card").width()*1-70;
	if(wh<100) wh=100;
	wh = wh + "px";
	//console.log(wh);
	$(".td-trmsettings-2").css("width",wh);


	for(var i = 1; i < 3; i++)
		{
		var wd = $(".td-trmsettings-"+i).width();
		$("#trmsettings-table thead th:nth-child("+i+")").width(wd);
	
		}
	_instance.height();
};	

this.load();
}