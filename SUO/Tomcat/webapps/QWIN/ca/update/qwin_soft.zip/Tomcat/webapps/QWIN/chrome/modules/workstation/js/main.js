

var counter = 0;
var branch = 0;
var username;

 var pult;
function getLogout()
{
//servicePoint.checkServicesLeft('handleClose');

$.ajax({
		url: "/rest/servicepoint/branches/"+branch+"/servicePoints/"+counter+"/users/"+username,
		type: 'DELETE',
		dataType : "json",                  
		success: function(a) {
			document.location.href = "/logout.jsp";	
		},
		error: function(){
		  console.log('/servicepoint/branches/{branchId}/servicePoints/{servicePointId}/users/{userName}');
		 
		}
		});
		 
//document.location.href = "/";
}
function winclos()
{

if(pult && pult!=null)
	{
	if(pult.closed)
		{
		document.getElementById("setlogout").style.display = "none";
		document.getElementById("getlogout").style.display = "block";
		window.onbeforeunload = null;
		getLogout();
		
		}
	else
		{
		setTimeout("winclos()",3000);
		}
	}
	else
		{
		setTimeout("winclos()",3000);
		}
}


function StartLoad()
	{
	$.ajax({
		url: "/rest/servicepoint/account",
		dataType : "json",                  
		success: function(a) {
			$('#userName').html(a['fullName']);
			username = a['userName'];
			$('#logoutLink').html('Выход');
		},
		error: function(){
		 document.location.href = '/login.jsp';
		 
		}
	});
	$.ajax({
		url: "/rest/servicepoint/systemInformation",
		dataType : "json",                  
		success: function(a) {
			$('#footer').html('ООО "Ритейл АСП" 2014 Создано QMATIC '+a['productName']+' '+a['releaseName']+' ['+a['productVersion']+'] Лицензия '+a['licenseCompanyName']);
		},
		error: function(){ console.log('/servicepoint/systemInformation'); }
	});

	$.ajax({
		url: "/rest/servicepoint/branches",
		dataType : "json",                  
		success: function(a) {
		
		if(a!=null && a.length>0)
			{
			if(a.length==1)
				{
				$('#branch').append('<option selected value="'+a[0]['id']+'">'+a[0]['name']+'</option>');
				branch_select(1);
				}
			else
				for(var i=0;i<a.length;i++)
					{
					$('#branch').append('<option value="'+a[i]['id']+'">'+a[i]['name']+'</option>');
					}
			
			}
		},
		error: function(){ console.log('/servicepoint/branches');}
	});
	
		
	}
	
function button_close()
{
pult.close();
document.getElementById("setlogout").style.display = "none";
document.getElementById("getlogout").style.display = "block";
}	
function branch_select(br)
{
branch = br;
counter = 0;

$.ajax({
	
		url: "/rest/servicepoint/branches/"+br+"/servicePoints/deviceTypes/SW_SERVICE_POINT",
		dataType : "json",                  
		success: function(a) {
		if(a!=null && a.length>0)
			{
			var mass_counter = new Array();
			var k = 0;
			for(var i=0;i<a.length;i++)
				{
				if( a[i]['name']!=null)
					{
					mass_counter[k] = new Array();
					var val = a[i]['id']+'';
					var len =val.length-11;
					if(len<=0) len=1;
					val = val.substr(0,len)*1;
					mass_counter[k][0] = val;	
					mass_counter[k][1] = a[i]['name'].replace('WebServicePoint','Окно');
					k++;
					}
				}
			/*for(var i = 0; i < mass_counter.length; ++i) // i - номер текущего шага
				{ 
					var pos = i; 
					var tmp = new Array();
					tmp[0] = mass_counter[i][0];
					tmp[1] = mass_counter[i][1];
					for(var j = i + 1; j < mass_counter.length; ++j) // цикл выбора наименьшего элемента
					{
						if (mass_counter[j][0] < tmp[0]) 
					   {
						   pos = j; 
						   tmp[0] = mass_counter[j][0];
						   tmp[1] = mass_counter[j][1]; 
					   }
					}
					mass_counter[pos][0] = mass_counter[i][0]; 
					mass_counter[pos][1] = mass_counter[i][1]; 
					mass_counter[i][0] = tmp[0]; // меняем местами наименьший с a[i]
					mass_counter[i][1] = tmp[1]; // меняем местами наименьший с a[i]
				}*/
				$('#counter option:gt(0)').hide().remove();

			for(var i=0;i<mass_counter.length;i++)
				{
				
				if(a.length==1)
					$('#counter').append('<option selected value="'+mass_counter[i][0]+'">'+mass_counter[i][1]+'</option>');
				else
					$('#counter').append('<option value="'+mass_counter[i][0]+'">'+mass_counter[i][1]+'</option>');
				}
			
			}
		},
		error: function(){ console.log('/managementinformation/branches/1/servicePoints');}
	});
}

function counter_select(val)
{
counter = val;
}
function counter_open(val)
{
if(BrowserDetect.browser =="Chrome" || (BrowserDetect.browser =="Explorer" && BrowserDetect.version<9))
	pult=window.open("pult.html?branch="+branch+'&counter='+counter, "Пульт", "menubar=no,location=no,resizable=no,scrollbars=no,status=0,toolbar=0,height=510px,width=338px");
	
else
	pult=window.open("pult.html?branch="+branch+'&counter='+counter, "Пульт", "menubar=no,location=no,resizable=no,scrollbars=no,status=0,toolbar=0,height=500px,width=338px");
setTimeout("winclos()",5000);
$('#closed_counter').css('display','none');
$('#opened_counter').css('display','inline-block');

}

function button_open()
{
if(counter==0 && branch==0)
	alert("Пожалуйста, для начала работы выберите отделение и окно!");
else
	{
	if(counter==0) alert("Пожалуйста, для начала работы выберите окно!");
	if(branch==0) alert("Пожалуйста, для начала работы выберите отделение!");
	console.log("/rest/servicepoint/branches/"+branch+"/servicePoints/"+counter+"/users/"+username);
	if(counter>0 && branch>0)
		{
		$.ajax({
		
		url: "/rest/servicepoint/branches/"+branch+"/users/"+username+"/workProfile/16", //8й профиль это норм режим, потом доработать
		type: 'PUT',
		dataType : "json",                  
		success: function(a) {
			$.ajax({
			url: "/rest/servicepoint/branches/"+branch+"/servicePoints/"+counter+"/users/"+username,
			type: 'PUT',
			dataType : "json",                  
			success: function(a) {
				counter_open(a);
			},
			error: function(){
			  console.log('/servicepoint/branches/{branchId}/servicePoints/{servicePointId}/users/{userName}');
			 
			}
			});
		},
		error: function(){
		  console.log("/rest/servicepoint/branches/"+branch+"/users/"+username+"/workProfile/2");
		 
		}
		});
		
		
		
		}
	}


}
