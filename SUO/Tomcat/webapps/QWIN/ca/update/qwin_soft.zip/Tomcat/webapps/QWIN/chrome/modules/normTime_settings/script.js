var module = new module();

function module()
{
var _instance = this;
this.name = 'normTime_settings';
this.title = 'Нормативное время обслуживания';
this.edit = false;
this.stop = function ()
	{
	console.log("stop module "+_instance.name+"...");
	//clearTimeout(_instance.timers[0]);
	};	
this.load = function() 
	{

	$.ajax({
		url : "modules/"+_instance.name+"/module.html",
		success : function (txt) {
		$('.container').html(txt);
		_instance.LoadData();
		if(CurPermissions['normTime_settings']>=2)
			{
			_instance.edit = true;
			}
		
		},
		error : function ($xhr) {console.log($xhr,"err");}
	});

	}


this.LoadData = function () {
$.ajax({
		url: "modules/"+_instance.name+"/data.qsp?save=0",                 
		success: function(json) {
		clearBug();
		json = json.split("<br>");
		json.length--;
		json.sort();
		for(var i=0;i<json.length;i++)
			{
			json[i] = json[i].split("|");	
			}

		_instance.createTable(json);
		
		},
		error : function ($xhr) {
			console.log($xhr,"err");
			bugAdd();
			
		}
	});
}

this.createElement = function (typeElement,classElement,idElement,parentElement)
	{
	var element;
	if(document.getElementById(idElement) && typeElement!="i")
		element = document.getElementById(idElement);
	else
		{
		element = document.createElement(typeElement);
		if(classElement)
			element.className = classElement;
		if(idElement)
			element.id = idElement;
		parentElement.appendChild(element);	
		}
	return element;
	}
this.timeToInt = function (time)//Время в цифру
	{
	time = time.split(":");
	var out=0;
	out = time[2]*1+time[1]*60+time[0]*3600;
	return out;
	}
this.save = function (id)
{
id = id.split('-');
var val = $('#input-norm-'+id[3]).val();
console.log(val);
val = _instance.timeToInt(val);
console.log(val);
var trm = id[3]*1;
var params = "modules/"+_instance.name+"/data.qsp?save=1";
		params+="&type="+trm+"&time="+val;
	console.log(params);
	$.ajax({
		url: params, 
		type: "POST",		
		success: function(json) {
		alert("Нормативное время сохранено!");
		//_instance.LoadData();
		
		},
		error: function() {
		alert("Ошибка сохранения!");		
		
		}
	});	

};
this.colTR = 0;

this.plusZero = function (num) //Добавлем ноль в числа меньше 10
	{
	var out = "";
	if (num * 1 < 10)
		out = "0" + num;
	else
		out = num;
	return out;
	}
this.intToTime = function (num)
	{
	var time = new Date(0, 0, 0, 0);
	var out;
	time.setSeconds(num);
	out = _instance.plusZero(time.getHours()) + ":" + _instance.plusZero(time.getMinutes()) + ":" + _instance.plusZero(time.getSeconds());
	return out;
	}

this.createTable = function (txt)
	{
	var disable = "";
	if(_instance.edit == false) disable = " disabled";
	for(var i=0;i<txt.length;i++)
		{
		if(txt[i].length > 3)
			{
			var idTR = "tr-norm-"+i;
			var normTR = _instance.createElement('tr','table-white',idTR,document.getElementById('norm-tbody'));	
			var normTD = new Array();
			normTD[0] = _instance.createElement('td','td-norm-1','td-norm-'+txt[i][3]+'-1',normTR);
			if(txt[i][3]*1<11) 
				{
				txt[i][0] = txt[i][0].substr(1, txt[i][0].length -1);	
				txt[i][0] = "Роль "+txt[i][0];
				}
			normTD[0].innerHTML = txt[i][0];
			normTD[1] = _instance.createElement('td','td-norm-2','td-norm-'+txt[i][3]+'-2',normTR);
			normTD[1].innerHTML = '<div class="input-field col s12"><input'+disable+' id="input-norm-'+txt[i][3]+'" type="time" value="'+_instance.intToTime(txt[i][4])+'" step="1" min="00:00:00" max="23:59:00" class="validate"></div>';
			normTD[2] = _instance.createElement('td','td-norm-3','td-norm-'+txt[i][3]+'-3',normTR);

			//$('#td-remove-'+i+'-5 i' ).remove();
			
			if(this.edit == true)
				{
				var normIco = _instance.createElement('a','waves-effect waves-teal btn-flat'+disable,'td-norm-btn-'+txt[i][3],normTD[2]);
				normIco.innerHTML = "Сохранить";
				normIco.onclick = function () {_instance.save(this.id)}; 
				}
			}
		}
	for(var i=txt.length;i<_instance.colTR;i++)
		{
		
		console.log("tr-remove-"+i);
		var child = document.getElementById("tr-remove-"+i);
		$( "#tr-norm-"+i+" .td-norm-3 a" ).remove();
		$( "#tr-norm-"+i+" .td-norm-2 input" ).remove();
		$( "#tr-norm-"+i+" .td-norm-2 div" ).remove();
		$( "#tr-norm-"+i+" td" ).remove();
		$( "#tr-norm-"+i ).remove();
		//child.style.display = 'none';
		}
	_instance.colTR = txt.length;
	_instance.width();
	};
this.height = function ()
	{
	var sh = $( window ).height()*1;
	sh = sh-220;
	var lentr = $('#norm-tbody tr').length;
	var tbodyH = $('#norm-tbody tr:first-child').height()*lentr;
	//console.log(tbodyH);
	
	var fh = 0;
	tbodyH = tbodyH +fh+35+2;
	if(tbodyH<sh)
		sh = tbodyH;
	sh = sh+"px"
	var tbsh = sh.replace("px", "")*1;
	
	tbsh = tbsh -35-fh;
	
	tbsh = tbsh+"px";
	$('.card').css("height",sh);
	$('#norm-tbody').css("height",tbsh);
	};
	
this.width = function() {
	var wh = $(".card").width()*1-250;
	if(wh<100) wh=100;
	wh = wh + "px";
	//console.log(wh);
	$(".td-norm-1").css("width",wh);


	for(var i = 1; i < 4; i++)
		{
		var wd = $(".td-norm-"+i).width();
		$("#norm-table thead th:nth-child("+i+")").width(wd);
	
		}
	_instance.height();
};	

this.load();
}