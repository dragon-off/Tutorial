var closingWindow;
function close() {
pultURL = "close.html";
closingWindow = window.open(pultURL, "Закрытие пульта...", "menubar=no,location=no,titlebar=no,resizable=no,scrollbars=no,status=0,toolbar=0,height=30px,width=150px");
return undefined;
}



$(function(){

});