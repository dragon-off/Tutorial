var module = new module();

function module()
{
var _instance = this;
this.name = 'indicators';
this.title = 'Показатели';
this.timers = new Array();
this.stop = function ()
	{
	console.log("stop module "+_instance.name+"...");
	clearTimeout(_instance.timers[0]);
	};	
this.load = function() 
	{

	$.ajax({
		url : "modules/"+_instance.name+"/module.html",
		success : function (txt) {
		$('.container').html(txt);
		_instance.LoadData();
		//setInterval(function(){_instance.LoadData()},60000);	

		},
		error : function ($xhr) {console.log($xhr,"err");}
	});

	}

this.plusZero = function (a){b=""; if(a*1<10) b="0"+a; else b=a; return b;}	

this.doParam = function (id,name,text,red)
	{
	
	var style = "white";
	if(red!=undefined && red!=null && red==1)
		style = "red";

	if($('#'+id).length <= 0)
		$( "#work-table" ).append( "<tr class=\"table-"+style+"\" id=\"tr-"+id+"\"><td class=\"indicators-name\">"+name+"</td><td style=\"cursor:default;\" id=\""+id+"\">"+text+"</td></tr>" );
	else
	{
		if(text.length>0)
			$('#'+id).text(text);
		$('#tr-'+id).removeClass("table-red").removeClass("table-white");
		$('#tr-'+id).addClass("table-"+style);
	}
	}



this.LoadData = function () {

clearTimeout(_instance.timers[0]);
$.ajax({
	url : "/indicatorsMonitoring?type=indicators",
	dataType: 'json',
	success : function (json) {
	console.log(json);	console.log(json.time);
	clearBug();
	$("#val-1").text(json.Klientopotok);
	var tmpParam = json.KlientopotokUFL;
	_instance.doParam('val-trm-ufl',"Клиентопоток УФЛ / на окно",_instance.byCounter(tmpParam.value,tmpParam.counters));
	tmpParam = json.KlientopotokOther;
	for(var i=0;i<tmpParam.length;i++)
		{
		_instance.doParam('val-trm-1-'+i,"Клиентопоток ТРМ "+tmpParam[i].name+"/ на окно",_instance.byCounter(tmpParam[i].value,tmpParam[i].counters));
		}
	var clients_proc = 0;
	tmpParam = json.bolee;
	if(tmpParam.five>0)
		clients_proc = (tmpParam.five*100)/tmpParam.sum;
	if(clients_proc>100)
		clients_proc = 100;
	var redVal = 0;
	if(clients_proc>json.redValue)
		redVal = 1;
	_instance.doParam('val-2',"Количество / Доля клиентов, ожидающих в очереди больше 5 мин",tmpParam.five+" ("+Math.round(clients_proc)+"%)",redVal);
	tmpParam = json.boleeDay;
	_instance.doParam('val-4',"Количество клиентов, ожидающих в очереди больше 5 мин в течение дня",_instance.byProcent(json.Klientopotok,tmpParam.five+json.bolee.five));
	tmpParam = json.dolya;
	_instance.doParam('val-3',"Количество и Доля открытых окон",_instance.byProcent(tmpParam.sum,tmpParam.opened));
	_instance.doParam('val-trm-2-ufl',"Среднее время обслуживания УФЛ",json.SrTransactionUFL);
	tmpParam = json.srTransactionOther;
	for(var i=0;i<tmpParam.length;i++)
		{
		_instance.doParam('val-trm-2-'+(i+1),"Среднее время обслуживания ТРМ "+tmpParam[i].name+"/ на окно",tmpParam[i].value);
		}
	tmpParam = json.bolee;
	_instance.doParam('dop-val-1',"Количество / Доля клиентов, ожидающих в очереди больше "+json.valueAfter+" мин",_instance.byProcent(tmpParam.sum,tmpParam.thirty));
	_instance.doParam('dop-val-2',"Максимальное время ожидания клиента в очереди",json.Maxvrozhid);
	},
	error : function ($xhr) {console.log($xhr,"err");bugAdd(); }
	}); 
_instance.timers[0] = setTimeout(function(){_instance.LoadData()},60000);	
}

this.byCounter = function (value, counters) {
	var byCounter = 0;
	if(counters>0)
		{
		byCounter = Math.round(value/counters);
		}
	return value+"/"+byCounter;
	}
this.byProcent = function (sum, part) {
	var byProcent = 0;
	if(part>0)
		{
		byProcent = Math.round((part*100)/sum);
		}
	if(byProcent>100) byProcent = 100;
	return part+" ("+byProcent+"%)";
	}


this.load();
}