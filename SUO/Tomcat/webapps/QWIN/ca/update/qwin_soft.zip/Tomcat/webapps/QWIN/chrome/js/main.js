var headerTimer;
var DisconnectMarker = false;
var prev_alert = false;

function load_module(module_name)	//Загрузка модуля
{
$('.active').removeClass('active');
$('#menu-'+module_name).addClass('active');
if(!$('#menu-'+module_name).parent().hasClass('side-nav'))
		$('#menu-'+module_name).parent().parent().show();
try {module.stop(); $('.module').remove();} catch(e) {}
loadScript("modules/"+module_name+"/script.js","module", function(){
	$('#navTitle').text(module.title);
	document.location.hash = module.name;
	});
}



function loadScript(url, classN, callback)		//Добавление скрипт-файла
{
    var head = document.getElementsByTagName('head')[0];
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = url;
	script.className = classN;
    script.onreadystatechange = callback;
    script.onload = callback;
    head.appendChild(script);
}

function closedWin() {
    confirm("close ?");
    return false; /* which will not allow to close the window */
}
var showhideBlock = false;
function hidePultDir()
{
console.log("show_hide");
if(showhideBlock == false)
	{
	showhideBlock = true;
	//$("#pult-dir").hide("drop", { direction: "right" },200)
	if(!$("#pult-dir").hasClass("pult-dir-min"))
		{

		$("#pult-dir").hide("drop", { direction: "right" },500, function(){
			$("#pult-dir i").text("expand_more");
			$("#pult-dir table").addClass("not-drag");
			$(this).addClass("pult-dir-min");
			$(this).show("drop", { direction: "up" },500, function(){showhideBlock = false;});
			});
		}
	else
		{
		$("#pult-dir").hide("drop", { direction: "up" },500, function(){
			$("#pult-dir i").text("expand_less");
			$("#pult-dir table").removeClass("not-drag");
			$(this).removeClass("pult-dir-min");
			$(this).show("drop", { direction: "right" },500, function(){showhideBlock = false;});
			});	
		
		}
	}
}
function loadDirectorPult()
{
$( "#pult-dir" ).draggable({ 
containment: "window",
cursor: "move",
cancel: ".not-drag"
});	
$("#close-pult-dir").click(function(){hidePultDir()});
$('.dropdown-button').dropdown({
      inDuration: 300,
      outDuration: 225,
      constrain_width: true, // Does not change width of dropdown to that of the activator
      hover: true, // Activate on hover
      gutter: 0, // Spacing from edge
      belowOrigin: false, // Displays dropdown below the button
      alignment: 'left' // Displays dropdown with edge aligned to the left of button
    }
  );
var module_name = "director_workstation";
loadScript("modules/"+module_name+"/script.js","dirPult", function(){
	
	});  
}

function loadHeader()	//Загрузка шапки
{
clearTimeout(headerTimer);

$.ajax({
	url : "modules/header/data.qsp",
	success : function (json) {
		if (/^svetofor+/.test(json)) {
			clearBug();
			json = json.split("-");
			json.length = json.length;
			$("#svetofor a").removeClass("red");
			$("#svetofor a").removeClass("orange");
			$("#svetofor a").removeClass("green");
			$("#svetofor a").addClass(json[1]);
			$("#svetofor a").text(json[2]);
			var UpdateTime = new Date();
			UpdateTime = "Обновлено в "+UpdateTime.toLocaleTimeString();
			$('#svetofor a').attr('title', UpdateTime);
			
				var proc = 0;
				if(json[2]*1>0)
					proc = (json[5]*100)/(json[2]*1);
				if(proc>json[6]*1 && prev_alert==false && CurPermissions['indicators']>0)
					{
					window.top.focus();
					if(module.name !="indicators")
					{
						load_module("indicators");
						$('#menu-monitoring .collapsible-header').removeClass("active");
						$('#menu-monitoring').removeClass("active");
						$('#menu-monitoring .collapsible-body').hide();
					}
					else
						console.log("you in indicators");
					console.log("alert");
					prev_alert = true;
					}
				else
					{
					//console.log(proc);
					if(proc<=json[6]*1) 
					{
						prev_alert = false;
						console.log("alert clear...");
					}
					}
				
		} 
		else {
			$("#svetofor a").toggleClass('orange', true);
			$("#svetofor a").toggleClass('green red', false);
			$("#svetofor a").text('');
		}
	},
	error : function ($xhr) {console.log($xhr,"err","loadHeader"); bugAdd();}
	}); 
headerTimer = setTimeout(function(){loadHeader();},10000);
}


function Logout()
{
	document.location.href = '/logout.action';
}

$( document ).ready(function() {
console.log("start page");


   // $(document).bind('keydown', 'esc', Logout);


 $('.navBtn').sideNav({
      menuWidth: 250, // Default is 240
      edge: 'left', // Choose the horizontal origin
      closeOnClick: true // Closes side-nav on <a> clicks, useful for Angular/Meteor
    }
  );
 $('#login').openModal({
      dismissible: false, // Modal can be dismissed by clicking outside of the modal
      opacity: .5, // Opacity of modal background
      in_duration: 300, // Transition in duration
      out_duration: 200 // Transition out duration
    });

startLogin();

$( ".menuItem" ).click(function() { load_module(this.id.split('-')[1]);});
});