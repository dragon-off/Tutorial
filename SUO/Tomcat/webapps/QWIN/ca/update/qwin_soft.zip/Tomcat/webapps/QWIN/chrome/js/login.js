var user;
var psword;
var defaultModule = 'counters';
var hashModule;

function parseGetParam(param) { 
var get_param=0;
var url = parent.location.search.substring(1).split("&");

if(url.length>0) 
{
for(var i=0; i<url.length; i++) 
	{ 
	var getVar = url[i].split("="); 
	if(param==getVar[0])
		get_param=getVar[1];
	
	} 
}
return get_param;
}



function endLogin() //Завершение Loginа
{
$('#login').closeModal();

if(hashModule != '')
	defaultModule = hashModule;

if(CurPermissions[defaultModule]>0)
	{
	load_module(defaultModule);
	setTimeout(function(){loadHeader();},500);
	//loadDirectorPult();
	/*$('#menu-monitoring .collapsible-header').click();
	$('#menu-monitoring .collapsible-header').addClass("active");
	$('#menu-monitoring').addClass("active");
	$('#menu-monitoring .collapsible-body').show();*/
	}
else
	load_module("workstation");
if(CurPermissions['director_workstation']>0)
	loadDirectorPult();

}

function getLogin() 
{
var tmp = new Date();
tmp = tmp.getHours().toString()+tmp.getMinutes().toString()+tmp.getSeconds().toString();
var psw = "";
if(psword!=null && psword!=0)
	psw = "&password="+psword;
console.log("/UserLogin?username="+user+psw+"&tmp="+tmp);
$.ajax({
	url : "/UserLogin?username="+user+psw+"&tmp="+tmp,
	dataType: 'json',
	contentType: "application/x-www-form-urlencoded;charset=windows-1251",
	success : function (json) {
		var jsn = JSON.stringify(json);
		console.log(jsn);
		docCookies.setItem("suo",jsn);
		docCookies.setItem("suo_login",json['Code']);
		if(json['Groups'])
			getPermissions(json['Groups'],json['Name'],"refresh");
		
		},
	error : function ($xhr) {console.log($xhr,"err"); alert("Ошибка входа! Невозможно войти.");}
}); 
}

function startLogin() //Начало логина
{
user = parseGetParam("user");
psword = parseGetParam("password");
hashModule = document.location.hash;
console.log(hashModule);
hashModule = hashModule.replace('#', '');
if(user.length > 0)
	window.history.replaceState(null, null, "index.html");
if(user!=0)
	{
	docCookies.setItem("suo","");
	docCookies.setItem("suo_login","");	
	$.ajax({
		url : "/logout.action",
		success : function (res) {console.log("startLogin"); checkSession()},
		error : function (res) {console.log("startLogin bad");checkSession()}
		});
	}
else
	{
	var jsn = docCookies.getItem("suo");
	json = JSON.parse(jsn);
	console.log(json);
	if(json['Groups'])
		getPermissions(json['Groups'],json['Name'],"refresh");
	else
		{
		$("#login-loading").hide();
		$("#login-error").show();
		}
	}
}

function checkSession() //Проверка сессии
{

$.ajax({
	url : "/session/ping.qsp",
	dataType: 'json',
	success : function (res) {console.log("checkSessions",res.responseText.search('good')); if(res.responseText.search('good')>=0) endLogin(); else getLogin();},
	error : function (res) {console.log("checkSessions bad",res.responseText,res.responseText.search('good'));  if(res.responseText.search('good')>=0) endLogin(); else getLogin();}
});
}
