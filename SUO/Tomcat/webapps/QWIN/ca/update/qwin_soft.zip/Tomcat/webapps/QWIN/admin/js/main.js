﻿if (!window.console)
	console = {
		log : function () {},
		info : function () {},
		error : function () {},
		warn : function () {}

	}; //Если нет конслои то не обращаем внимание...
var main_timer;
var arrayTRM;//список названий трм
var fioList;
var UFLList = new Array();
var resultArr;
var resultArrName;



function parseGetParam(param) { 
var get_param=0;
var url = parent.location.search.substring(1).split("&");

if(url.length>0) 
{
for(var i=0; i<url.length; i++) 
	{ 
	var getVar = url[i].split("="); 
	if(param==getVar[0])
		get_param=getVar[1];
	
	} 
}
return get_param;
}
function showHideCounters() {
	$(".table-gray").toggle();
}
function LoadLogins() {
var time = new Date();
var urlLoginName = "/login/users.db?time="+time.getHours()+time.getMinutes()+time.getSeconds();
if(DisconnectMarker==false)
$.ajax({
		url : urlLoginName,
		type : 'GET',
		dataType: 'text',
		success : function (a) {
			a = a.split('\n');
			var usersFIOArray = new Array();
			for(var i=0;i<a.length;i++)
			{
				var usersFIOBuf = a[i].split('#');
				if(usersFIOBuf.length > 2)
				{
					usersFIOArray[usersFIOBuf[0]] = usersFIOBuf[2];
				}
			}
			console.log(usersFIOArray);
			fioList = usersFIOArray;
			//console.log(fioList);
		},
		error : function ($xhr) {
			console.log($xhr,"err");
			//var obj = jQuery.parseJSON( $xhr.responseText);
			//console.log(obj);
			if ($xhr.status === 500) {
				var uname = parseGetParam('username');
				bugAdd();
		
			}

		}
	});
}

function FindFIO(id,name) //Фамилия и инициалы
{


var fio = fioList[id];
if(fio)
		{
		fio = fio.split(" ");
		var fioTmp = "";
		if(fio.length>=3)
			{
			fioTmp = fio[0].charAt(0).toUpperCase() + fio[0].substr(1)+" ";
			for(var i=1;i<fio.length;i++)
				{
				if(fio[i].substr(0, 1).match(/[а-я]/i))
					fioTmp = fioTmp + fio[i].substr(0, 1).toUpperCase()+".";
				else
					fioTmp = fioTmp + fio[i];
			
				}
			}
		else
			{
			for(var i=0;i<fio.length;i++)
				{
				if(i>0)
					fioTmp = fioTmp + " ";
				fioTmp = fioTmp + fio[i].charAt(0).toUpperCase() + fio[i].substr(1);
				}
			}
		fio = fioTmp;
		
				
		}
	else
		fio = name;
if(id==0)
	fio="-";
return fio;
}

function LoadMain() {
	
	clearTimeout(main_timer);
	LoadLogins();
	if(DisconnectMarker==false)
	$.ajax({
		url : "includes/counters.qsp",
		type : 'GET',
		success : function (a) {
			a = a.split("¤");
			if (a.length > 1) {
				{
					arrayTRM = a[0].split("<br>")[2].split("&&");
					arrayTRM.length--;
					for(var i=0;i<arrayTRM.length;i++)
						arrayTRM[i] = arrayTRM[i].split("|");
					responseCounters(a[1]);
					
				//console.log();
				}
			
				//responseCategorys(a[2]);
			} else
				console.log("error LoadMain", a.length);
		},
		error : function ($xhr) {
			if ($xhr.status === 500) {
				var uname = parseGetParam('username');	
				bugAdd();
			}

		}
	});
	if(DisconnectMarker==false)
	main_timer = setTimeout(function () {
			LoadMain()
		}, 10000);
}
function plusZero(num) //Добавлем ноль в числа меньше 10
{
	var out = "";
	if (num * 1 < 10)
		out = "0" + num;
	else
		out = num;
	return out;
}

var counters_len = 0; //Количество строк в таблице с окнами
function timeToInt(time)//Время в цифру
{
time = time.split(":");
var out=0;
out = time[2]*1+time[1]*60+time[0]*3600;
return out;
}
function intToTime(txt) //Цифра во время
{
var time = new Date(0, 0, 0, 0);
var out;
time.setSeconds(txt);
out = plusZero(time.getHours()) + ":" + plusZero(time.getMinutes()) + ":" + plusZero(time.getSeconds());
return out;
}
function loadResults()	//Результативные показатели
{

var resultArr = new Array();
var resultArrName = new Array();
for(var i=1;i<counters_len;i++)
	{
	var curTRMName = $("#td-"+i+"-2").text();
	var mark = false;
	var counterTRM="";
	if(curTRMName!="-")
		{
		if(UFLList[i]==1)
			curTRMName = "УФЛ";
		for(var j=0;j<resultArrName.length;j++)
			{
			if(curTRMName==resultArrName[j])
				{
				mark=true;
				counterTRM = j;
				}
			}
		if(mark==false)
			{
			resultArrName[resultArrName.length] = curTRMName;
			resultArr[curTRMName] = new Array();	
			resultArr[curTRMName]['counters'] = 0;
			resultArr[curTRMName]['active_counters'] = 0;	
			resultArr[curTRMName]['pereriv'] = 0;	
			resultArr[curTRMName]['prostoi'] = 0;	
			resultArr[curTRMName]['srvrobsl'] = 0;	
			resultArr[curTRMName]['obsl'] = 0;			
			}
		resultArr[curTRMName]['counters']++;
		if(!$("#workstation-"+i).hasClass("table-gray"))
			resultArr[curTRMName]['active_counters']++;
		resultArr[curTRMName]['prostoi']+=timeToInt($("#td-"+i+"-5").text());
		resultArr[curTRMName]['obsl']+=$("#td-"+i+"-7").text()*1;
		resultArr[curTRMName]['srvrobsl']+=timeToInt($("#td-"+i+"-8").text());
		resultArr[curTRMName]['pereriv']+=timeToInt($("#td-"+i+"-9").text());
		}
	}
//console.log(resultArrName,resultArr);
for(var i=0;i<resultArrName.length;i++)
	{
	var curTRMarr = resultArr[resultArrName[i]];
	var prostoy = 0;
	if(curTRMarr['counters']>0)
		prostoy = Math.round(curTRMarr['prostoi']/curTRMarr['counters']);
	prostoy = intToTime(prostoy);
	var srvr = 0;
	if(curTRMarr['counters']>0)
		srvr = Math.round(curTRMarr['srvrobsl']/curTRMarr['counters']);
	srvr = intToTime(srvr);
	var pereriv = 0;
	if(curTRMarr['counters']>0)
		pereriv = Math.round(curTRMarr['pereriv']/curTRMarr['counters']);
	pereriv = intToTime(pereriv);
	
	if($('#res-'+i).length <= 0)
		$(".info-table tfoot").append("<tr id='res-"+i+"'><td style=\"border-left:0px;\"></td><td id='res-"+i+"-name'>"+resultArrName[i]+"</td><td id='res-"+i+"-counters'>Окон: <b>"+curTRMarr['counters']+"</b></td><td id='res-"+i+"-active_counters'>Активных окон: <b>"+curTRMarr['active_counters']+"</b></td><td id='res-"+i+"-prostoi'>"+prostoy+"</td><td></td><td id='res-"+i+"-obsl'>"+curTRMarr['obsl']+"</td>		<td id='res-"+i+"-srvrobsl'>"+srvr+"</td><td id='res-"+i+"-pereriv'>"+pereriv+"</td></tr>");
	else
		{
		$("#res-"+i+"-name").text(resultArrName[i]);
		$("#res-"+i+"-counters").html("Окон: <b>"+curTRMarr['counters']+"</b>");
		$("#res-"+i+"-active_counters").html("Активных окон: <b>"+curTRMarr['active_counters']+"</b>");
		$("#res-"+i+"-prostoi").text(prostoy);
		$("#res-"+i+"-obsl").text(curTRMarr['obsl']);
		$("#res-"+i+"-srvrobsl").text(srvr);
		$("#res-"+i+"-pereriv").text(pereriv);
		}
	}
}
var firstResult = true; //Первый раз загружаются данные?
function responseCounters(txt) //Обработка окон
{
	resp = txt;
	var line_split;
	var el_g;
	var system_type = '';
	line_split = resp.split('<br>');
	var tr = new Array();
	var schet = 1;
	counters_len = line_split.length;
	for (var r = 1; r < line_split.length; r++) {
	
		obj_split = line_split[r - 1].split('&&');
		if(obj_split[2]!="-111") // надо "-" чтобы скрывать окна без ТРМ, но суммируется тогда не правильно. доработать
		{
		if (document.getElementById('workstation-' + r)) {
			tr[r - 1] = document.getElementById('workstation-' + r);
			tr[r - 1].className = 'table-' + obj_split[0];
			mouse_color_table(tr[r - 1], 2);
		} else {
			tr[r - 1] = document.createElement('tr');
			tr[r - 1].className = 'table-' + obj_split[0];
		}
		tr[r - 1].id = 'workstation-' + r;
		document.getElementById('work-table').appendChild(tr[r - 1]);

		if (obj_split.length > 1) {
			var td1 = new Array();
			tr[r - 1].onmouseover = new Function("mouse_color_table(this,1)");
			tr[r - 1].onmouseout = new Function("mouse_color_table(this,2)");
			//tr[r - 1].onclick = new Function("close_workstation(this)");
			
			for (var h = 1; h <= obj_split.length - 1; h++) {

				if (document.getElementById('td-' + r+'-'+h))
					td1[h] = document.getElementById('td-' + r+'-'+h);
				else
					td1[h] = document.createElement('td');
				td1[h].id = 'td-' + r+'-'+h;
				td1[h].className = 'td-' + h;
				td1[h].style.height = '26px';
				schet++;
				switch (h) {
					case 1: {
							td1[h].innerHTML = obj_split[h].split(" ")[1];
							break;
						}
					case 2: {
							var trmName = obj_split[h].split("|");
							if(trmName.length > 1)
							{
								td1[h].innerHTML = trmName[1];
								UFLList[r] = trmName[2]*1;
							}
							else
								td1[h].innerHTML = trmName[0];
							td1[h].title = trmName[0];
							break;
						}
					case 3: {
							var title_man;
							if (document.getElementById("title_man-" + r))
								title_man = document.getElementById("title_man-" + r);
							else
								title_man = document.createElement('p');
							title_man.id = "title_man-" + r;
							obj_split[h] = obj_split[h].split("|");
							title_man.innerHTML = FindFIO(obj_split[h][0]*1,obj_split[h][1]);
							title_man.style.height = "18px";
							title_man.style.whiteSpace = "nowrap";
							title_man.style.margin = "0px";
							title_man.style.overflow = "hidden";
							title_man.style.textOverflow = "ellipsis";
							td1[h].setAttribute('vlign', 'center');
							td1[h].appendChild(title_man);

							title_man.title = obj_split[h][1];
							break;
						}
					case 4: {
							var title_operation;
							if (document.getElementById("title_operation-" + r))
								title_operation = document.getElementById("title_operation-" + r);
							else
								title_operation = document.createElement('p');
							title_operation.id = "title_operation-" + r;
							var operation = obj_split[h].split("|");
							//console.log(operation);
							var opTitle;
							if(operation[0]=="TRM")
								opTitle = "(перевод) "+arrayTRM[operation[1]*1-1][0];
							else
								opTitle = operation[1];
							title_operation.innerHTML = opTitle;
							title_operation.style.height = "18px";
							title_operation.style.whiteSpace = "nowrap";
							title_operation.style.overflow = "hidden";
							title_operation.style.margin = "0px";
							title_operation.style.textOverflow = "ellipsis";
							td1[h].setAttribute('vlign', 'center');
							td1[h].appendChild(title_operation);
							
							title_operation.title = operation[2]+": "+opTitle;
							break;
						}
					case 5: {
							var times = obj_split[h].split("|");
							//console.log(r,intToTime(times[0]*2),intToTime(times[1]*2),intToTime(times[2]*2),intToTime(times[3]*2),intToTime(times[4]*2),intToTime(times[5]*2));
							var vrRab = times[0]*1;//время работы станции (открыта)
							if(times[2]*1>times[4]*1)
								vrRab = vrRab + (times[3]*1-times[2]*1);
							var vrProstoy = vrRab - (times[1]*1+times[5]*1);	
							if(vrProstoy<0) vrProstoy = 0;
							td1[h].innerHTML = intToTime(vrProstoy*2);
							break;
						}
					case 6: {				
							td1[h].innerHTML = intToTime(obj_split[h]);
							break;
						}
					case 7: {
							td1[h].innerHTML = obj_split[h];
							break;
						}
					case 8: {
							if (obj_split[7] * 1 > 0)
								obj_split[h] = Math.round(obj_split[h] / obj_split[7]);
							else
								obj_split[h] = 0;
							td1[h].innerHTML = intToTime(obj_split[h]);			
							break;
						}
					case 9: {
							var perer = obj_split[h].split("|");
							
							var pereriv = 0;
							//console.log(r,intToTime(perer[0]*2),intToTime(perer[1]*2),intToTime(perer[2]*2),intToTime(perer[3]*2),intToTime(perer[4]*2),intToTime(perer[5]*2));
							var VremNachRab 	= perer[0]*2;
							var VremTek		 	= perer[1]*2;
							var VremOkonch 		= perer[2]*2;
							var VremRabOkna 	= perer[3]*2;
							var VremVhoda 		= perer[4]*2;
							var VremVihoda 		= perer[5]*2;
							var VremPerVhoda 	= perer[6]*2;
							/*if(r==1)
								console.log('vrrab '+VremRabOkna);*/
							var dayTo = VremTek;
							if(dayTo<VremNachRab)
								dayTo = VremNachRab;
							if(dayTo>VremOkonch)
								dayTo = VremOkonch;
							//console.log(dayTo);
							if(VremVhoda<VremNachRab)
								VremVhoda = VremNachRab;
							if(VremVhoda>VremOkonch)
								VremVhoda = VremOkonch;
							
						
							//console.log("dayTime",dayTime);
							if(VremVhoda>VremVihoda)
								VremVihoda=VremVhoda;
							pereriv = (VremVihoda-VremPerVhoda)-VremRabOkna;
							//console.log(r,pereriv,intToTime(dayTime*2),intToTime(perer[3]*2));
							/*if(VremRabOkna==0 && obj_split[0]!="gray")
								pereriv = 0;*/
							if(VremRabOkna==0)
								pereriv = 0;
							
							if(pereriv<0)
								pereriv = 0;
						
							td1[h].innerHTML = intToTime(pereriv);
							break;
						}
					/*case 10: {
							if(obj_split[0]!="gray")
								{
								//console.log("r="+r);
								td1[h].innerHTML = "<img src='img/close.png' id='close-button-"+r+"' onClick='close_workstation("+r+")' style='cursor:pointer;' title='Закрыть окно' alt='Закрыть окно'/>";
								}
							else
								td1[h].innerHTML = "&nbsp;";
							break;
						}*/
					default: {
							console.log("err");
							break;
						}
					}
				

				document.getElementById('workstation-' + r).appendChild(td1[h]);
			}
		}
		}
	}
var director = parseGetParam("director");
//console.log(director);
if(director>0)
	loadResults();
if(firstResult==true)
	{
	$(".table-gray").hide();
	firstResult = false;
	}

}


function mouse_color_table(el, state) {
	if (state == 1) {
		if (el.className == "table-green")
			el.style.backgroundPosition = "0px -28px";
		if (el.className == "table-red")
			el.style.backgroundPosition = "0px -84px";
		if (el.className == "table-yellow")
			el.style.backgroundPosition = "0px -280px";
		if (el.className == "table-gray")
			el.style.backgroundPosition = "0px -168px";
		if (el.className == "table-white") {
			el.style.backgroundPosition = "0px -224px";
			el.style.color = "#4272c0";
		} else
			el.style.color = "";
	} else {
		if (el.className == "table-green")
			el.style.backgroundPosition = "0px 0px";
		if (el.className == "table-red")
			el.style.backgroundPosition = "0px -56px";
		if (el.className == "table-yellow")
			el.style.backgroundPosition = "0px -252px";
		if (el.className == "table-gray")
			el.style.backgroundPosition = "0px -168px";
		if (el.className == "table-white") {
			el.style.backgroundPosition = "0px -196px";
			el.style.color = "black";
		} else {
			el.style.color = "";
		}
	}
}

function close_workstation(el) {
		var counterId = el;
		el = document.getElementById("workstation-"+el);
		if (confirm("Вы действительно хотите закрыть Окно " + counterId + "?")) {
			el.className = "table-gray";
			$("#close-button-"+counterId).css('display','none');
			el.style.backgroundPosition = "0px -112px";
			el.style.color = "#4f4f4f";
			$.ajax({
				url : "/admin/includes/close.qsp?counter=" + counterId,
				type : 'GET',
				success : function (a) {
					console.log("close good");

				},
				error : function () {
					console.log("close bad");

				}
			});
		}
	
}

function tooltip(r, a) {
	el = document.getElementById("to2r" + r);
	if (a == 1)
		el.style.display = "block";
	else
		el.style.display = "none";
}

function tooltip_2(r, a) {
	el = document.getElementById("to4r" + r);
	if (a == 1)
		el.style.display = "block";
	else
		el.style.display = "none";
}

