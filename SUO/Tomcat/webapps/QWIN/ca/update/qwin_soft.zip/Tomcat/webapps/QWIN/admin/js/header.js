﻿if (!window.console) console = {log: function() {},info: function() {},error: function() {},warn: function() {}}; // Если нет консоли игнорируем console
var prev_alert = false;
var director = 0;

function parseGetParam(param) { 
var get_param=0;
var url = parent.location.search.substring(1).split("&");

if(url.length>0) 
{
for(var i=0; i<url.length; i++) 
	{ 
	var getVar = url[i].split("="); 
	if(param==getVar[0])
		get_param=getVar[1];
	
	} 
}

return get_param;
}
		
function LoadData() {
	
if(DisconnectMarker==false)
	{
	$.ajax({
		url : "includes/svetofor.qsp",
		success : function (json) {
			if (/^svetofor+/.test(json)) {
				json = json.split("-");
				json.length = json.length;
				$("#svetofor").removeClass("svetofor-red");
				$("#svetofor").removeClass("svetofor-yellow");
				$("#svetofor").removeClass("svetofor-green");
				$("#svetofor").addClass("svetofor-" + json[1]);
				$("#svetofor").text(json[2]);
				var UpdateTime = new Date();
				UpdateTime = "Обновлено в "+UpdateTime.toLocaleTimeString();
				$('#svetofor').attr('title', UpdateTime);
				/*for(var i=1;i<=json.length;i++){
				$("#runText-"+i).val(json[i-1]);
				}*/
				
					var proc = 0;
					if(json[2]*1>0)
						proc = (json[5]*100)/(json[2]*1);
					if(proc>json[6]*1 && prev_alert==false)
						{
						window.top.focus();
						$("#mb_5").click();
						console.log("alert");
						prev_alert = true;
						}
					else
						{
						//console.log(proc);
						if(proc<=json[6]*1) 
							prev_alert = false;
						}
					
			} 
			else {
				$("#svetofor").toggleClass('svetofor-yellow', true);
				$("#svetofor").toggleClass('svetofor-green svetofor-red', false);
				$("#svetofor").text('');
			}
		},
		error : function ($xhr) {
			console.log($xhr,"err");
			bugAddHead();
		}
	});
	}
}

function checkAdminPrinter() {
	$.ajax({
	url : "/settings/includes/AdminTouchValue.txt",
	type : 'GET',
	success : function (txt) {checkAdminTouchRes(txt);},
	error : function(txt) {	checkAdminTouchRes('admintouch:true');}
	});	

}

function checkAdminTouchRes(txt) {
	txt = txt.split(":");
	if(txt.length==2 && txt[0]=="admintouch" && txt[1] == 'false')
		$("#mb_1").remove();
	else
		$("#mb_1").hasClass('show')?$("#mb_1").show():$("#mb_1").hide();
}

function mbClick(el,link)
{
if(!$("#"+el).hasClass("menuactive"))
	{
	for(var i=1;i<8;i++)
		$("#mb_"+i).removeClass("menuactive");
	$("#"+el).addClass("menuactive");
	}
top.mainFrame.location.href = link;
}
  $(function(){

director = parseGetParam("director")*1;
var uname = parseGetParam("username");
var localPermission = false;
console.log("director="+director);
switch(director)
{
case 0: {localPermission = checkPermissions(ADGroups[2]); break;}
case 1: {localPermission = checkPermissions(ADGroups[4]); break;}
case 2: {localPermission = checkPermissions(ADGroups[3]); break;}
case 3: {localPermission = checkPermissions(ADGroups[1]); break;}
default:{localPermission = checkPermissions(ADGroups[2]); break;}
}
if(localPermission == false)
	{
	alert("У Вас нет прав на просмотр этой страницы!");
	top.location.href = "/logout.action";
	}
else
	{
		$("#mb_6").show();
	if(director>0)
		{
		$("#mb_1").hide();
		$("#mb_4").show();
		$("#mb_7").show();
		$("#mb_4").click(function() {top.location.href='/settings/index.jsp?director='+director+'&username='+uname;});
		$("#mb_7").click(function() {mbClick(this.id,"users.html");});
		}
	else
		{
		checkAdminPrinter();
		$("#mb_1").addClass('show');
		$("#mb_4").hide();
		$("#mb_1").click(function() {mbClick(this.id,"touchscreen.html");});
		}
	$("#mb_5").click(function() {mbClick(this.id,"director.html");});
	$("#mb_6").click(function() {mbClick(this.id,"stat.html"); });
	$("#mb_2").click(function() {mbClick(this.id,"category.html");});
	$("#mb_3").click(function() {mbClick(this.id,"counters.html");});
	
	LoadData();
	setInterval(function(){LoadData()},10000);	
	}
});


