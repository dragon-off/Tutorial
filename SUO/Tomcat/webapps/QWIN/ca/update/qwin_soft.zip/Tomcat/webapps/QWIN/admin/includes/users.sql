SELECT v.LoginId, v.RegDate, 
(SELECT Name FROM STAFINFO WHERE StafInfoNo = v.LoginId) AS LoginName, 
(SELECT TOP 1 RegTime FROM EVENT WHERE RegDate = v.RegDate AND LoginId = v.LoginId AND EventType = 4 ORDER BY RegTime) AS OpenWS, 
(SELECT TOP 1 IIF( (SELECT TOP 1 EventType FROM EVENT e1 WHERE RegDate = v.RegDate AND LoginId = v.LoginId AND EventType IN (4, 5) ORDER BY RegTime desc) = 5, RegTime, NULL) 
FROM EVENT e WHERE RegDate = v.RegDate AND LoginId = v.LoginId AND EventType = 5 ORDER BY RegTime desc) AS CloseWS,

(SELECT TOP 1 DATEDIFF('s', e.RegTime, 
IIF( (SELECT TOP 1 EventType FROM EVENT e1 WHERE e1.RegDate = e.RegDate AND e1.LoginId = e.LoginId AND e1.EventType IN (4, 5) ORDER BY RegTime desc) <> 5, 
CDate('01.01.1980') + Time() , 
(SELECT TOP 1 RegTime FROM EVENT WHERE RegDate = e.RegDate AND LoginId = e.LoginId AND EventType = 5 ORDER BY RegTime desc )
)
) 
FROM EVENT AS e
WHERE e.RegDate = v.RegDate AND e.LoginId = v.LoginId AND e.EventType = 4 ORDER BY e.RegTime) AS CloseOpen,

COUNT(*) AS obsl, 
SUM(DATEDIFF('s', v.NextTime, v.EndTime)) AS vrobsl, 
AVG(DATEDIFF('s', v.NextTime, v.EndTime)) AS Avgvrobsl, 
MAX(DATEDIFF('s', v.NextTime, v.EndTime)) AS Maxvrobsl
FROM MATTER AS m INNER JOIN VISIT AS v ON (m.BranchNo = v.BranchNo) AND (v.RegDate = m.RegDate) AND (v.TrackNo = m.TrackNo) AND (v.EndTime = m.EndTime) AND (v.NextTime = m.StartTime)
WHERE m.Code>50 AND v.RegDate = Date() AND (datediff('s', v.NextTime, v.EndTime) > 120 OR m.Code = 55 AND datediff('s', v.NextTime, v.EndTime) > 60)
GROUP BY v.LoginId, v.RegDate;
