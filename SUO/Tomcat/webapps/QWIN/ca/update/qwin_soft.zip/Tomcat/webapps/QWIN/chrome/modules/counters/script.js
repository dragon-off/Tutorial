var module = new module();



var firstResult = true; //Первый раз загружаются данные?

function module()
{
	var _instance = this;
	this.name = 'counters';
	this.title = 'Информация по окнам';
	this.timers = new Array();
	this.arrayTRM;//список названий трм
	this.fioList;
	this.counters_len = 0; //Количество строк в таблице с окнами
	this.hide = true;
	this.UFLList = new Array();
	this.resultArr;
	this.permission = 1;
	this.resultArrName;
	this.stop = function ()
	{
	console.log("stop module "+_instance.name+"...");
	clearTimeout(_instance.timers[0]);
	};
	
	this.loadResults = function ()	//Результативные показатели
		{

		var resultArr = new Array();
		var resultArrName = new Array();
		for(var i=1;i<_instance.counters_len;i++)
			{
			var curTRMName = $("#td-"+i+"-2").text();
			var mark = false;
			var counterTRM="";
			if(curTRMName!="-")
				{
				if(_instance.UFLList[i]==1)
					curTRMName = "УФЛ";
				for(var j=0;j<resultArrName.length;j++)
					{
					if(curTRMName==resultArrName[j])
						{
						mark=true;
						counterTRM = j;
						}
					}
				if(mark==false)
					{
					resultArrName[resultArrName.length] = curTRMName;
					resultArr[curTRMName] = new Array();	
					resultArr[curTRMName]['counters'] = 0;
					resultArr[curTRMName]['active_counters'] = 0;	
					resultArr[curTRMName]['pereriv'] = 0;	
					resultArr[curTRMName]['prostoi'] = 0;	
					resultArr[curTRMName]['srvrobsl'] = 0;	
					resultArr[curTRMName]['obsl'] = 0;			
					}
				resultArr[curTRMName]['counters']++;
				if(!$("#workstation-"+i).hasClass("table-gray"))
					resultArr[curTRMName]['active_counters']++;
				resultArr[curTRMName]['prostoi']+=_instance.timeToInt($("#td-"+i+"-5").text());
				resultArr[curTRMName]['obsl']+=$("#td-"+i+"-7").text()*1;
				resultArr[curTRMName]['srvrobsl']+=_instance.timeToInt($("#td-"+i+"-8").text());
				resultArr[curTRMName]['pereriv']+=_instance.timeToInt($("#td-"+i+"-9").text());
				}
			}
		//console.log(resultArrName,resultArr);
		for(var i=0;i<resultArrName.length;i++)
			{
			var curTRMarr = resultArr[resultArrName[i]];
			var prostoy = 0;
			if(curTRMarr['counters']>0)
				prostoy = Math.round(curTRMarr['prostoi']/curTRMarr['counters']);
			prostoy = _instance.intToTime(prostoy);
			var srvr = 0;
			if(curTRMarr['counters']>0)
				srvr = Math.round(curTRMarr['srvrobsl']/curTRMarr['counters']);
			srvr = _instance.intToTime(srvr);
			var pereriv = 0;
			if(curTRMarr['counters']>0)
				pereriv = Math.round(curTRMarr['pereriv']/curTRMarr['counters']);
			pereriv = _instance.intToTime(pereriv);
			
			if($('#res-'+i).length <= 0)
				$("#counters-table tfoot").append("<tr id='res-"+i+"'><th style=\"border-left:0px;\"></th><th id='res-"+i+"-name'>"+resultArrName[i]+"</th><th id='res-"+i+"-counters'>Окон: <b>"+curTRMarr['counters']+"</b></th><th id='res-"+i+"-active_counters'>Активных окон: <b>"+curTRMarr['active_counters']+"</b></th><th id='res-"+i+"-prostoi'>"+prostoy+"</th><th></th><th id='res-"+i+"-obsl'>"+curTRMarr['obsl']+"</th>		<th id='res-"+i+"-srvrobsl'>"+srvr+"</th><th id='res-"+i+"-pereriv'>"+pereriv+"</th></tr>");
			else
				{
				$("#res-"+i+"-name").text(resultArrName[i]);
				$("#res-"+i+"-counters").html("Окон: <b>"+curTRMarr['counters']+"</b>");
				$("#res-"+i+"-active_counters").html("Активных окон: <b>"+curTRMarr['active_counters']+"</b>");
				$("#res-"+i+"-prostoi").text(prostoy);
				$("#res-"+i+"-obsl").text(curTRMarr['obsl']);
				$("#res-"+i+"-srvrobsl").text(srvr);
				$("#res-"+i+"-pereriv").text(pereriv);
				}
			}
		}
	
	this.height = function ()
	{
	var sh = $( window ).height()*1;
	sh = sh-220;
	var lentr = $('#counters-tbody tr').length;
	var tbodyH = $('#counters-tbody tr:first-child').height()*lentr;
	//console.log(tbodyH);
	
	var fh = $( 'tfoot' ).height()*1;
	tbodyH = tbodyH +fh+35+2;
	if(tbodyH<sh)
		sh = tbodyH;
	sh = sh+"px"
	var tbsh = sh.replace("px", "")*1;
	
	tbsh = tbsh -35-fh;
	
	tbsh = tbsh+"px";
	$('.card').css("height",sh);
	$('#counters-tbody').css("height",tbsh);
	}
	this.load = function ()
	{
	clearTimeout(_instance.timers[0]);
	_instance.permission = CurPermissions['counters'];
	
	if($('#counters-table').length<=0)
		{
		$.ajax({
			url : "modules/"+_instance.name+"/module.html",
			success : function (txt) {
			$('.container').html(txt);
			_instance.LoadLogins();
			
			
			$("#showCounters").click(function(){
				if(module.hide==true)
					{
					$(".table-gray").show();
					module.hide = false;
					}
				else
					{
					$(".table-gray").hide();
					module.hide = true;
					}
				});
			
			
			},
			error : function ($xhr) {console.log($xhr,"err");bugAdd();}
		});
		}
	else
		_instance.LoadLogins();
	
	_instance.timers[0] = setTimeout(function(){_instance.load()},10000);
	};
	this.LoadCounters = function() {
	$.ajax({
		url : "modules/"+_instance.name+"/data.qsp",
		success : function (a) {
			clearBug();
			a = a.split("¤");
			if (a.length > 1) {
				{
					_instance.arrayTRM = a[0].split("<br>")[2].split("&&");
					_instance.arrayTRM.length--;
					for(var i=0;i<_instance.arrayTRM.length;i++)
						_instance.arrayTRM[i] = _instance.arrayTRM[i].split("|");
					_instance.responseTable(a[1]);
					
				//console.log();
				}
			
				//responseCategorys(a[2]);
			} else
				{
				console.log("error LoadMain", a.length);
				bugAdd();
				}
		},
		error : function ($xhr) {console.log($xhr,"err");bugAdd();}
	});
	};
	this.LoadLogins = function () {
	var time = new Date();
	var urlLoginName = "/login/users.db?time="+time.getHours()+time.getMinutes()+time.getSeconds();
	if(DisconnectMarker==false)
	$.ajax({
			url : urlLoginName,
			type : 'GET',
			dataType: 'text',
			success : function (a) {
				a = a.split('\n');
				var usersFIOArray = new Array();
				for(var i=0;i<a.length;i++)
				{
					var usersFIOBuf = a[i].split('#');
					if(usersFIOBuf.length > 2)
					{
						usersFIOArray[usersFIOBuf[0]] = usersFIOBuf[2];
					}
				}
				console.log(usersFIOArray);
				_instance.fioList = usersFIOArray;
				_instance.LoadCounters();
			},
			error : function ($xhr) {
				console.log($xhr,"err");
				//var obj = jQuery.parseJSON( $xhr.responseText);
				//console.log(obj);
				if ($xhr.status === 500) {
					
					bugAdd();
			
				}

			}
		});
	}
	this.FindFIO = function (id,name) //Фамилия и инициалы
	{


	var fio = _instance.fioList[id];
	if(fio)
		{
		fio = fio.split(" ");
		var fioTmp = "";
		if(fio.length>=3)
			{
			fioTmp = fio[0].charAt(0).toUpperCase() + fio[0].substr(1)+" ";
			for(var i=1;i<fio.length;i++)
				{
				if(fio[i].substr(0, 1).match(/[а-я]/i))
					fioTmp = fioTmp + fio[i].substr(0, 1).toUpperCase()+".";
				else
					fioTmp = fioTmp + fio[i];
			
				}
			}
		else
			{
			for(var i=0;i<fio.length;i++)
				{
				if(i>0)
					fioTmp = fioTmp + " ";
				fioTmp = fioTmp + fio[i].charAt(0).toUpperCase() + fio[i].substr(1);
				}
			}
		fio = fioTmp;
		
				
		}
	else
		fio = name;
	if(id==0)
		fio="-";
	return fio;
	}
	this.plusZero = function (num) //Добавлем ноль в числа меньше 10
{
	var out = "";
	if (num * 1 < 10)
		out = "0" + num;
	else
		out = num;
	return out;
}

	
	this.timeToInt = function (time)//Время в цифру
	{
	time = time.split(":");
	var out=0;
	out = time[2]*1+time[1]*60+time[0]*3600;
	return out;
	}
	this.intToTime = function (txt) //Цифра во время
	{
	var time = new Date(0, 0, 0, 0);
	var out;
	time.setSeconds(txt);
	out = _instance.plusZero(time.getHours()) + ":" + _instance.plusZero(time.getMinutes()) + ":" + _instance.plusZero(time.getSeconds());
	return out;
	}
	
	this.close = function (counter) //Закрытие окна
	{
	
	var ulrClose = "/chrome/modules/workstation/includes/close.qsp?workstation="+counter;
	console.log(ulrClose);
	$.ajax({
			url : ulrClose,
			type : 'GET',
			success : function (a) {
				alert("Окно закрыто!");
			},
			error : function ($xhr) {
				console.log($xhr,"err");
				alert("Ошибка закрытия!");

			}
		});	
	
	}
	this.responseTable = function (txt) //Обработка окон
	{
	resp = txt;
	var line_split;
	var el_g;
	var system_type = '';
	line_split = resp.split('<br>');
	var tr = new Array();
	var schet = 1;
	_instance.counters_len = line_split.length;
	
	for (var r = 1; r < line_split.length; r++) {
	
		obj_split = line_split[r - 1].split('&&');
		
		if(obj_split[2]!="-111") // надо "-" чтобы скрывать окна без ТРМ, но суммируется тогда не правильно. доработать
		{
		if (document.getElementById('workstation-' + r)) {
			tr[r - 1] = document.getElementById('workstation-' + r);
			if(obj_split[0]!="gray")
				{
				tr[r - 1].style.display = "table-row";
				}
			else
				{
				if(_instance.hide==true) 
					tr[r - 1].style.display = "none";
				}
			tr[r - 1].className = 'table-' + obj_split[0];

		} else {
			tr[r - 1] = document.createElement('tr');
			tr[r - 1].className = 'table-' + obj_split[0];
		}
		tr[r - 1].id = 'workstation-' + r;
		if(document.getElementById('counters-tbody'))
			document.getElementById('counters-tbody').appendChild(tr[r - 1]);
		else
			return 0;
		if (obj_split.length > 1) {
			var td1 = new Array();
			if(obj_split[0]!="gray")
				{
				if(_instance.permission==2)
					{
					tr[r - 1].style.cursor = "pointer";
					tr[r - 1].setAttribute('data',obj_split[10]);
					tr[r - 1].onclick = function(){
					var idOkno = $(this).attr('id');
					idOkno = '#' + idOkno + ' .td-1';
					if(confirm("Закртыть Окно "+$(idOkno).text()+"?"))
						_instance.close($(this).attr('data')*1);
					};
					}
				}
			else
				{
				if(_instance.permission==2)
					{
					tr[r - 1].style.cursor = "default";
					tr[r - 1].setAttribute('data',obj_split[10]);
					tr[r - 1].onclick = undefined;
					}
				}
			
			for (var h = 1; h <= obj_split.length - 2; h++) {

				if (document.getElementById('td-' + r+'-'+h))
					td1[h] = document.getElementById('td-' + r+'-'+h);
				else
					td1[h] = document.createElement('td');
				td1[h].id = 'td-' + r+'-'+h;
				td1[h].className = 'td-' + h;
				td1[h].style.height = '26px';
				schet++;
				switch (h) {
					case 1: {
							td1[h].innerHTML = obj_split[h].split(" ")[1];
							break;
						}
					case 2: {
							var trmName = obj_split[h].split("|");
							if(trmName.length > 1)
							{
								td1[h].innerHTML = trmName[1];
								_instance.UFLList[r] = trmName[2]*1;
							}
							else
								td1[h].innerHTML = trmName[0];
							td1[h].title = trmName[0];
							break;
						}
					case 3: {
							var title_man;
							if (document.getElementById("title_man-" + r))
								title_man = document.getElementById("title_man-" + r);
							else
								title_man = document.createElement('p');
							title_man.id = "title_man-" + r;
							obj_split[h] = obj_split[h].split("|");
							title_man.innerHTML = _instance.FindFIO(obj_split[h][0]*1,obj_split[h][1]);
							td1[h].setAttribute('vlign', 'center');
							td1[h].appendChild(title_man);

							title_man.title = obj_split[h][1];
							break;
						}
					case 4: {
							var title_operation;
							if (document.getElementById("title_operation-" + r))
								title_operation = document.getElementById("title_operation-" + r);
							else
								title_operation = document.createElement('p');
							title_operation.id = "title_operation-" + r;
							var operation = obj_split[h].split("|");

							var opTitle;
							if(operation[0]=="TRM")
								opTitle = "(перевод) "+_instance.arrayTRM[operation[1]*1-1][0];
							else
								opTitle = operation[1];
							title_operation.innerHTML = opTitle;

							td1[h].setAttribute('vlign', 'center');
							td1[h].appendChild(title_operation);
						
							title_operation.title = operation[2]+": "+opTitle;
							break;
						}
					case 5: {
							var times = obj_split[h].split("|");
							var vrRab = times[0]*1;//время работы станции (открыта)
							if(times[2]*1>times[4]*1)
								vrRab = vrRab + (times[3]*1-times[2]*1);
							var vrProstoy = vrRab - (times[1]*1+times[5]*1);	
							if(vrProstoy<0) vrProstoy = 0;
							td1[h].innerHTML = _instance.intToTime(vrProstoy*2);
							break;
						}
					case 6: {				
							td1[h].innerHTML = _instance.intToTime(obj_split[h]);
							break;
						}
					case 7: {
							td1[h].innerHTML = obj_split[h];
							break;
						}
					case 8: {
							if (obj_split[7] * 1 > 0)
								obj_split[h] = Math.round(obj_split[h] / obj_split[7]);
							else
								obj_split[h] = 0;
							td1[h].innerHTML = _instance.intToTime(obj_split[h]);			
							break;
						}
					case 9: {
							var perer = obj_split[h].split("|");
							
							var pereriv = 0;
							var VremNachRab 	= perer[0]*2;
							var VremTek		 	= perer[1]*2;
							var VremOkonch 		= perer[2]*2;
							var VremRabOkna 	= perer[3]*2;
							var VremVhoda 		= perer[4]*2;
							var VremVihoda 		= perer[5]*2;
							var VremPerVhoda 	= perer[6]*2;
							
							var dayTo = VremTek;
							if(dayTo<VremNachRab)
								dayTo = VremNachRab;
							if(dayTo>VremOkonch)
								dayTo = VremOkonch;
							
							if(VremVhoda<VremNachRab)
								VremVhoda = VremNachRab;
							if(VremVhoda>VremOkonch)
								VremVhoda = VremOkonch;
							if(VremVhoda>VremVihoda)
								VremVihoda=VremVhoda;
							pereriv = (VremVihoda-VremPerVhoda)-VremRabOkna;
							
							if(VremRabOkna==0)
								pereriv = 0;
							
							if(pereriv<0)
								pereriv = 0;
						
							td1[h].innerHTML = _instance.intToTime(pereriv);
							break;
						}
					default: {
							console.log("err");
							break;
						}
					}
				

				document.getElementById('workstation-' + r).appendChild(td1[h]);
			}
		}
		}
	}
var director = 1;
//console.log(director);
/*if(director>0)
	loadResults();*/
_instance.loadResults();
var wh = $(".card").width()*1-882;
if(wh<100) wh=100;
wh = wh + "px";
//$("#counters-table thead th:nth-child(4)").css("width",wh);


$(".td-4").css("width",wh);
$(".td-4 p").css("width",wh);

for(var i = 1; i < 10; i++)
	{
	var wd = $(".td-"+i).width();
	$("#counters-table thead th:nth-child("+i+")").width(wd);
	$("#counters-table tfoot tr th:nth-child("+i+")").width(wd);
	}


if(firstResult==true)
	{
	//$(".table-gray").hide();
	_instance.height();
	firstResult = false;
	}
if(module.hide==true) {$(".table-gray").hide();}
else {$(".table-gray").show();}
}
	console.log(this.name+" is initializated!");
	
	this.load();
}