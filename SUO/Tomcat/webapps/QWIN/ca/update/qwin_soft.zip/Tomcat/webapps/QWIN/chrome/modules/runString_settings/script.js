var module = new module();

function module()
{
var _instance = this;
this.name = 'runString_settings';
this.title = 'Бегущая строка';
this.edit = false;
this.stop = function ()
	{
	console.log("stop module "+_instance.name+"...");
	//clearTimeout(_instance.timers[0]);
	};	
this.load = function() 
	{

	$.ajax({
		url : "modules/"+_instance.name+"/module.html",
		success : function (txt) {
		$('.container').html(txt);
		_instance.LoadData();
		if(CurPermissions['runString_settings']>=2)
			{
			_instance.edit = true;
			}
		if(_instance.edit == true)
			{
			$( "#runString-save" ).css('display','inline-block');	
			$( "#runString-save" ).click(function() {
				var strings = {};
				var params = "modules/"+_instance.name+"/save.qsp?";
				for(var i=1;i<6;i++)
				{
					strings["text"+i] = $("#runString-"+i).val();
					if(strings["text"+i]=="")	strings["text"+i] = "0";
					if(i>1)
						params+="&";
					params+="text"+i;
					params+="=\""+encodeURIComponent(strings["text"+i])+"\"";
				}
				console.log(params);
				$.ajax({
					url: params, 
					type: "POST",		
					data: strings,
					success: function(json) {alert("Данные сохранены!");clearBug();},
					error: function() {	alert("Ошибка сохранения!");bugAdd();}
					});
				});
			}
		},
		error : function ($xhr) {console.log($xhr,"err");}
	});

	}


this.LoadData = function () {
$.ajax({
		url: "modules/"+_instance.name+"/data.qsp",                 
		success: function(json) {
		clearBug();
		json = json.split("||");
		console.log(json,json.length);
		for(var i=0;i<json.length;i++)
			{
			$("#runString-"+(i+1)).val(json[i]);
			$('input'+'#runString-'+(i+1)).characterCounter();
			if(_instance.edit == false)
				{
				$("#runString-"+(i+1)).attr("disabled","disabled"); 	
				}
			}
		$("label").addClass("active");
		
		},
		error : function ($xhr) {
			console.log($xhr,"err");
			bugAdd();
			
		}
	});
}

this.load();
}