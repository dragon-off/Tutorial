var dirPult = new dirPult();

function dirPult()
{
var _instance = this;
this.name = 'director_workstation';
this.title = 'Пульт директора';
this.workstation = 0;
this.loginCode = 0;
this.widgetLeft = -100;
this.widgetTop = -100;
this.blockUpdate = false;
this.notonly = true;
this.timers = new Array();
this.dir = "/chrome/modules/"+_instance.name;
this.groupletters; //Буквы кнопок
this.stop = function ()
	{
	console.log("stop module "+_instance.name+"...");
	clearTimeout(_instance.timers[0]);
	};
this.call = function(value) 
	{
	$("body").css('cursor','progress');
	_instance.timers[0] = setTimeout(function(){$("body").css('cursor','default');clearTimeout(_instance.timers[0]);clearTimeout(_instance.timers[1]);alert("Ошибка инициализации окна директора!\nВозможные причины:\n- Нет cвязи с сервером СУО\n- Нет настроенных табло");},10000);
	var tmp = new Date();
	tmp = tmp.getHours() + tmp.getMinutes() + tmp.getSeconds();

	var runUrl = _instance.dir+"/data.qsp?value=" + value + "&action=1"+ "&login=" + _instance.loginCode + "&tmp="+tmp;
	console.log(runUrl);
	$.ajax({
		url : runUrl,
		success : function (txt) {
			txt = txt.split('|');
			if(txt[0]*1==-1)
				{
				alert("Ошибка инициализации окна директора!\nВозможные причины:\n- Нет ни одного настроенного окна под директора\n- Все окна директоров заняты");
				$("#title-pult-dir").attr('title',value[1]);
				$("body").css('cursor','default');
				}
			else
				{
				_instance.workstation = txt[0]*1;
				$('#header-pult-dir').text('Пульт Директора "'+txt[1]+'"');
				}
			_instance.groupletters = txt[3].trim();
			console.log("good call");
			_instance.timers[1] = setTimeout(function(){clearTimeout(_instance.timers[1]);clearTimeout(_instance.timers[0]);$("body").css('cursor','default');_instance.end();alert("Ошибка вызова клиента!\nВозможные прицины:\n- Клиента уже вызвали");},5000);
		},
		error : function ($xhr) {console.log($xhr,"err");}
	});	
	}
this.end = function() 
	{
	var runUrl = _instance.dir+"/data.qsp?workstation=" + _instance.workstation + "&action=2";
	console.log(runUrl);
	$.ajax({
		url : runUrl,
		success : function (txt) {console.log("good end");_instance.blockUpdate = true;$("#pult-dir").hide("drop", { direction: "right" },500);},
		error : function ($xhr) {console.log($xhr,"err");}
	});
	}

this.perevod = function(value) 
	{
	var runUrl = _instance.dir+"/data.qsp?workstation=" + _instance.workstation + "&action=4" + "&value=" + value;
	console.log(runUrl);
	$.ajax({
		url : runUrl,
		success : function (txt) {console.log("good perevod");_instance.blockUpdate = true;$("#pult-dir").hide("drop", { direction: "right" },500);},
		error : function ($xhr) {console.log($xhr,"err");}
	});
	}
	
this.perevodTable = function() 
	{
	var runUrl = _instance.dir+"/data.qsp?workstation=" + _instance.workstation + "&action=3";
	$.ajax({
		url : runUrl,
		success : function (txt) {
			txt = txt.split('<br>');
			$('#dropdown-perevod li').unbind('click');
			$("#dropdown-perevod").empty();
			txt.length--;
			for(var i=0;i<txt.length;i++)
				{
				txt[i] = txt[i].split('|');
				$("#dropdown-perevod").append("<li data='"+txt[i][3]+"'><a>"+txt[i][1]+"</a></li>");
				}
			
			$('#dropdown-perevod li').click( function(){dirPult.perevod($(this).attr('data'))});
			if(_instance.blockUpdate==false)
				setTimeout(function(){_instance.perevodTable()},10000);
			},
		error : function ($xhr) {console.log($xhr,"err");}
	});
	}
	
this.show = function()
	{
	$("body").css('cursor','default');
	$("#pult-dir").show("drop", { direction: "right" },500);
	
	}
this.load = function() 
	{
	console.log("director pult is loaded");
	_instance.loginCode = docCookies.getItem("suo_login")*1;
	var tmpLeft = docCookies.getItem("suo_widget_left");
	if(tmpLeft!= null && tmpLeft.split('px')[0]*1<$(window).width())
		_instance.widgetLeft = tmpLeft;
	var tmpTop = docCookies.getItem("suo_widget_top");
	if(tmpTop!= null && tmpTop.split('px')[0]*1<$(window).height())
		_instance.widgetTop = tmpTop;
	if(_instance.widgetLeft > -100)
		$("#pult-dir").css('left',_instance.widgetLeft);
	if(_instance.widgetTop > -100)
		$("#pult-dir").css('top',_instance.widgetTop);

	$("#pult-dir").mouseup(function() {_instance.setPos()});
	$("#next-pult-dir").click(function() {_instance.end()}); 
		
	}
this.responseCall = function(value)
	{
	clearTimeout(_instance.timers[0]);
	clearTimeout(_instance.timers[1]);
	_instance.blockUpdate = false;
	_instance.perevodTable();	
	value = value.split('|');
	letter = (value[0]*1-824)/(-2);
	letter = _instance.groupletters.substr(letter-1,1);
	$("#talon-pult-dir").text(letter+value[1]);
	$("#title-pult-dir").text(value[2]);
	_instance.show();
	$("#title-pult-dir").attr('title',value[1]);
	}
this.setPos = function() 
	{
	docCookies.setItem("suo_widget_top",$("#pult-dir").css('top'));
	docCookies.setItem("suo_widget_left",$("#pult-dir").css('left'));
	}
	
qwin_event.trig = function (eventType, unit, payload) {
if (eventType == "5" && unit == _instance.workstation) //Вызов клиента
	_instance.responseCall(payload);


}
qwin_event.setEvents = function () {
qwin_event.waitForEventTrig("5.200.144.123");
}
qwin_event.setEvents();
this.load();
}