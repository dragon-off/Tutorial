﻿"use strict;"

if (!window.console) {
	window.console = {
		log : function () {},
		info : function () {},
		error : function () {},
		warn : function () {}
	};
}

function savePrinter(id)
{

var inx = id.split("-")[2];
pathToJSP = 'includes/installsSavePrinters.qsp';
$.post(pathToJSP, {'printer': inx, 'name': "\""+$('#p-name-'+inx).val()+"\"",'ip':"\""+$('#p-ip-'+inx).val()+"\""}, function(answer) {
			alert('Данные принтера №'+inx+' успешно сохранены');
		});
}

function saveDisplay(id)
{

var inx = id.split("-")[2];
pathToJSP = 'includes/installsSaveDisplays.qsp';
$.post(pathToJSP, {'display': inx, 'counters': "\""+$('#d-counter-'+inx).val()+"\"",'left':"\""+$('#d-left-'+inx).val()+"\""}, function(answer) {
			alert('Данные гр. дисплеев №'+inx+' успешно сохранены');
		});
}

function addPrinter(inx,name,ip)
{
if(name=="ERROR") name="";
if(ip=="ERROR") ip="";
$( "#printers tbody" ).append("<tr><td style=\"padding:0px 5px;vertical-align: bottom;\">Принтер №"+inx+":</td><td style=\"padding:0px 5px;\"><div class=\"inputHelp\">Имя</div><input type=\"text\" value=\""+name+"\" id=\"p-name-"+inx+"\" placeholder=\"Printer "+inx+"\" maxlength=\"20\" style=\"width: 12em\" /></td><td style=\"padding:0px 5px;\"><div class=\"inputHelp\">IP-адрес</div><input type=\"text\" value=\""+ip+"\" id=\"p-ip-"+inx+"\" placeholder=\"192.168.0.10\" maxlength=\"15\" style=\"width: 7em\" /></td><td><span class=\"button\" onClick=\"savePrinter(this.id)\" id=\"save-printer-"+inx+"\">Сохранить</span></td></tr>");
}

function addDisplay(inx,counters,left,secondaries)
{
if(counters=="ERROR") counters="";
if(left=="ERROR") left="";
if(secondaries=="ERROR") secondaries="";
$( "#displays tbody" ).append("<tr><td style=\"padding:0px 5px;vertical-align: bottom;\">Гр. табло №"+inx+":</td><td style=\"padding:0px 5px;\"><div class=\"inputHelp\">Отображаемые окна</div><input type=\"text\" value=\""+counters+"\" id=\"d-counter-"+inx+"\" placeholder=\"1-38\" maxlength=\"20\" style=\"width: 12em\" /></td><td style=\"padding:0px 5px;\"><div class=\"inputHelp\">Окна слева</div><input type=\"text\" value=\""+left+"\" id=\"d-left-"+inx+"\" placeholder=\"1-38\" maxlength=\"15\" style=\"width: 7em\" /></td><td style=\"padding:0px 5px;\"><div class=\"inputHelp\">Вторичные строки</div><input type=\"text\" value=\""+secondaries+"\" id=\"d-secondaries-"+inx+"\" placeholder=\"2\" maxlength=\"2\" style=\"width: 2em\" /></td><td><span class=\"button\" onClick=\"saveDisplay(this.id)\" id=\"save-couner-"+inx+"\">Сохранить</span></td></tr>");
}

var weekDay = new Array("Понедельник","Вторник","Среда","Четверг","Пятница","Суббота","Воскресенье");
function addRasp(inx,curRasp)
{
curRasp = curRasp.substr(1, curRasp.length-2).split("|");
var str = "<tr style=\"height:50px;\"><td style=\"padding:0px 5px;vertical-align: middle;\">"+weekDay[inx-1]+"</td>";
for(var j=1;j<=5;j++)
	{
	var fromto = curRasp[j-1].split("-");
	str+="<td style=\"padding:0px 5px;\"><input type=\"text\" value=\""+
	fromto[0]+"\" id=\"f-"+inx+"-"+j+"\" placeholder=\"09:00\" maxlength=\"5\" style=\"width: 3em\" />"+
	" - <input type=\"text\" value=\""+fromto[1]+"\" id=\"t-"+inx+"-"+j+"\" placeholder=\"20:00\" maxlength=\"5\" style=\"width: 3em\" /></td>";
	}
str+="<td><span class=\"button\" onClick=\"saveRasp(this.id)\" id=\"rasp-save-"+inx+"\">Сохранить</span></td></tr>";
$( "#rasp tbody" ).append(str);
}

function saveRasp(id)
{

var inx = id.split("-")[2];
pathToJSP = 'includes/installsSaveRasp.qsp';
var str = "<";
var marker = false;

for(var i=1;i<=5;i++)
	{
	var fromT = $('#f-'+inx+'-'+i).val();
	var toT = $('#t-'+inx+'-'+i).val();
	if(fromT.length==5 && toT.length==5)
		{
		str+=fromT+"-"+toT;
		if(i<5)
			str+="|";
		}
	else
		marker = true;
	}
str += ">";
if(marker==false)
	{
		console.log(str);
	$.post(pathToJSP, {'rasp': inx, 'data': "\""+str+"\""}, function(answer) {
				alert('Расписание на '+weekDay[inx-1]+' успешно сохранено!');
			});
	}
else
	alert("Ошибка при сохранении расписания! Не соблюден формат ЧЧ:ММ");
}

function checkChromeRes(txt) //Смотрим хром запускать или нет
{
txt = txt.split(":");
if(txt.length==2 && txt[0]=="chrome")
	{
	chromeVal = txt[1]*1;
	$("#Browser").val(chromeVal);
	}
}

function saveBrowser()
{
var chromeVal = $("#Browser").val()*1;
var params = "?val="+chromeVal;
$.ajax({
	url : "includes/chromeCheck.jsp"+params,
	type : 'GET',
	success : function (txt) {alert("Браузер сохранен!");},
	error : function(txt) {	alert("Ошибка сохранения браузера!");}
});
	
}


function checkAdminTouchRes(txt) //Выдача талонов администратором
	{
	console.log(txt);
	txt = txt.split(":");
	if(txt.length==2 && txt[0]=="admintouch" && txt[1] == 'false')
		$("#installs-AdminTouch").prop('checked', false);
	else
		$("#installs-AdminTouch").prop('checked', true);
	
	}	
function checkAdminTouch() 
	{
	$.ajax({
	url : "/settings/includes/AdminTouchValue.txt",
	type : 'GET',
	success : function (txt) {checkAdminTouchRes(txt);},
	error : function(txt) {	checkAdminTouchRes('admintouch:true');}
	});	
	}

function saveAdminTouch() 
	{
	var AdminTouchVal = $("#installs-AdminTouch").prop('checked');
	console.log(AdminTouchVal);
	var params = "?val="+AdminTouchVal;
	$.ajax({
		url : "/settings/includes/AdminTouchCheck.jsp"+params,
		type : 'GET',
		success : function (txt) {alert("Параметр выдачи талонов администратором сохранен!");},
		error : function(txt) {	alert("Ошибка сохранения параметра выдачи талонов администратором!");}
	});
	}


$(document).ready(function() {

pathToJSP = 'includes/installs.qsp';
$('#saveTimeBtn').click(function(e) {
	
	
	if ($("#counters").val()*1>0) {
		$.post(pathToJSP, {'counters': $("#counters").val(),'printer': $("#printer").val(), 'save': '1'}, function(answer) {
			alert('Данные успешно сохранены');
			document.location.reload();
		});
	}
});

//menu_3
checkAdminTouch();
if($("#menu_3",top.frames['menu'].document).length > 0)
	$("#installs-AdminTouch").change(function(){saveAdminTouch()});
else $("#installs-AdminTouch").prop('disabled',true);


$('#saveBrowser').click(function() {saveBrowser();});

$.ajax({
	url : "/login/chromeValue.txt",
	type : 'GET',
	success : function (txt) {checkChromeRes(txt);},
	error : function(txt) {	checkChromeRes(txt);}
});
	
$.get(pathToJSP, null, function(data) {
	data = data.split("<br>");
	var tableHeight = document.documentElement.clientHeight*1-86;
	$("#List-tr").css("height",tableHeight+"px");
	$("#List-td").css("height",tableHeight+"px");
	$("#List-div").css("height",tableHeight+"px");
	$("#counters").val(data[0]);
	
	$("#printer").val(data[1]);
	
	var printers = data[2].split("&&");
	printers.length--;

	for(var i=1;i<=printers.length;i++)
		{
		printers[i-1] = printers[i-1].split("|");
		addPrinter(i,printers[i-1][0],printers[i-1][1]);
		}
	$("#printers").css('height',$("#printers").css('height'));
	var displays = data[3].split("&&");
	console.log(displays);
	displays.length--;
	for(var i=1;i<=displays.length;i++)
		{
		displays[i-1] = displays[i-1].split("|");
		addDisplay(i,displays[i-1][0],displays[i-1][1],displays[i-1][2]);
		}
	$( "#rasp thead td" ).css("font-size","11px");
	$( "#rasp thead td" ).css("text-align","center");
	$( "#rasp thead td" ).css("width","125px");
	var rasp = data[4].split("&&");
	for(var i=1;i<=7;i++)
		{
		addRasp(i,rasp[i-1]);
		}
	$("#displays").css('height',$("#displays").css('height'));
	$("#rasp").css('height',$("#rasp").css('height'));
});
	
});