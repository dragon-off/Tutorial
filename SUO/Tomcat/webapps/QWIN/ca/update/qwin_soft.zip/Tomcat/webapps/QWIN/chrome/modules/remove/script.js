var module = new module();

function module()
{
var _instance = this;
this.name = 'remove';
this.title = 'Удаление талонов';
this.timers = new Array();
this.stop = function ()
	{
	console.log("stop module "+_instance.name+"...");
	clearTimeout(_instance.timers[0]);
	};	
this.load = function() 
	{

	$.ajax({
		url : "modules/"+_instance.name+"/module.html",
		success : function (txt) {
		$('.container').html(txt);
		_instance.LoadData();
		if(CurPermissions['remove']==2)
			{
			$("#clearDay").css("display", "inline-block");
			$("#clearDay").click(
			function() {
			var strings = {};
			var params = "modules/"+_instance.name+"/data.qsp?day=1";
			if(confirm("Сброс дня приведет к сбросу всех талонов и всей информации в онлайн мониторинге.\n\nВы уверены, что хотите сбросить день?"))
				{
				
				$.ajax({
					url: params, 
					type: "POST",		
					data: strings,
					success: function(json) {
					var params2 = "/utils.newdayreset.action";	
					$.ajax({
						url: params2, 
						type: "GET",		
						success: function(json) {
						alert("Сброс завершен!");
						
						},
						error: function() {
						alert("Подождите пару минут, идет сброс!");		
						
						}
					});
					
					},
					error: function() {
					alert("Ошибка сброса!");		
					
					}
				});
				}	
			}
			);
			}
		//setInterval(function(){_instance.LoadData()},60000);	

		},
		error : function ($xhr) {console.log($xhr,"err");}
	});

	}
this.createElement = function (typeElement,classElement,idElement,parentElement)
	{
	var element;
	if(document.getElementById(idElement) && typeElement!="i")
		element = document.getElementById(idElement);
	else
		{
		element = document.createElement(typeElement);
		if(classElement)
			element.className = classElement;
		if(idElement)
			element.id = idElement;
		parentElement.appendChild(element);	
		}
	return element;
	}
this.removeClient = function (id)
	{
	id = id.split('-');
	console.log(id);
	var cat = id[3];
	var talon = id[4];
	var strings = {};
	var params = "modules/"+_instance.name+"/data.qsp?save=1";
		params+="&talon="+talon*1+"&category="+cat*1;
	console.log(params);
	$.ajax({
		url: params, 
		type: "POST",		
		data: strings,
		success: function(json) {
		alert("Клиент удален!");
		_instance.LoadData();
		
		},
		error: function() {
		alert("Ошибка удаления! Необходим, чтобы хотябы одно окно было открыто!");		
		
		}
	});	
	}
this.colTR = 0;
this.createTable = function (txt)
	{
	for(var i=0;i<txt.length;i++)
		{
		var idTR = "tr-remove-"+i;
		var removeTR = _instance.createElement('tr','table-white',idTR,document.getElementById('remove-tbody'));	
		//removeTR.style.display = 'table-row';
		for(var j=2;j<6;j++)
			{
			var removeTD = _instance.createElement('td','td-remove-'+(j-1),'td-remove-'+i+'-'+(j-1),removeTR);

			if(j==3) 
				{
				removeTD.title = "Начальная операция: "+txt[i][7];
				var button_name = txt[i][j].split("|");
				if(button_name.length>1)
					{
					button_name[0] = button_name[0].split(') ');
					txt[i][j] = button_name[0][0]+") В ТРМ &laquo;"+button_name[1]+"&raquo;";
					}
				}
			removeTD.innerHTML = txt[i][j];
			}
		
		var removeTD = _instance.createElement('td','td-remove-5','td-remove-'+i+'-5',removeTR);
		$('#td-remove-'+i+'-5 i' ).remove();
		
		if(txt[i][6]*1==1)
			{
			var removeIco = _instance.createElement('i','material-icons removeButton','td-remove-ico-'+txt[i][0]+"-"+txt[i][1],removeTD);
			removeIco.innerHTML = "clear";
			removeIco.onclick = function () {_instance.removeClient(this.id)}; 
			removeIco.title = 'Удалить талон';
			}
		
		
		}
	for(var i=txt.length;i<_instance.colTR;i++)
		{
		
		console.log("tr-remove-"+i);
		//var child = document.getElementById("tr-remove-"+i);
		$( "#tr-remove-"+i+" .td-remove-5 i" ).remove();
		$( "#tr-remove-"+i+" .td-remove-2 p" ).remove();
		$( "#tr-remove-"+i+" td" ).remove();
		$( "#tr-remove-"+i ).remove();
		//child.style.display = 'none';
		}
	_instance.colTR = txt.length;
	_instance.width();
	};
this.height = function ()
	{
	var sh = $( window ).height()*1;
	sh = sh-220;
	var lentr = $('#remove-tbody tr').length;
	var tbodyH = $('#remove-tbody tr:first-child').height()*lentr;
	//console.log(tbodyH);
	
	var fh = 0;
	tbodyH = tbodyH +fh+35+2;
	if(tbodyH<sh)
		sh = tbodyH;
	sh = sh+"px"
	var tbsh = sh.replace("px", "")*1;
	
	tbsh = tbsh -35-fh;
	
	tbsh = tbsh+"px";
	$('.card').css("height",sh);
	$('#remove-tbody').css("height",tbsh);
	};
	
this.width = function() {
	var wh = $(".card").width()*1-390;
	if(wh<100) wh=100;
	wh = wh + "px";
	//console.log(wh);
	$(".td-remove-2").css("width",wh);
	$(".td-remove-2 p").css("width",wh);

	for(var i = 1; i < 6; i++)
		{
		var wd = $(".td-remove-"+i).width();
		$("#remove-table thead th:nth-child("+i+")").width(wd);
	
		}
	_instance.height();
};	
this.LoadData = function() {
	clearTimeout(_instance.timers[0]);
	$.ajax({
		url: "modules/"+_instance.name+"/data.qsp?save=0",                 
		success: function(json) {
		json = json.split("<br>");
		json.length--;
		for(var i=0;i<json.length;i++)
			{
			json[i] = json[i].split("||");
			}
		
		//console.log(json);		
		_instance.createTable(json);
		
		_instance.timers[0] = setTimeout(function(){_instance.LoadData()},10000);	
		}
	});
};

this.load();
}