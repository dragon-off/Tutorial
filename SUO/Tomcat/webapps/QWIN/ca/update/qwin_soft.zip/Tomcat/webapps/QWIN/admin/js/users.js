﻿if (!window.console)
	console = {
		log : function () {},
		info : function () {},
		error : function () {},
		warn : function () {}

	}; //Если нет конслои то не обращаем внимание...
var main_timer;
var arrayTRM;//список названий трм



function parseGetParam(param) { 
var get_param=0;
var url = parent.location.search.substring(1).split("&");

if(url.length>0) 
{
for(var i=0; i<url.length; i++) 
	{ 
	var getVar = url[i].split("="); 
	if(param==getVar[0])
		get_param=getVar[1];
	
	} 
}
return get_param;
}

function FindFIO(name) //Фамилия и инициалы
{
var fio = name;
if(fio)
		{
		fio = fio.split(" ");
		var fioTmp = "";
		if(fio.length>=3)
			{
			fioTmp = fio[0].charAt(0).toUpperCase() + fio[0].substr(1)+" ";
			for(var i=1;i<fio.length;i++)
				{
				if(fio[i].substr(0, 1).match(/[а-я]/i))
					fioTmp = fioTmp + fio[i].substr(0, 1).toUpperCase()+".";
				else
					fioTmp = fioTmp + fio[i];
			
				}
			}
		else
			{
			for(var i=0;i<fio.length;i++)
				{
				if(i>0)
					fioTmp = fioTmp + " ";
				fioTmp = fioTmp + fio[i].charAt(0).toUpperCase() + fio[i].substr(1);
				}
			}
		fio = fioTmp;
		
				
		}
	else
		fio = name;

return fio;
}
function findTRM(trm) 
{
trm = trm.replace(/^\s+|\s+$/g, '');

for(var i=0;i<arrayTRM.length;i++)
	{
	if(arrayTRM[i][0].indexOf(trm)>=0)
		return arrayTRM[i]; 
	}
}

function LoadMain() {
	
	clearTimeout(main_timer);
	if(DisconnectMarker==false)
	$.ajax({
		url : "/usersMonitoring",
		type : 'GET',
		success : function (a) {
			a = a.split("¤");
			if (a.length > 1) {
				{
					arrayTRM = a[0].split("&&");
					arrayTRM.length--;
					for(var i=0;i<arrayTRM.length;i++)
						arrayTRM[i] = arrayTRM[i].split("|");
					
					responseUsers(a[1]);
					
				//console.log();
				}
			
				//responseCategorys(a[2]);
			} else
				console.log("error LoadMain", a.length);
		},
		error : function ($xhr) {
			if ($xhr.status === 500) {
				var uname = parseGetParam('username');	
				bugAdd();
			}

		}
	});
	if(DisconnectMarker==false)
	main_timer = setTimeout(function () {
			LoadMain()
		}, 60000);
}
function plusZero(num) //Добавлем ноль в числа меньше 10
{
	var out = "";
	if (num * 1 < 10)
		out = "0" + num;
	else
		out = num;
	return out;
}

var users_len = 0; //Количество строк в таблице с пользователями
function timeToInt(time)//Время в цифру
{
time = time.split(":");
var out=0;
out = time[2]*1+time[1]*60+time[0]*3600;
return out;
}
function intToTime(txt) //Цифра во время
{
var time = new Date(0, 0, 0, 0);
var out;
time.setSeconds(txt);
out = plusZero(time.getHours()) + ":" + plusZero(time.getMinutes()) + ":" + plusZero(time.getSeconds());
return out;
}
function loadResults()	//Результативные показатели
{
	
var SumZn = new Array(0,0,0,0,0,0,0,0,0,0,0);
var SrZn = new Array(0,0,0,0,0,0,0,0,0,0,0);
for(var i = 4; i < 11; i++)
	{
	for(var j = 1; j < users_len; j++)
		{
		if(i == 6)
			SumZn[i] += $("#td-"+j+"-"+i).text()*1;
		else
			SumZn[i] += timeToInt($("#td-"+j+"-"+i).text());
		
		}
	if(users_len > 1)
		{
		if(i == 6)
			SrZn[i] = Math.round(SumZn[i]/(users_len-1));
		else
			SrZn[i] = intToTime(Math.round(SumZn[i]/(users_len-1)));
		}		
	}

SumZn[10] = intToTime(SumZn[10]);
var Res = new Array();

Res[0] = "<tr id='res-1'><td style=\"border-left:0px;text-align:right;\">Средние значения:</td><td class=\"header-center\" colspan=3>&nbsp;</td>";
for(var i = 4; i < 10; i++)
	{
	Res[0] += "<td class=\"header-center\">"+SrZn[i]+"</td>";
	}
Res[0] += "<td class=\"header-center\" style=\"border-right:0px;\">&nbsp;</td>";
$(".info-table tfoot").html("");
$(".info-table tfoot").append(Res[0]);

Res[1] = "<tr id='res-2'><td style=\"border-left:0px;text-align:right;\">Всего за период:</td><td class=\"header-center\" colspan=3>&nbsp;</td>";
for(var i = 4; i < 11; i++)
	{
	if(i == 6)
		{
		var sty ="style=\"border-right:0px;\"";
		Res[1] += "<td class=\"header-center\" "+sty+">"+SumZn[i]+"</td>";
		}
	else
		Res[1] += "<td class=\"header-center\">&nbsp;</td>";
	}
$(".info-table tfoot").append(Res[1]);


}

function responseUsers(txt) //Обработка пользователей
{
	resp = txt;
	resultArr = new Array();
	var line_split;
	var el_g;
	var system_type = '';
	line_split = resp.split('<br>');
	//console.log(line_split);
	var tr = new Array();
	var schet = 1;
	users_len = line_split.length;
	for (var r = 1; r < line_split.length; r++) {
	
		obj_split = line_split[r - 1].split('&&');
		if (document.getElementById('user-' + r)) {
			tr[r - 1] = document.getElementById('user-' + r);
			tr[r - 1].className = 'table-white';
			mouse_color_table(tr[r - 1], 2);
		} else {
			tr[r - 1] = document.createElement('tr');
			tr[r - 1].className = 'table-white';
		}
		tr[r - 1].id = 'user-' + r;
		document.getElementById('work-table').appendChild(tr[r - 1]);

		if (obj_split.length > 1) {
			var td1 = new Array();
			tr[r - 1].onmouseover = new Function("mouse_color_table(this,1)");
			tr[r - 1].onmouseout = new Function("mouse_color_table(this,2)");
		
			
			for (var h = 0; h <= obj_split.length - 1; h++) {

				if (document.getElementById('td-' + r+'-'+h))
					td1[h] = document.getElementById('td-' + r+'-'+h);
				else
					td1[h] = document.createElement('td');
				td1[h].id = 'td-' + r+'-'+h;
				td1[h].className = 'td-' + h;
				td1[h].style.height = '26px';
				schet++;
				if(obj_split[h].indexOf("null")>=0)obj_split[h] = "0";
				switch (h) {
					case 0: {
							var title_man;
							if (document.getElementById("title_man-" + r))
								title_man = document.getElementById("title_man-" + r);
							else
								title_man = document.createElement('p');
							title_man.id = "title_man-" + r;

							title_man.innerHTML = FindFIO(obj_split[h]);
							title_man.style.height = "18px";
							title_man.style.whiteSpace = "nowrap";
							title_man.style.margin = "0px";
							title_man.style.overflow = "hidden";
							title_man.style.textOverflow = "ellipsis";
							td1[h].setAttribute('vlign', 'center');
							td1[h].appendChild(title_man);
						
							title_man.title = obj_split[h];
							break;
						}
					case 1: {
							var trmName = findTRM(obj_split[h]);
							if(trmName.length > 1)
							{
								td1[h].innerHTML = trmName[1];
							}
							else
								td1[h].innerHTML = trmName[0];
							td1[h].title = trmName[0];
							break;
						}
					case 2: {
							obj_split[h] = obj_split[h].split(" ");
							if(obj_split[h].length > 1)
								td1[h].innerHTML = obj_split[h][1];
							else
								td1[h].innerHTML = "&nbsp;";
							break;
						}
					case 3: {
							obj_split[h] = obj_split[h].split(" ");
							if(obj_split[h].length > 1)
								td1[h].innerHTML = obj_split[h][1];
							else
								td1[h].innerHTML = "&nbsp;";
							break;
						}
					case 4: {
							td1[h].innerHTML = intToTime(obj_split[h]*1);
							break;
						}
					case 5: {		
							console.log(obj_split[h].split("||"));
							obj_split[h] = obj_split[h].split("||");
							var pereriv = 0;
							for(var i=0;i<obj_split[h].length;i++)
								{
								pereriv += obj_split[h][i]*1;
								}
							console.log(pereriv);
							obj_split[h] = pereriv;
							td1[h].innerHTML = intToTime(obj_split[h]*1);
							break;
						}
					case 6: {
							td1[h].innerHTML = obj_split[h]*1;
							break;
						}
					case 7: {
							td1[h].innerHTML = intToTime(obj_split[h]*1);	
							break;
						}
					case 8: {
							//CloseOpen - vrobsl - pereryv
							var Prostoy = 0;
							Prostoy = obj_split[4]*1 - obj_split[7]*1 - obj_split[5]*1;
							if(Prostoy<0) Prostoy = 0;
							obj_split[h] = Prostoy;
							td1[h].innerHTML = intToTime(obj_split[h]*1);
							break;
						}
					case 9: {
							if(obj_split[6]*1>0)
								obj_split[h] = intToTime(Math.round(obj_split[7]/obj_split[6]*1));
							else
								obj_split[h] = intToTime(0);
							td1[h].innerHTML = obj_split[h];
							break;
						}
					case 10: {
							td1[h].innerHTML = intToTime(obj_split[h]*1);
							break;
						}
					default: {
							console.log("err");
							break;
						}
					}

				document.getElementById('user-' + r).appendChild(td1[h]);
			}
		}
		
	}
loadResults();


}


function mouse_color_table(el, state) {
	if (state == 1) {
		if (el.className == "table-green")
			el.style.backgroundPosition = "0px -28px";
		if (el.className == "table-red")
			el.style.backgroundPosition = "0px -84px";
		if (el.className == "table-yellow")
			el.style.backgroundPosition = "0px -280px";
		if (el.className == "table-gray")
			el.style.backgroundPosition = "0px -168px";
		if (el.className == "table-white") {
			el.style.backgroundPosition = "0px -224px";
			el.style.color = "#4272c0";
		} else
			el.style.color = "";
	} else {
		if (el.className == "table-green")
			el.style.backgroundPosition = "0px 0px";
		if (el.className == "table-red")
			el.style.backgroundPosition = "0px -56px";
		if (el.className == "table-yellow")
			el.style.backgroundPosition = "0px -252px";
		if (el.className == "table-gray")
			el.style.backgroundPosition = "0px -168px";
		if (el.className == "table-white") {
			el.style.backgroundPosition = "0px -196px";
			el.style.color = "black";
		} else {
			el.style.color = "";
		}
	}
}



