var Permissions;
var CurPermissions =  new Array();
var PermissionName = ['workstation','indicators','statistic','printer','counters','groups','users','runString_settings','normTime_settings','remove','trm_settings','counters_settings','install_settings','printer_settings','director_workstation'];


function getGroupId(groupName)
{
for(var i = 0;i < 6;i++)	
	{
	if(Permissions[i]['group'].toLowerCase() == groupName.toLowerCase())
		return i;
	}
return -1;
}
function checkAdminPrinter() {
	$.ajax({
	url : "/settings/includes/AdminTouchValue.txt",
	type : 'GET',
	success : function (txt) {checkAdminTouchRes(txt);},
	error : function(txt) {	checkAdminTouchRes('admintouch:true');}
	});	

}

function checkAdminTouchRes(txt) {
	txt = txt.split(":");
	if(txt.length==2 && txt[0]=="admintouch" && txt[1] == 'false')
		$("#menu-printer").remove();
}

function showMenu()
{
var showMonitoring = false;
var showSettings = false;
for(var i = 0;i < PermissionName.length;i++)	
	{
	var pn = PermissionName[i]
	if(CurPermissions[pn]>0)
		{
		//console.log("#menu-"+pn);
		if(pn=="counters" || pn=="groups" || pn=="users")
			showMonitoring = true;
		if(pn.search("_settings")>0)
			showSettings = true;
		$("#menu-"+pn).show();
		}

	}
if(showMonitoring == true)
	$("#menu-monitoring").show();
if(showSettings == true)
	$("#menu-settings").show();	
checkAdminPrinter();
}

function getPermissions(groups,DisplayName,type)
{
$.ajax({
	url : "/getPermissions",
	dataType: 'json',
	success : function (json) {
	console.log(json);	
	Permissions = json;
	calcPermissions(groups,DisplayName,type);
	},
	error : function ($xhr) {console.log($xhr,"err","loadHeader"); }
	}); 
}

function calcPermissions(groups,DisplayName,type)
{
var groups_len = groups.length;
var groupsName = new Array();
if(groups_len == 0) 
	{
	$("#login-loading").hide();
	$("#login-error").show();
	return NULL;
	}
for(var i = 0;i < groups_len;i++)	
	{
	var inxPerm = Permissions[groups[i]['Name']];
	console.log(inxPerm);	
	groupsName[groupsName.length] = inxPerm['title'];
	for(var j = 0;j < PermissionName.length;j++)	
			{
			if(!CurPermissions[PermissionName[j]] || CurPermissions[PermissionName[j]] < inxPerm['access'][PermissionName[j]])	
				CurPermissions[PermissionName[j]] = inxPerm['access'][PermissionName[j]];	
			}
	}
console.log(CurPermissions,groupsName);
showMenu();
var fio = DisplayName.split(" ");
if(fio.length==3)
	{
	fio = fio[0]+" "+fio[1].substr(0,1).toUpperCase()+"."+fio[2].substr(0,1).toUpperCase()+".";
	}
else
	fio = DisplayName;
$(".user-info").text(fio);
$(".user-groups").append("<div class='chip'>"+groupsName[0]+"</div>");

if(groupsName.length>1)
{
var groupsNameTitle = "";
for(var i = 0;i < groupsName.length;i++)	
	{
	if(i>0)
		groupsNameTitle = groupsNameTitle + ", "+ groupsName[i];
	else
		groupsNameTitle = groupsName[i];
	}
$(".user-groups").append(",<div class='chip' title='"+groupsNameTitle+"'>...</div>");
}
if(type!="refresh")
	LoginNow(DisplayName);
else
	endLogin();
}