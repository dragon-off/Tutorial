﻿var cur_page = 0; //текущая страница
var pagesBack = new Array(); //Предыдущие страницы
var pagesType = new Array(); //Типы страниц
var mainPage = 0; //Начальная страница
var MyReload = false; //маркер перезагрузки
var printer = 2; //Номер принтера
var print_enabled; //Доступность кнопок на печать
var ReloadButtons = false; //Маркер возможности перезагрузки кнопок
var checkSession = false; //Маркер проверки соединения
var LoadPage = false; //Маркер проверки производилась ли загрузка страница
var TouchSize = 0; //Размер touchscreenа
var Pages;
var timeDiff = 0;
var pageReloadTimeout;
var schedule = {
	'1' : [],
	'2' : [],
	'3' : [],
	'4' : [],
	'5' : [],
	'6' : [],
	'7' : []
};
var buttonMessages = {
		'-1': { 'message': '' }
};
var buttonMessagesSpec = new Array();

if (!window.console) {
	console = {
		log : function () {},
		info : function () {},
		error : function () {},
		warn : function () {}
	};
}

function addTouch(tSize) {TouchSize = tSize;}
function $ajax(url, successCallback, errorCallback, successCbArg, data, requestType) {
	if (!url) {
		throw 'URL must be specified'
	}

	requestType = typeof requestType === 'string' ? requestType.toUpperCase() : 'GET';

	if ((requestType !== 'GET') & (requestType !== 'POST')) {
		requestType = 'GET';
	}

	return $.ajax({
		url : url,
		type : requestType,
		data : data,
		cache: false,
		success : function (data) {
			if (successCallback) {
				successCallback.call(this, data, successCbArg);
			}
		},
		error : function ($xhr) { //http://api.jquery.com/Types/#jqXHR
			if (errorCallback) {
				errorCallback.call(this, $xhr);
			}
		}
	});
}

function parseGetParam(param) //получаем парамтеры из адресной строки
{
	var get_param = 2;
	var url = window.location.search.substring(1).split("&");

	if (url.length > 0) {
		for (var i = 0; i < url.length; i++) {
			var getVar = url[i].split("=");

			if (getVar[0] == param)
				get_param = getVar[1] * 1;
		}
	}
	return get_param;
}

function check_connect_result(res) //результат проверки соединения
{
	var connectionOk = false;
	if (res) {
		connectionOk = typeof res === 'string' ? res.split('#')[0] === 'good' : false;
	}
	if (connectionOk) {
		console.log('Связь есть! Старт проверки сессии...');
		$ajax('/logout.action',
			function()
				{
				$ajax('/login/login.action?username=administrator&page=/touchscreens/ping.qsp',
				function(){$ajax('includes/ping.qsp', check_session_result, check_session_result);},
				check_session_result);
				},
			check_connect_result);
		
		//$ajax('/login/login.action?username=administrator&page=/touchscreens/ping.qsp', check_session_result, check_session_result);
	} else {
		setTimeout(function () {
			console.log('Проверяем соединение до сервера...');
			$ajax('/login/ping.txt', check_connect_result, check_connect_result);
		}, 10000);
	}
}

function check_session_result(res) //результат проверки сессии перезагрузка страницы/проверка соединения
{
	var sessionOk = false;
	if (res) {
		sessionOk = typeof res === 'string' ? res.split('#')[0] === 'good' : false;
	}
	if (sessionOk)
		document.location.reload();
	else {
		checkSession = true;
		console.log('Сессии нет! Проверяем соединение до сервера...');
		$ajax('/login/ping.txt', check_connect_result, check_connect_result);
	}
}

function check_session() // проверяем сессию
{
	if(checkSession==false)
		{
		console.log('Старт проверки сессии...')
		$ajax('includes/ping.qsp', check_session_result, check_session_result);
		}
	else
		console.log('Проверка сессии уже идет!')
}

//Выключает кнопки
function turnOff(page) {
	var mark = 0,
	mark2 = true,
	state,
	Link = 0,
	activeLinks = 0,
	activeButtons = 0;
	
	$('#page-' + page + ' .button').each(function () {
		var that = $(this);
		var inx = $(this).prop('id');
		var number = inx.split("-");
		var mainButtonClass = that.attr("class").split(" ")[1];
		if (number[1] != "link" ) {
			state = Number(print_enabled.charAt(number[1]));
			if (state === 0) {
				that.addClass(mainButtonClass + "-disabled");
				that.removeClass(mainButtonClass + "-hidden");
				mark2 = false;
				activeButtons++;
			}
			else if (state === 1) {
				that.removeClass(mainButtonClass + "-disabled");
				that.removeClass(mainButtonClass + "-hidden");
				mark = 1;
				activeButtons++;
			}
			else if (state === 2) {
				that.addClass(mainButtonClass + "-disabled");
				that.addClass(mainButtonClass + "-hidden");
			}
		} else {
			state = turnOff(number[2] * 1);
			//console.log(state+" "+page);
			if (state == 1) {
				that.removeClass(mainButtonClass + "-disabled");
				that.removeClass(mainButtonClass + "-hidden");
				mark = 1;
				activeLinks++;
				if(activeLinks==1)
						Link = number[2] * 1; 
			}
			else if (state == 0) {
					that.addClass(mainButtonClass + "-disabled");
					that.removeClass(mainButtonClass + "-hidden");
					mark2 = false;
					activeLinks++;
					if(activeLinks==1)
						Link = number[2] * 1; 
			}
			else if(state == 2) {
					//that.css('display', 'none');
					that.addClass(mainButtonClass + "-disabled");
					that.addClass(mainButtonClass + "-hidden");
			}
		}
		
	});
	if(mark2==true && mark==0) mark = 2;
	if(pagesType[page]==1 && mainPage==page)//Если на начальной странице только одна кнопка доступна, то переходим в на следующий уровень
		{
		if(activeLinks==1 && activeButtons==0)
			{
			console.log("change mainPage from "+mainPage+" to "+Link);
			$('#page-' + mainPage + ' .back').show();
			$('#page-' + mainPage + " .title-page").show();
			if(pagesType[mainPage]*1==2) //Смещение вверх от синих кнопок на главном экране, если есть уровень 0
				{
				$('#page-' + Link +" .Button-1").removeClass("Button-1-margin");
				}
			mainPage = Link;
			$('#page-' + Link + ' .back').hide();
			$('#page-' + Link + " .title-page").hide();
			if(pagesType[Link]*1==2) //Смещение вниз от синих кнопок на главном экране, если нет уровня 0
				{
				$('#page-' + Link +" .Button-1").addClass("Button-1-margin");
				}
			gotopage(mainPage,2);
			}
		}

	return mark;
}

function getCorrectedTime() {
	var d = new Date();
	d.setSeconds(timeDiff);
	return d;
}
function getScheduleEntry(dayOfWeek, catType) {
	var result = null;
	if ( (dayOfWeek > 0) & (dayOfWeek < 8) ) {
		if ( (catType > 0) & (catType < 6) ) {
			result = schedule[dayOfWeek][catType];
		}
	}
	return result;
}
function isCurrentTimeOk(dayOfWeek, catType) {
	var entry = getScheduleEntry(dayOfWeek, catType),
		d = getCorrectedTime(),
		result = false;
	if (entry) {
		d = getCorrectedTime();
		d = (d.getHours() * 60 * 60) + (d.getMinutes() * 60) + d.getSeconds();
		result = Boolean((d >= entry.from) & (d <= entry.till));
	}
	return result;
}
function createScheduleEntry(str) {
	var result = null,
	regResult = /^(\d\d):(\d\d)-(\d\d):(\d\d)$/.exec(str);
	if ((regResult) && (regResult.length == 5)) {
		result = {
			from: (regResult[1] * 60 * 60) + (Number(regResult[2]) * 60),
			till: (regResult[3] * 60 * 60) + (Number(regResult[4]) * 60)
		};
	}
	return result;
}
function removeBrackets(str) {
	return str.length > 2 ? str.substr(1, str.length - 2) : str;
}
function convertToBool(str) {
	return str === '0' ? false : true;
}
function replaceChar(str, idx, sym) {
	return str.substr(0, idx) + sym + str.substr(idx + 1);
}
//Обработка доступности кнопок
function rasp_split(res) {
	var d1, d2, wholeData, dataLine, entry, dayOfWeek,
	categories, buttonState, allowedTrm, isTrue, isFirstRun;
	
	res = res.split(">||<");
	console.log(res);
	isFirstRun = (print_enabled === undefined);
	
	print_enabled = res[0].split("{}")[printer - 1];
	
	d1 = Number(res[3]);
	if ( !isNaN(d1) ) {
		d1 = new Date(0, 0, 0, 0, 0, d1 * 2);
		d1 = (d1.getHours() * 60 * 60) + (d1.getMinutes() * 60) + d1.getSeconds();
		d2 = new Date();
		d2 = (d2.getHours() * 60 * 60) + (d2.getMinutes() * 60) + d2.getSeconds();
		timeDiff = d1 - d2;
	}
	
	schedule = {
		'1' : [], '2' : [], '3' : [], '4' : [], '5' : [], '6' : [], '7' : []
	};
	
	if(res[1]) {		
		wholeData = res[1].split('{}');
		for (var i = 0; i < wholeData.length; i++) {
			dataLine = removeBrackets(wholeData[i]).split('|');
			schedule[i + 1].push({'from' : 0, 'till' : 0});
			for (var k = 0; k < dataLine.length; k++) {
				entry = createScheduleEntry(dataLine[k]);
				if (entry) {
					schedule[i + 1].push(entry);
				}
			}
		}
	}
	
	if (!res[2]) {
		throw "Could not find res[2] for categories!";
	}
	categories = removeBrackets(res[2]);
	
	dayOfWeek = Number(res[4]);
	if (isNaN(dayOfWeek)) {
		dayOfWeek = 1;
	}

	if (res[5]) {
		wholeData = res[5].split('{}');
		if (/^<\d+>$/.test(wholeData[0]) === true) {
			allowedTrm = removeBrackets(wholeData[0]);
			if (wholeData.length > 2) {
				for (var i = 1; i < wholeData.length - 1; i++) {
					if (/^<\d+>$/.test(wholeData[i]) === false) { continue; }
					dataLine = removeBrackets(wholeData[i]);
					for (var k = 0; k < dataLine.length; k++) {
						isTrue = convertToBool(allowedTrm.charAt(k)) | convertToBool(dataLine.charAt(k));
						allowedTrm = replaceChar(allowedTrm, k, isTrue == true ? '1' : '0');
					}
				}
			}
		}
		if ( categories.length !== allowedTrm.length ) {
			allowedTrm = null;
			console.log('Not equal length of categories and allowedTrm. All buttons will be disabled');
		}
	}
	
	if (categories.length !== (print_enabled.length - 2)) {
		allowedTrm = null;
		console.log('Not equal length of print_enabled and categories. All buttons will be disabled');
	}

	for (var i = 0; i < categories.length; i++) {
		if (print_enabled.charAt(i + 1) === '0') {
			buttonState = '2';
		}
		else {
			buttonState = '0';
			if (allowedTrm) {
				if (allowedTrm.charAt(i) !== '0') {
					buttonState = (isCurrentTimeOk(dayOfWeek, Number(categories.charAt(i))) === true ? '1' : '0');
				}
			}
		}
		
		print_enabled = print_enabled.substr(0, i + 1) + buttonState + print_enabled.substr(i + 2);
	}
	
	if (res[6]) {
		
		wholeData = res[6].split('{}');
		
		for (var i = 0; i < wholeData.length-1; i++) {
			
			if ( /^\d+\|.+$/.test(wholeData[i]) === false ) { console.log( "Ахтунг!"); continue; }
			dataLine = wholeData[i].split('|');
			dataLine[1] = dataLine[1].replace('@touchSize@',TouchSize);
			buttonMessages[dataLine[0]] = { 'message': dataLine[1] };
			if(dataLine.length == 3)
				buttonMessagesSpec[dataLine[0]] = dataLine[2];
		}
	}
	
	console.log(print_enabled);	
	$ajax('includes/buttons.jsp', parseXML, check_session);
	if(LoadPage == false && TouchSize>0)
	{
		
		$ajax('/getTouchscreens?type=add&printer='+printer+'&size='+TouchSize, null, null);
		
	}
	else
		turnOff(mainPage);
	//$ajax('includes/buttons.txt', pages_split, check_session, !isFirstRun);
}

function createButton(Button,page) //Создание кнопки
{
Button['Title'] = Button['Title'].replace(/\\n/g,"<br>");
Button['Sub'] = Button['Sub'].replace(/\\n/g,"<br>");
var out="";
if(Button['Css']=="Button-2" || Button['Css']=="Button-5")
	{
	out+="<table id=\"button-"+(Button['Type']=='link'?"link-"+Button['Number']:Button['Number'])+"-"+page+"\" class='button "+Button['Css']+"' border=0 cellpadding=0 cellspacing=0>";
	out+="<tr>";
	out+="<td class=\"ico\"><div class=\"img "+Button['Icon']+"\"></div></td>";

	out+="<td class=\"title\">"+Button['Title']+"</td>";
	out+="</tr>";
	out+="</table>";
	}
if(Button['Css']=="Button-1" || Button['Css']=="Button-6")
	{
	out+="<table id=\"button-"+(Button['Type']=='link'?"link-"+Button['Number']:Button['Number'])+"-"+page+"\" class='button "+Button['Css']+"' border=0 cellpadding=0 cellspacing=0>";
	out+="<tr>";
	out+="<td class=\"ico\"><div class=\"img "+Button['Icon']+"\"></div></td>";
	out+="<td class=\"title\">"+Button['Title']+"</td>";
	out+="</tr>";
	out+="<tr>"
	out+="<td class=\"sub\" colspan=2>"+Button['Sub']+"</td>";
	out+="</tr>";
	out+="</table>";
	}
if(Button['Css']=="Button-4")
	{
	out+="<table id=\"button-"+(Button['Type']=='link'?"link-"+Button['Number']:Button['Number'])+"-"+page+"\" class='button "+Button['Css']+"' border=0 cellpadding=0 cellspacing=0>";
	out+="<tr>";
	out+="<td class=\"title"+(Button['Sub'].length>0?"":"2")+"\">"+Button['Title']+"</td>";
	out+="</tr>";
	if(Button['Sub'].length>0)
		{	
		out+="<tr>"
		out+="<td class=\"sub\">"+Button['Sub']+"</td>";
		out+="</tr>";
		}
	out+="</table>";
	}	

return out;
}

function createPage(Page) //Создание страницы
{

var PageId = "#page-" + Page['Settings']['Number'];
pagesType[Page['Settings']['Number']*1] = Page['Settings']['Type']*1;
$(PageId).append($("#page-type-" + Page['Settings']['Type']).html());
$(PageId + " .title-page").text(Page['Settings']['Title']);
if(Page['Settings']['Main']=='true')	
	{
	$(PageId + " .back").hide();
	$(PageId + " .title-page").hide();
	mainPage = Page['Settings']['Number']*1;
	}
else
	$(PageId + " .back").attr('id','back-'+Page['Settings']['Number']);

if(Page['Buttons']['Button']['Title'])
	{
	var buf = Page['Buttons']['Button'];
	Page['Buttons']['Button'] = new Array();
	Page['Buttons']['Button'][0] = buf;
	}
for (var i = 0; i < Page['Buttons']['Button'].length; i++) {
	$(PageId + " .buttonPlace").append(createButton(Page['Buttons']['Button'][i],Page['Settings']['Number']));
}
if(Page['Settings']['Type']*1==2 && Page['Settings']['Main']=='true') //Смещение вниз от синих кнопок на главном экране, если нет уровня 0
	{
	$(PageId+" .Button-1").css("margin-bottom","73px");
	}
}

//загрузка кнопок
function parseXML(xml)
{
Pages = $.xml2json(xml)['Page'];
console.log(Pages);
if(Pages['Settings'])
	{
	var buf = Pages;
	Pages = new Array();
	Pages[0] = buf;
	}
$('#bg').empty();
for (var i = 0; i < Pages.length; i++) {
	$("#bg").append("<div id='page-" + Pages[i]['Settings']['Number'] + "' style='display:none;'></div>");
	createPage(Pages[i]);
}
$("#page-"+mainPage).show(0);
cur_page = mainPage; 
$( ".button" ).click(function() {buttonDown(this.id); });
$( ".back" ).click(function() {buttonDown(this.id, 'back', 0); });

LoadPage = true;	
turnOff(mainPage);
}
function loading_pages() {

	printer = parseGetParam("printer");
	ReloadButtons = false;

	
	if(checkSession==false)
		{
		$ajax('includes/rasp.qsp', rasp_split, check_session);
		
		}
	else
		{
		console.log("Невозможно выполнить. Идет проверка сессии!");
		}
	if (!pageReloadTimeout) {
		pageReloadTimeout = window.setTimeout(function () {
			pageReloadTimeout = null;
			if(cur_page==mainPage)
				{	
				loading_pages();
				}
			else
				{
				ReloadButtons = true;
				}
		}, 10 * 1000);
		
	}
}
//результат печати
function print_result(res) {
	console.log(res);
	$(".info_message").hide(0);
	$(".info_message_text").text("");
	if (res.search('<html>') >= 0) {
		check_session();
		return 0;
	}
	res = res.split('#');
	if (res[0] === 'good') {
		$('#print_number').text(res[1]);
		$('#print_message').toggle(true, 0);

		clearTimeout(back_time);
		setTimeout(function () {
			gotopage(mainPage,2);
			if (MyReload == true) {
				check_session();
			}
			$('#print_message').toggle(false, 0);
			$('#print_number').text("");
		}, 3000);
	} else {
		$('#print_message').toggle(false, 0);
		$('#print_number').text("");
		check_session();
	}
}
function callPrinter(printer, button) {
	var fastTrack = 0, url = '';
	if(window != top)
		fastTrack = window.parent.getQwinFastTrack();
	else
		fastTrack = 0;

	if (fastTrack*1 === 1) {
		url += '&fasttrack=1';
		window.parent.setQwinFastTrack(0);
	}
	if(checkSession==false)
		{
		$ajax('includes/print.qsp?printer=' + printer + '&button=' + button + url, print_result, check_session);
		}
	else
		{
		console.log("Невозможно выполнить. Идет проверка сессии!");
		}
}

function buttonDown(id, type, inx, up) //Нажатие кнопки
{
	var mainClass = $("#" + id).attr("class").split(" ");
	if (type != "back" && type!="next") {
		var SplittedId = id.split("-");
		if (SplittedId[1] == "link") {
			type = "link";
			inx = SplittedId[2] * 1;
		} else {
			type = "print";
			inx = SplittedId[1] * 1;
		}
	}
	if (mainClass.length > 1 && type != "back" && type != "next")
		mainClass = mainClass[1];
	else
		mainClass = mainClass[0];
	if (up != 1) {
		if (!$("#" + id).hasClass(mainClass + "-disabled")) {	
			$("#" + id).addClass(mainClass + "-down");
			setTimeout(function () {buttonDown(id, type, inx, 1);}, 200);
		}
	} else {
		$("#" + id).removeClass(mainClass + "-down");
		if (type == "link")
			gotopage(inx);
		if (type == "back")
			backButton();
		if (type == "print")
			buttonclick(inx);
		if (type == "next")
			callPrinter(printer, inx);
	}
}

function backButton() //Кнопка назад
{
if(pagesBack.length<=1)
	page = mainPage;
else
	page = pagesBack[pagesBack.length-2];
gotopage(page,1);
}

function gotopage(page,back) //смена страницы
{
	clearTimeout(back_time);
	if(back && back>0)
		{
		if(back==1)
		{
			if(pagesBack.length>0)
				pagesBack.length--;
			else
				pagesBack = new Array();
		}
		if(back==2)
			pagesBack = new Array();
		}
	else
		pagesBack[pagesBack.length] = page;
	console.log("gotopage "+page,pagesBack);
	$(".info_message").hide(0);
	$(".info_message_text").text("");
	pre_page = cur_page;
	cur_page = page;
	if (page != mainPage)
		goback();
	for (var i = 0; i < Pages.length; i++)
		$("#page-" + Pages[i]['Settings']['Number']).hide(0);
	$("#page-" + page).show(0);
	if(page==mainPage && ReloadButtons==true)
		{
		pageReloadTimeout = null;
		loading_pages();
		}
}


function buttonclick(button) // нажатие на кнопку - печать талона
{
	console.log("button", button, "printer", printer);
	if (buttonMessages[button]) {
		if(buttonMessagesSpec[button] == 'spec')
		{
			$('#info_message_text_spec').html(buttonMessages[button].message);
			$('#info_message-2').toggle(true, 0);
			pagesBack[pagesBack.length] = 9999;
		}
		else
		{
			$('#info_message_text').html(buttonMessages[button].message);
			$('#info-1').unbind('click');
			$('#info-1').click('click', function (e) {
				buttonDown($(this).prop('id'), 'next', button);
			});
			$('#info_message').toggle(true, 0);
		}
	} else {
		callPrinter(printer, button);
	}
}
var back_time;
function goback() // авто-возврат на начальную страницу
{
	clearTimeout(back_time);
	back_time = setTimeout(function () {
		console.log("goback");
			gotopage(mainPage,2);
		}, 20000);
}

function AutoReload() {
	setTimeout(
		function () {
		console.log('перезагрузка разрешена!');
		MyReload = true;
		if (cur_page == mainPage) {
			console.log('перезагрузка!');
			check_session();
		}
	}, 600000);
}