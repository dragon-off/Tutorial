var module = new module();

function module()
{
var _instance = this;
this.name = 'printer_settings';
this.title = 'Настройки доступности кнопок';

this.stop = function ()
	{
	console.log("stop module "+_instance.name+"...");
	//clearTimeout(_instance.timers[0]);
	};	
this.load = function() 
	{

	$.ajax({
		url : "modules/"+_instance.name+"/module.html",
		success : function (txt) {
		$('.container').html(txt);
		_instance.LoadData();
		
		
		},
		error : function ($xhr) {console.log($xhr,"err");}
	});

	}


this.LoadData = function () {
$.ajax({
	url: "modules/"+_instance.name+"/data.qsp",                 
	success: function(json) {
	clearBug();
	json = json.split("<p>");
	json[0] = json[0].split("<br>");
	json[1] = json[1].split("<br>");
	json[1].length--;
	for(var i=0;i<json[1].length;i++)
		{
		json[1][i] = json[1][i].split("|");	
		}
	
	console.log(json);
	_instance.createTable(json);

	
	},
	error : function ($xhr) {
		console.log($xhr,"err");
		bugAdd();
		
	}
	});
}

this.createElement = function (typeElement,classElement,idElement,parentElement)
	{
	var element;
	if(document.getElementById(idElement) && typeElement!="i")
		element = document.getElementById(idElement);
	else
		{
		element = document.createElement(typeElement);
		if(classElement)
			element.className = classElement;
		if(idElement)
			element.id = idElement;
		parentElement.appendChild(element);	
		}
	return element;
	}

this.save = function (id,tp)
{
var ids = id.split('-');
var button = ids[2]*1+1;
var printer = ids[4]*1;
var val; 
if(tp==3)
	val = $('#'+id).val()*1; 
else
	val = $('#'+id).prop('checked')*1;
if(!printer) printer = 0;
console.log(val,printer,button,tp);
var params = "modules/"+_instance.name+"/save.qsp?";
	params+="button="+button+"&printer="+printer+"&set="+val+"&type="+tp;
console.log(params);
$.ajax({
	url: params, 
	type: "POST",		
	success: function(json) {
	alert("Изменения для кнопки №"+button+" сохранены!");
	//_instance.LoadData();
	
	},
	error: function() {
	alert("Ошибка сохранения!");		
	
	}
});	

};


this.createTable = function (txt)
	{
	var groups = new Array("Основная","ЮЛ","Ипотека","Автокредитование","Малый бизнес");
	var disable = "";
	var buttonList = txt[1];
	var enabledList = txt[0];
	var vipList = txt[3];
	var groupList = txt[2];
	txt = null;
	if(_instance.edit == true) disable = " disabled";
	for(var i=0;i<buttonList.length;i++)
		{
		if(buttonList[i][2]!='-')
			{
			var idTR = "tr-printersettings-"+i;	
			var printersettingsTR = _instance.createElement('tr','table-white',idTR,document.getElementById('printersettings-tbody'));
			var printersettingsTD = new Array();
			for(var j=0;j<3;j++)
				{
				printersettingsTD[j] = _instance.createElement('td','td-printersettings-'+(j+1),'td-printersettings-'+i+'-'+(j+1),printersettingsTR);
				printersettingsTD[j].innerHTML = buttonList[i][j];
				}
			for(var j=0;j<4;j++)
				{
				printersettingsTD[j+3] = _instance.createElement('td','td-printersettings-'+(j+4),'td-printersettings-'+i+'-'+(j+4),printersettingsTR);
				printersettingsP = _instance.createElement('p',null,null,printersettingsTD[j+3]);
				printersettingsInput = _instance.createElement('input',null,'td-printersettings-'+i+'-check-'+(j+1),printersettingsP);
				printersettingsInput.setAttribute("type", "checkbox");
				if(enabledList[j].charAt(i+1)*1 == 1)
					printersettingsInput.setAttribute("checked", "checked");
				printersettingsInput.onchange = function () {_instance.save(this.id,1)}; 
				printersettingsLabel = _instance.createElement('label',null,null,printersettingsP);
				printersettingsLabel.setAttribute("for", 'td-printersettings-'+i+'-check-'+(j+1));
				
				}
			printersettingsTD[7] = _instance.createElement('td','td-printersettings-8','td-printersettings-'+i+'-8',printersettingsTR);
			printersettingsP = _instance.createElement('p',null,null,printersettingsTD[7]);
			printersettingsInput = _instance.createElement('input',null,'td-printersettings-'+i+'-check-8',printersettingsP);
			printersettingsInput.setAttribute("type", "checkbox");
			if(vipList.charAt(i+1)*1 == 1)
				printersettingsInput.setAttribute("checked", "checked");
			printersettingsInput.onchange = function () {_instance.save(this.id,2)}; 
			printersettingsLabel = _instance.createElement('label',null,null,printersettingsP);
			printersettingsLabel.setAttribute("for", 'td-printersettings-'+i+'-check-8');
			 
			printersettingsTD[8] = _instance.createElement('td','td-printersettings-9','td-printersettings-'+i+'-9',printersettingsTR);
			printersettingsSelect = _instance.createElement('select','browser-default','td-printersettings-'+i+'-select',printersettingsTD[8]);
			printersettingsSelect.onchange = function () {_instance.save(this.id,3)}; 
			
			printersettingsOption = new Array();
			for(var j=0;j<5;j++)
				{
				printersettingsOption[j] = _instance.createElement('option',null,null,printersettingsSelect);
				printersettingsOption[j].innerHTML = groups[j];
				printersettingsOption[j].value = (j+1);
				if(groupList.charAt(i+1)*1 == (j+1))
					printersettingsOption[j].setAttribute("selected", "selected");
				}
			
			}
		}

	_instance.width();
	};
this.height = function ()
	{
	var sh = $( window ).height()*1;
	sh = sh-220;
	var lentr = $('#printersettings-tbody tr').length;
	var tbodyH = $('#printersettings-tbody tr:first-child').height()*lentr;
	//console.log(tbodyH);
	
	var fh = 0;
	tbodyH = tbodyH +fh+35+2;
	if(tbodyH<sh)
		sh = tbodyH;
	sh = sh+"px"
	var tbsh = sh.replace("px", "")*1;
	
	tbsh = tbsh -35-fh;
	
	tbsh = tbsh+"px";
	$('.card').css("height",sh);
	$('#printersettings-tbody').css("height",tbsh);
	};
	
this.width = function() {
	var wh = $(".card").width()*1-632;
	if(wh<100) wh=100;
	var wr = wh;
	wh = wh + "px";
	wr = wr - 10-5;
	wr = wr + "px";
	var row = 3
	console.log("wh",wh);
	$(".td-printersettings-"+row).css("width",wh);
	

	for(var i = 1; i < 10; i++)
		{
		var wd = $(".td-printersettings-"+i).width();
		console.log(i,wd);
		$("#printersettings-table thead th:nth-child("+i+")").width(wd);
	
		}
	_instance.height();
};	

this.load();
}