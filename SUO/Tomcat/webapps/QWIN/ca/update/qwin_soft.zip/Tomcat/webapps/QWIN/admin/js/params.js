﻿if (!window.console) console = {log: function() {},info: function() {},error: function() {},warn: function() {}}; // Если нет консоли игнорируем console
var bugNum = 0; //количество ошибок 500

function parseGetParam(param) { 
var get_param=0;
var url = parent.location.search.substring(1).split("&");

if(url.length>0) 
{
for(var i=0; i<url.length; i++) 
	{ 
	var getVar = url[i].split("="); 
	if(param==getVar[0])
		get_param=getVar[1];
	
	} 
}

return get_param;
}
function plusZero(a)
{
b=""
if(a*1<10)
	b="0"+a;
else
	b=a;
return b;
}	
function doParam(id,name,text,red)
{
var style = "white";
if(red!=undefined && red!=null && red==1)
	style = "red";

if($('#'+id).length <= 0)
	$( "#work-table" ).append( "<tr class=\"table-"+style+"\" id=\"tr-"+id+"\"><td style=\"height:30px;text-align:left;padding-left:5px;cursor:default;\">"+name+"</td><td style=\"cursor:default;\" id=\""+id+"\">"+text+"</td></tr>" );
else
{
	$('#'+id).text(text);
	$('#tr-'+id).removeClass("table-red").removeClass("table-white");
	$('#tr-'+id).addClass("table-"+style);
}
}


function LoadData() {

$.ajax({
	url : "/indicatorsMonitoring?type=indicators",
	dataType: 'json',
	success : function (json) {
	console.log(json);	
	$("#val-1").text(json.Klientopotok);
	var tmpParam = json.KlientopotokUFL;
	doParam('val-trm-ufl',"Клиентопоток УФЛ / на окно",byCounter(tmpParam.value,tmpParam.counters));
	tmpParam = json.KlientopotokOther;
	for(var i=0;i<tmpParam.length;i++)
		{
		doParam('val-trm-1-'+i,"Клиентопоток ТРМ "+tmpParam[i].name+"/ на окно",byCounter(tmpParam[i].value,tmpParam[i].counters));
		}
	var clients_proc = 0;
	tmpParam = json.bolee;
	if(tmpParam.five>0)
		clients_proc = (tmpParam.five*100)/tmpParam.sum;
	if(clients_proc>100)
		clients_proc = 100;
	var redVal = 0;
	if(clients_proc>json.redValue)
		redVal = 1;
	doParam('val-2',"Количество / Доля клиентов, ожидающих в очереди больше 5 мин",tmpParam.five+" ("+Math.round(clients_proc)+"%)",redVal);
	tmpParam = json.boleeDay;
	doParam('val-4',"Количество клиентов, ожидающих в очереди больше 5 мин в течение дня",byProcent(json.Klientopotok,tmpParam.five+json.bolee.five));
	tmpParam = json.dolya;
	doParam('val-3',"Количество и Доля открытых окон",byProcent(tmpParam.sum,tmpParam.opened));
	doParam('val-trm-2-ufl',"Среднее время обслуживания УФЛ",json.SrTransactionUFL);
	tmpParam = json.srTransactionOther;
	for(var i=0;i<tmpParam.length;i++)
		{
		doParam('val-trm-2-'+(i+1),"Среднее время обслуживания ТРМ "+tmpParam[i].name+"/ на окно",tmpParam[i].value);
		}
	tmpParam = json.bolee;
	doParam('dop-val-1',"Количество / Доля клиентов, ожидающих в очереди больше "+json.valueAfter+" мин",byProcent(tmpParam.sum,tmpParam.thirty));
	doParam('dop-val-2',"Максимальное время ожидания клиента в очереди",json.Maxvrozhid);
	},
	error : function ($xhr) {console.log($xhr,"err");bugAdd(); }
	}); 

}

function byCounter (value, counters) {
	var byCounter = 0;
	if(counters>0)
		{
		byCounter = Math.round(value/counters);
		}
	return value+"/"+byCounter;
	}
function byProcent(sum, part) {
	var byProcent = 0;
	if(part>0)
		{
		byProcent = Math.round((part*100)/sum);
		}
	if(byProcent>100) byProcent = 100;
	return part+" ("+byProcent+"%)";
	}



  $(function(){

LoadData();
setInterval(function(){LoadData()},60000);	

});


