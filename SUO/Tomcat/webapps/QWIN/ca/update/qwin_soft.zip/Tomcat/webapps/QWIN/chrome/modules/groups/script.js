var module = new module();


function module()
{
	var _instance = this;
	this.name = 'groups';
	this.title = 'Информация по категориям';
	this.timers = new Array();
	this.permission = 1;
	this.stop = function ()
	{
	console.log("stop module "+_instance.name+"...");
	clearTimeout(_instance.timers[0]);
	clearTimeout(_instance.timers[1]);
	clearTimeout(_instance.timers[2]);
	};
	this.load = function ()
	{
	
	$.ajax({
		url : "modules/"+_instance.name+"/module.html",
		success : function (txt) {
		$('.container').html(txt);
		$('#catBack').click(function(){_instance.open_main();});
		$('#catBack_vn').click(function(){_instance.open_main();});
		_instance.data();
		 
		},
		error : function ($xhr) {console.log($xhr,"err");}
	});
	
	_instance.permission = CurPermissions['groups'];
	};
	this.data = function ()
	{
	clearTimeout(_instance.timers[0]);	
	if(DisconnectMarker==false)
	$.ajax({
		url : "modules/"+_instance.name+"/data.qsp",
		type : 'GET',
		success : function (a) {
			//console.log(a);
			
				_instance.responseCategorys(a);
			
		},
		error : function ($xhr) {
			console.log($xhr.status);
			if ($xhr.status === 500) {
				var uname = parseGetParam('username');
				bugAdd();
				
			}
		}
	});
	if(DisconnectMarker==false)
		_instance.timers[0] = setTimeout(function(){_instance.data()},10000);
	};
	
	
	this.plusZero = function (num) //Добавлем ноль в числа меньше 10
	{
		var out = "";
		if (num * 1 < 10)
			out = "0" + num;
		else
			out = num;
		return out;
	}

	this.cat_len = 0; //Количество строк в таблице с категориями
	this.Sums = null;
	this.timeToInt = function (time)//Время в цифру
	{
	time = time.split(":");
	var out=0;
	out = time[2]*1+time[1]*60+time[0]*3600;
	return out;
	}

	this.intToTime = function (txt) //Цифра во время
	{
	var time = new Date(0, 0, 0, 0);
	var out;
	time.setSeconds(txt);
	out = _instance.plusZero(time.getHours()) + ":" + _instance.plusZero(time.getMinutes()) + ":" + _instance.plusZero(time.getSeconds());
	return out;
	}

	this.LoadingSum = function ()
	{
	
	$("#groups-sum-tbody td:nth-child(1)").text(_instance.Sums[0]);
	$("#groups-sum-tbody td:nth-child(2)").text(_instance.Sums[1]);
	console.log(_instance.Sums);
	if(_instance.Sums[1]>0)
		{
		$("#groups-sum-tbody td:nth-child(4)").text(_instance.intToTime(_instance.Sums[3]/_instance.Sums[1]));
		}
	else
		{
		$("#groups-sum-tbody td:nth-child(4)").text(_instance.intToTime(0));
		}
	if(_instance.Sums[4]>0)
		{
		
		$("#groups-sum-tbody td:nth-child(3)").text(_instance.intToTime(_instance.Sums[2]/_instance.Sums[4]));
		
		}
	else
		{
		$("#groups-sum-tbody td:nth-child(3)").text(_instance.intToTime(0));	
		}
	}

	this.responseCategorys = function (txt) //обработка Категорий
	{
		_instance.Sums = new Array(0,0,0,0,0);
		resp = txt;
		var line_split;
		var el_g;
		var system_type = '';
		line_split = resp.split('<br>');
		var tr = new Array();
		var schet = 1;

		cat_len = line_split.length;
		for (var r = 1; r < line_split.length; r++) {
			obj_split = line_split[r - 1].split('|');
			if(obj_split[3]!="-")
			{
			cat_len = r;	
			if (document.getElementById('cat-' + r)) {
				tr[r - 1] = document.getElementById('cat-' + r);
			
				tr[r - 1].className = 'table-' + obj_split[1];
				//mouse_color_table(tr[r - 1], 2);
			} else {
				tr[r - 1] = document.createElement('tr');
				tr[r - 1].className = 'table-' + obj_split[1];
			}
			tr[r - 1].style.cursor = "pointer";
			tr[r - 1].id = 'cat-' + r;
			document.getElementById('groups-tbody').appendChild(tr[r - 1]);

			if (obj_split.length > 1) {
				var td1 = new Array();
				/*tr[r - 1].onmouseover = new Function("mouse_color_table(this,1)");
				tr[r - 1].onmouseout = new Function("mouse_color_table(this,2)");*/
				if(obj_split[0]*1>0)
					tr[r - 1].onclick = new Function("module.open_button(" + obj_split[0] + ",\"" + obj_split[3] + "\")");
				else
					tr[r - 1].onclick = new Function("module.open_vn()");
				for (var h = 2; h <= obj_split.length - 1; h++) {

					if (document.getElementById('cattd-' + r + '-' + h))
						td1[h] = document.getElementById('cattd-'+r+'-'+h);
					else
						td1[h] = document.createElement('td');
					td1[h].id = 'cattd-' + r + '-' + h;
					td1[h].className = 'cat-td' + h;
					td1[h].style.height = '18px';
					switch(h) 
					{
					case 2: {
						td1[h].style.fontSize = "14px";
						td1[h].style.fontWeight = "900";
						td1[h].setAttribute('colSpan', 2);
						td1[h].innerHTML = obj_split[h];
						break;
						}
					case 3: {
						td1[h].style.textAlign = "left";
						td1[h].innerHTML = obj_split[h];
						break;
						}
					case 4: {
						_instance.Sums[0]+=obj_split[h]*1;
						td1[h].innerHTML = obj_split[h];
						break;
						}
					case 5: {
						_instance.Sums[1]+=obj_split[h]*1;
						td1[h].innerHTML = obj_split[h];
						break;
						}
					case 6: {
						var srvrozhid = obj_split[h].split("^");
						
						_instance.Sums[4]=_instance.Sums[4]*1+srvrozhid[1]*1;
						_instance.Sums[2]=_instance.Sums[2]*1+srvrozhid[0]*1;

						var srvrozhidout = 0;
						if(srvrozhid[1]*1>0)
							srvrozhidout = srvrozhid[0]*1/srvrozhid[1]*1;
						td1[h].innerHTML = _instance.intToTime(srvrozhidout);
						break;
						}
					case 7: {
					
						_instance.Sums[3]=_instance.Sums[3]*1+obj_split[h]*1;

						td1[h].setAttribute('colSpan', 2);
						var srvrobslOut = 0;
						if(obj_split[5]>0)
							srvrobslOut = obj_split[h]/obj_split[5];
						td1[h].innerHTML = _instance.intToTime(srvrobslOut);
						break;
						}
					default: {
						td1[h].innerHTML = obj_split[h];
						break;
						}					
					}
					
					document.getElementById('cat-' + r).appendChild(td1[h]);
				}
			}
		}
		}
	var wh = $(".card").width()*1;
	wh = wh - ($(".cattd-1-2").width()*1+$(".cattd-1-4").width()*1+$(".cattd-1-5").width()*1+$(".cattd-1-6").width()*1+$(".cattd-1-7").width()*1);
	if(wh<100) wh=100;
	wh = wh + "px";
	$(".cat-td3").css("width",wh);
	
	for(var i = 2; i < 8; i++)
		{
		var wd = $(".cat-td"+i).width();
		$("#groups-table thead th:nth-child("+(i-1)+")").width(wd);
		}
	_instance.height('#groups-tbody','#card-2');
	_instance.LoadingSum();
	}
	this.cbut = new Array();
	
	this.open_main = function () //на главную страницу категорий
	{
		_instance.cbut[0] = null;
		_instance.cbut[1] = null;
		//clearTimeout(_instance.timers[0]);
		clearTimeout(_instance.timers[1]);
		clearTimeout(_instance.timers[2]);
		$("#card-3").hide();
		$("#card-4").hide();
		$("#card-2").show();
	}
	
	this.open_button = function (id, name) //открытие кнопки
	{

		//clearTimeout(_instance.timers[0]);
		clearTimeout(_instance.timers[1]);
		clearTimeout(_instance.timers[2]);
		if (id != null) {
			_instance.cbut[0] = id;
			_instance.cbut[1] = name;
		} else {
			id = _instance.cbut[0];
			name = _instance.cbut[1];
		}
		console.log(id, name);
		if(DisconnectMarker==false && id!=null)
			{
			$("#catName p").text(name);
			$("#card-2").hide();
			$("#card-3").show();
			//$("#button-table").css("display", "table");
			
			$.ajax({
				url : "modules/"+_instance.name+"/info_buttons.qsp?button=" + id,
				type : 'GET',
				success : function (a) {
					_instance.responseButton(a,id);

				},
				error : function () {
				bugAdd();


				}
			});
			}
		
	}
	this.buttons_count = 0;
	this.open_vn = function () //открытие внутренние
	{

		//clearTimeout(_instance.timers[0]);
		clearTimeout(_instance.timers[1]);
		clearTimeout(_instance.timers[2]);
		$("#catName_vn p").html("Внутренние");
		$("#card-2").hide();
		$("#card-3").hide();
		$("#card-4").show();
		if(DisconnectMarker==false)
		$.ajax({
			url :  "modules/"+_instance.name+"/info_vn.qsp",
			type : 'GET',
			success : function (a) {
				_instance.responseVn(a);

			},
			error : function () {
			bugAdd();


			}
		});
		
	}
	
	this.responseVn = function (resp) //Таблица талонов
	{

		var line_split;
		var el_g;
		var system_type = '';
		line_split = resp.split('<br>');
		var tr = new Array();
		var schet = 1;

		for (var r = 1; r < line_split.length; r++) {
			obj_split = line_split[r - 1].split('|');

			
			if (document.getElementById('vn-' + r)) {
				tr[r - 1] = document.getElementById('vn-' + r);

				tr[r - 1].className = 'table-' + obj_split[0];
				//mouse_color_table(tr[r - 1], 2);
			} else {
				tr[r - 1] = document.createElement('tr');
				tr[r - 1].className = 'table-' + obj_split[0];
			}
			tr[r - 1].id = 'vn-' + r;
			document.getElementById('vn-tbody').appendChild(tr[r - 1]);

			if (obj_split.length > 1) {
				var td1 = new Array();
				/*tr[r - 1].onmouseover = new Function("mouse_color_table(this,1)");
				tr[r - 1].onmouseout = new Function("mouse_color_table(this,2)");*/

				for (var h = 1; h <= obj_split.length - 2; h++) {

					if (document.getElementById('vntd-' + r + '-' + h))
						td1[h] = document.getElementById('vntd-' + r + '-' + h);
					else
						td1[h] = document.createElement('td');
					td1[h].id = 'vntd-' + r + '-' + h;
					td1[h].className = 'td-vn-' + h;
					td1[h].style.height = '18px';
					schet++;
					if (h == 2) {
						td1[h].style.fontSize = "14px";
						//td1[h].style.fontWeight = "900";
					}

					if (h == 1 || h == 5) {
						td1[h].setAttribute('colSpan', 2);
					}

					td1[h].innerHTML = obj_split[h];
					document.getElementById('vn-' + r).appendChild(td1[h]);
				}
			}
			if(_instance.permission==2)
				{
				tr[r - 1].style.cursor = "pointer";
				tr[r - 1].setAttribute('data',obj_split[6]);
				tr[r - 1].onclick = function(){
				var idTalon = $(this).attr('id');
				idTalon = '#vntd-' + idTalon.split('-')[1] + '-3';
				if(confirm("Вызвать талон "+$(idTalon).text().substr(0,4)+"?"))
					dirPult.call($(this).attr('data'));
				};
				}
		}
		for (var r = line_split.length; r < _instance.tickets_count; r++) {
			$('#vn-' + r).remove();
		}
		
		_instance.tickets_count = line_split.length;
		
		var wh = $(".card").width()*1;
			wh = wh - ($(".td-vn-1").width()*1+$(".td-vn-3").width()*1+$(".td-vn-4").width()*1+$(".td-vn-5").width()*1);
			if(wh<100) wh=100;
			wh = wh + "px";
			$(".td-vn-2").css("width",wh);
			
			for(var i = 1; i < 6; i++)
				{
				var wd = $(".td-vn-"+i).width();
				$("#vn-table thead th:nth-child("+i+")").width(wd);
				}
			_instance.height('#vn-tbody','#card-4');
		if(DisconnectMarker==false)
			module.timers[2] = setTimeout(function () {_instance.open_vn()}, 5000);
	};
	this.tickets_count = 0;
	this.responseButton = function (resp,id) //Таблица талонов
		{

			var line_split;
			var el_g;
			var system_type = '';
			
			line_split = resp.split('<br>');
			var tr = new Array();
			var schet = 1;

			for (var r = 1; r < line_split.length; r++) {
				obj_split = line_split[r - 1].split('|');

				
				if (document.getElementById('b-' + r)) {
					tr[r - 1] = document.getElementById('b-' + r);

					tr[r - 1].className = 'table-' + obj_split[0];
					//mouse_color_table(tr[r - 1], 2);
				} else {
					tr[r - 1] = document.createElement('tr');
					tr[r - 1].className = 'table-' + obj_split[0];
				}
				tr[r - 1].id = 'b-' + r;
				document.getElementById('button-tbody').appendChild(tr[r - 1]);

				if (obj_split.length > 1) {
					var td1 = new Array();
					/*tr[r - 1].onmouseover = new Function("mouse_color_table(this,1)");
					tr[r - 1].onmouseout = new Function("mouse_color_table(this,2)");*/

					for (var h = 1; h <= obj_split.length - 2; h++) {

						if (document.getElementById('btd-' + r + '-' + h))
							td1[h] = document.getElementById('btd-' + r + '-' + h);
						else
							td1[h] = document.createElement('td');
						td1[h].id = 'btd-' + r + '-' + h;
						td1[h].className = 'td-button-' + h;
						td1[h].style.height = '18px';
						schet++;
						if (h == 2) {
							td1[h].style.fontSize = "14px";
							
							if(id==122)
								{
								console.log("test "+obj_split[h]);
								var itemValue = obj_split[h].split(">");
								if(itemValue.length>1)
									{
									itemValue = itemValue[1].split("<")[0];
									obj_split[h] = obj_split[h]+" (Окно "+itemValue+")";
									}
								}
							//td1[h].style.fontWeight = "900";
						}
						if (h == 1 || h == 4) {
							td1[h].setAttribute('colSpan', 2);
						}
						
						td1[h].innerHTML = obj_split[h];
						document.getElementById('b-' + r).appendChild(td1[h]);
					}
				if(_instance.permission==2)
					{
					tr[r - 1].style.cursor = "pointer";
					tr[r - 1].setAttribute('data',obj_split[5]);
					tr[r - 1].onclick = function(){
					var idTalon = $(this).attr('id');
					idTalon = '#btd-' + idTalon.split('-')[1] + '-2';
					if(confirm("Вызвать талон "+$(idTalon).text().substr(0,4)+"?"))
						{
						try {dirPult.call($(this).attr('data'));}
						catch(e)
						{
							loadDirectorPult();
							dirPult.call($(this).attr('data'));
						}
						}
					};
					}
				}
			}
			for (var r = line_split.length; r < _instance.tickets_count; r++) {
				$('#b-' + r).remove();
			}
			_instance.tickets_count = line_split.length;
			var wh = $(".card").width()*1;
			wh = wh - ($(".td-button-1").width()*1+$(".td-button-3").width()*1+$(".td-button-4").width()*1);
			if(wh<100) wh=100;
			wh = wh + "px";
			$(".td-button-2").css("width",wh);
			
			for(var i = 1; i < 5; i++)
				{
				var wd = $(".td-button-"+i).width();
				$("#button-table thead th:nth-child("+i+")").width(wd);
				}
			_instance.height('#button-tbody','#card-3');
			if(DisconnectMarker==false)
					_instance.timers[1] = setTimeout(function () {_instance.open_button()}, 5000);
		};

	
	this.height = function (tbody,card)
	{
	var sh = $( window ).height()*1;
	sh = sh-220;
	var lentr = $(tbody+' tr').length;
	if(lentr<4)lentr = 4;
	var tbodyH = $(tbody+' tr:first-child').height()*lentr;
	//console.log(tbodyH);
	if(card == "#card-3" || card == "#card-4")
		tbodyH = tbodyH +(35+2)*2;
	else
		tbodyH = tbodyH +35+2;
	if(tbodyH<sh)
		sh = tbodyH;
	sh = sh+"px"
	var tbsh = sh.replace("px", "")*1;
	if(card == "#card-3" || card == "#card-4")
		tbsh = tbsh -35*2;
	else
		tbsh = tbsh -35;
	
	tbsh = tbsh+"px";
	$(card).css("height",sh);
	$(tbody).css("height",tbsh);
	}
	
	console.log(this.name+" is initializated!");
	this.load();
}