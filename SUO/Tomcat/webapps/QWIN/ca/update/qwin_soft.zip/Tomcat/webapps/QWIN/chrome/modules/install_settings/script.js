var module = new module();

function module()
{
var _instance = this;
this.name = 'install_settings';
this.title = 'Установки';
this.trLen = 0;
this.directors = new Array();
this.stop = function ()
	{
	console.log("stop module "+_instance.name+"...");
	//clearTimeout(_instance.timers[0]);
	};	
this.checkChromeRes = function (txt) //Смотрим хром запускать или нет
	{
	console.log(txt);
	txt = txt.split(":");
	if(txt.length==2 && txt[0]=="chrome")
		{
		chromeVal = txt[1]*1;
		$("#installs-Browser").val(chromeVal);
		$("#installs-Browser").material_select();
		}
	}
this.checkBrowser = function() 
	{
	$.ajax({
	url : "/login/chromeValue.txt",
	type : 'GET',
	success : function (txt) {_instance.checkChromeRes(txt);},
	error : function(txt) {	_instance.checkChromeRes(txt);}
	});	
	}

this.saveBrowser = function() 
	{
	var chromeVal = $("#installs-Browser").val()*1;
	var params = "?val="+chromeVal;
	$.ajax({
		url : "/settings/includes/chromeCheck.jsp"+params,
		type : 'GET',
		success : function (txt) {alert("Браузер сохранен!");},
		error : function(txt) {	alert("Ошибка сохранения браузера!");}
	});
	}

this.checkAdminTouchRes = function (txt) //Выдача талонов администратором
	{
	console.log(txt);
	txt = txt.split(":");
	if(txt.length==2 && txt[0]=="admintouch" && txt[1] == 'false')
		$("#installs-AdminTouch").prop('checked', false);
	else
		$("#installs-AdminTouch").prop('checked', true);
	
	}	
this.checkAdminTouch = function() 
	{
	$.ajax({
	url : "/settings/includes/AdminTouchValue.txt",
	type : 'GET',
	success : function (txt) {_instance.checkAdminTouchRes(txt);},
	error : function(txt) {	_instance.checkAdminTouchRes('admintouch:true');}
	});	
	}

this.saveAdminTouch = function() 
	{
	var AdminTouchVal = $("#installs-AdminTouch").prop('checked');
	console.log(AdminTouchVal);
	var params = "?val="+AdminTouchVal;
	$.ajax({
		url : "/settings/includes/AdminTouchCheck.jsp"+params,
		type : 'GET',
		success : function (txt) {alert("Параметр выдачи талонов администратором сохранен!");},
		error : function(txt) {	alert("Ошибка сохранения параметра выдачи талонов администратором!");}
	});
	}
	
this.checkConnectionRes = function (txt) //Смотрим тип соединения
	{
	$("#installs-connection").val(txt);
	$("#installs-connection").material_select();
	}
this.checkConnection = function() 
	{
	$.ajax({
	url : "/getName",
	type : 'GET',
	dataType: 'json',
	success : function (txt) {console.log(txt);_instance.checkConnectionRes(txt.connectionType);},
	error : function(txt) {	_instance.checkConnectionRes("ip");}
	});	
	}

this.fontUpload = function() 
	{
	$.ajax({
	url : "/ss.font.upload.action",
	type : 'GET',
	success : function (txt) {alert("Загрузка шрифтов проведена!");},
	error : function(txt) {	alert("Загрузка шрифтов проведена!");}
	});	
	}
	
this.saveConnection = function() 
	{
	var connectionVal = $("#installs-connection").val();
	var params = "?set="+connectionVal;
	$.ajax({
		url : "/getName"+params,
		type : 'GET',
		success : function (txt) {alert("Тип соединения сохранено!");},
		error : function(txt) {	alert("Ошибка сохранения типа соединения!");}
	});
	}
	
this.load = function() 
	{

	$.ajax({
		url : "modules/"+_instance.name+"/module.html",
		success : function (txt) {
		$('.container').html(txt);
		
		$('.collapsible').collapsible({ accordion : false });
		_instance.LoadData();
		 
		 _instance.checkBrowser();
		 if($(".user-groups .chip:last").prop('title').search('Администратор ГО') >= 0)
			$("#installs-AdminTouch").change(function(){_instance.saveAdminTouch()});
		else $("#installs-AdminTouch").prop('disabled',true);
		 
		 _instance.checkAdminTouch();
		 _instance.checkConnection();
		 $('#installs-system-save').click(function(){_instance.saveSystem()})
		$('#installs-browser-save').click(function(){_instance.saveBrowser()})
		$('#installs-connection-save').click(function(){_instance.saveConnection()})
		$('#installs-font-upload').click(function(){_instance.fontUpload()})
		
		},
		error : function ($xhr) {console.log($xhr,"err");}
	});

	}

this.isDirector = function (counter) {
	for(var i=0;i<=_instance.directors.length;i++)
		if(_instance.directors[i]==counter)
			return true;
	return false;
	}

this.LoadData = function () {
$.ajax({
	url: "modules/"+_instance.name+"/data.qsp?directors=\"\"",                 
	success: function(json) {
	clearBug();
	json = json.split("<br>");
	json.length--;
	console.log(json);
	json[0] = json[0].split("|");
	$(".badge").text("Версия "+json[0][0]);
	$(".badge").attr("title","Дата обновления:\t"+json[0][1]+"\nДата обновления файлов:\t"+json[0][2]);
	$(".badge").css("right",$(".badge").width());
	$("#installs-counters").val(json[1]*1);
	$("#installs-printers").val(json[2]*1);
	
	json[6] = json[6].substr(1, json[6].length-2);
	for(var i=0;i<json[6].length;i+=2)
		_instance.directors[i/2] =json[6].substr(i,2)*1;
	console.log(_instance.directors);
	for(var i=1;i<=json[1]*1;i++)
		{
		$("#directors-counters-list").append("<option value=\""+i+"\" "+(_instance.isDirector(i)?"selected":"")+">Окно "+i+"</option>");
		}
	 $('#directors-counters-list').material_select();
	var printers = json[3].split("&&");
	printers.length--;
	for(var i=0;i<printers.length;i++)
		{
		printers[i] = printers[i].replace(/ERROR/g, "");
		printers[i] = printers[i].split("|");	
		}
	_instance.createPrinterTable(printers);	
	var displays = json[4].split("&&");
	displays.length--;
	for(var i=0;i<displays.length;i++)
		{
		displays[i] = displays[i].replace(/ERROR/g, "");
		displays[i] = displays[i].split("|");	
		}
	_instance.createDisplaysTable(displays);	
	var schedule = json[5].split("&&");
	schedule.length--;
	for(var i=0;i<schedule.length;i++)
		{
		schedule[i] = schedule[i].substr(1,schedule[i].length-2).split("|");
		for(var j=0;j<schedule[i].length;j++)
			{
			schedule[i][j] = schedule[i][j].split("-");
			
			}
		}
	console.log(schedule);
	_instance.createScheduleTable(schedule);
	},
	error : function ($xhr) {
		console.log($xhr,"err");
		bugAdd();
		
	}
	});
}

this.createElement = function (typeElement,classElement,idElement,parentElement)
	{
	var element;
	if(document.getElementById(idElement) && typeElement!="i")
		element = document.getElementById(idElement);
	else
		{
		element = document.createElement(typeElement);
		if(classElement)
			element.className = classElement;
		if(idElement)
			element.id = idElement;
		parentElement.appendChild(element);	
		}
	return element;
	}


this.saveSystem = function ()
{
var counters = $("#installs-counters").val()*1;
var printers = $("#installs-printers").val()*1;
var directors ="\"<";
var dirTmp = $("#directors-counters-list").val();
for(var i=0;i<dirTmp.length;i++)
	{
	if(dirTmp[i]*1<10)
		directors+="0"+dirTmp[i];
	else
		directors+=dirTmp[i];
	}
directors+=">\"";	
var params = "modules/"+_instance.name+"/data.qsp?save=1&counters="+counters+"&printer="+printers+"&directors="+directors;
console.log(params);
$.ajax({
	url: params, 
	type: "POST",		
	success: function(json) {
	alert("Изменения системных настроек сохранены!");
	//_instance.LoadData();
	
	},
	error: function() {
	console.log("Ошибка сохранения!");		
	
	}
});	

};

this.savePrinter = function (val)
{
val = val.split('-');
var printer = val[3]*1;
console.log(val);
var name = $("#name-installs-printers-"+printer).val();
var ip = $("#ip-installs-printers-"+printer).val();
var params = "modules/"+_instance.name+"/SavePrinters.qsp?printer="+(printer+1)+"&name=\""+name+"\"&ip=\""+ip+"\"";
console.log(params);
$.ajax({
	url: params, 
	type: "POST",		
	success: function(json) {
	alert("Настройки принтера сохранены!");
	//_instance.LoadData();
	
	},
	error: function() {
	console.log("Ошибка сохранения!");		
	
	}
});	

};

this.saveDisplay = function (val)
{
val = val.split('-');
var display = val[3]*1;
console.log(val);
var counters = $("#counters-installs-displays-"+display).val();
var left = $("#left-installs-displays-"+display).val();
var sec = $("#second-installs-displays-"+display).val();
var params = "modules/"+_instance.name+"/SaveDisplays.qsp?display="+(display+1)+"&counters=\""+counters+"\"&left=\""+left+"\"&second="+sec;
console.log(params);
$.ajax({
	url: params, 
	type: "POST",		
	success: function(json) {
	alert("Настройки дисплея сохранены!");
	//_instance.LoadData();
	
	},
	error: function() {
	console.log("Ошибка сохранения!");		
	
	}
});	

};

this.saveSchedule = function (val)
{
val = val.split('-');
console.log(val);
var schedule = "<";
for(var i=2;i<7;i++)
	{
	var plus = "|";
	var fromT = $("#schedule-installs-"+val[3]+"-"+i+"-0").val();
	var toT = $("#schedule-installs-"+val[3]+"-"+i+"-1").val();
	if(i==6) plus="";
	schedule+=fromT+"-"+toT+plus;
	}

schedule +=">"
console.log(schedule);

var params = "modules/"+_instance.name+"/SaveRasp.qsp?rasp="+(val[3]*1+1)+"&data=\""+schedule+"\"";
console.log(params);
$.ajax({
	url: params, 
	type: "POST",		
	success: function(json) {
	alert("Настройки расписания сохранены!");
	//_instance.LoadData();
	
	},
	error: function() {
	console.log("Ошибка сохранения!");		
	
	}
});	

};


this.createValues = function (valuesList)
	{
	var values = new Array("close","add","check","remove");
	//<i class="material-icons">close</i>
	for(var i=0;i<_instance.trLen;i++)
		{
		if(document.getElementById('tr-instPrinters-'+i))
		for(var j=4;j<7;j++)
			{
			
			var instPrintersTD = document.getElementById('td-instPrinters-'+i+'-'+j);
			instPrintersTD.innerHTML = "";
			var curVal = values[valuesList[j-4].charAt(i+1)*1]
			instPrintersInput = _instance.createElement('i',"material-icons rv-"+curVal,'i-instPrinters-'+i+'-'+j,instPrintersTD);
			instPrintersInput.innerHTML = curVal;
			
			}
		}
	}

this.createPrinterTable = function (printerList)
	{

	for(var i=0;i<printerList.length;i++)
		{
		
		var idTR = "tr-installs-printers-"+i;	
		var instPrintersTR = _instance.createElement('tr','table-white',idTR,document.getElementById('installs-printers-tbody'));
		var instPrintersTD = new Array();
		for(var j=0;j<4;j++)
			{
			instPrintersTD[j] = _instance.createElement('td','td-installs-printers-'+(j+1),'td-installs-printers-'+i+'-'+(j+1),instPrintersTR);
			}
		instPrintersTD[0].innerHTML = (i+1);
		var instPrintersName = _instance.createElement('input','installs-input','name-installs-printers-'+i,instPrintersTD[1]);
		instPrintersName.setAttribute("type","text");
		instPrintersName.value = printerList[i][0];
		var instPrintersIP = _instance.createElement('input','installs-input','ip-installs-printers-'+i,instPrintersTD[2]);
		instPrintersIP.setAttribute("type","text");
		instPrintersIP.value = printerList[i][1];
		var instPrintersSave = _instance.createElement('a','waves-effect waves-teal btn-flat','installs-printers-btn-'+i,instPrintersTD[3]);
			instPrintersSave.innerHTML = "Сохранить";
			instPrintersSave.onclick = function () {_instance.savePrinter(this.id)}; 
		}

	};

this.createDisplaysTable = function (displaysList)
	{

	for(var i=0;i<displaysList.length;i++)
		{
		
		var idTR = "tr-installs-displays-"+i;	
		var instDisplaysTR = _instance.createElement('tr','table-white',idTR,document.getElementById('installs-displays-tbody'));
		var instDisplaysTD = new Array();
		for(var j=0;j<5;j++)
			{
			instDisplaysTD[j] = _instance.createElement('td','td-installs-displays-'+(j+1),'td-installs-displays-'+i+'-'+(j+1),instDisplaysTR);
			}
	
		instDisplaysTD[0].innerHTML = (i+1);
		var instDisplaysCounters = _instance.createElement('input','installs-input','counters-installs-displays-'+i,instDisplaysTD[1]);
		instDisplaysCounters.setAttribute("type","text");
		instDisplaysCounters.value = displaysList[i][0];
		var instDisplaysLeft = _instance.createElement('input','installs-input','left-installs-displays-'+i,instDisplaysTD[2]);
		instDisplaysLeft.setAttribute("type","text");
		instDisplaysLeft.value = displaysList[i][1];
		var instDisplaysSecond = _instance.createElement('input','installs-input','second-installs-displays-'+i,instDisplaysTD[3]);
		instDisplaysSecond.setAttribute("type","number");
		instDisplaysSecond.setAttribute("min","0");
		instDisplaysSecond.setAttribute("max","10");
		instDisplaysSecond.value = displaysList[i][2]*1;
		var instDisplaysSave = _instance.createElement('a','waves-effect waves-teal btn-flat','installs-displays-btn-'+i,instDisplaysTD[4]);
			instDisplaysSave.innerHTML = "Сохранить";
			instDisplaysSave.onclick = function () {_instance.saveDisplay(this.id)}; 
		}

	};
	
this.createScheduleTable = function (scheduleList)
	{
	var dw = new Array('Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье');
	for(var i=0;i<scheduleList.length;i++)
		{
		
		var idTR = "tr-installs-schedule-"+i;	
		var instScheduleTR = _instance.createElement('tr','table-white',idTR,document.getElementById('installs-schedule-tbody'));
		var instScheduleTD = new Array();
		var instScheduleInput = new Array();
		instScheduleTD[0] = _instance.createElement('td','td-installs-schedule-1','td-installs-schedule-'+i+'-1',instScheduleTR);
		instScheduleTD[0].innerHTML = dw[i];
		for(var j=1;j<6;j++)
			{
			instScheduleTD[j] = _instance.createElement('td','td-installs-schedule-'+(j+1),'td-installs-schedule-'+i+'-'+(j+1),instScheduleTR);
			instScheduleInput[j] = new Array();
			instScheduleInput[j][0] = _instance.createElement('input','installs-input','schedule-installs-'+i+'-'+(j+1)+'-0',instScheduleTD[j]);
			instScheduleInput[j][0].setAttribute("type","time");
			instScheduleInput[j][0].value = scheduleList[i][j-1][0];
			instScheduleInput[j][1] = _instance.createElement('input','installs-input','schedule-installs-'+i+'-'+(j+1)+'-1',instScheduleTD[j]);
			instScheduleInput[j][1].setAttribute("type","time");
			instScheduleInput[j][1].value = scheduleList[i][j-1][1];
			}
	
		instScheduleTD[6] = _instance.createElement('td','td-installs-schedule-7','td-installs-schedule-'+i+'-7',instScheduleTR);
		var instScheduleSave = _instance.createElement('a','waves-effect waves-teal btn-flat','installs-schedule-btn-'+i,instScheduleTD[6]);
			instScheduleSave.innerHTML = "Сохранить";
			instScheduleSave.onclick = function () {_instance.saveSchedule(this.id)}; 
		}

	};
	
this.load();
}