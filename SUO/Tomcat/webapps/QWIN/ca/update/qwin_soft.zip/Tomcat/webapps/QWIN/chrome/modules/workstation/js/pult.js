﻿var counter = 1; //id окна
var login = 0; //id сотрудника
var nextTimeout; //Идентификатор таймаута кнопки некст
var sumservtime = 0; //сумма времени обслуживания
var nextTimerValue = 30; //таймер вызова сл. клиента
var default_nextTimerValue;//таймер вызова сл. клиента default
var default_MMTimerValue; //время автовызова клиента по-умолчанию
var STANDARD_TIME_OF_SERVICE = 0; //Нормативное время обслуживания
var NullClientTimer; //Идентификатор таймаута повисшиго вызова
var storeTimeout; //повисший вызов
var TRM_Number = 1; //Номер ТРМ
var rezhims = new Array(); //Режимы
var refresh_rezhims_timeout; //Идентификатор таймаута обновленифя режимов
var blink_otlozh_state = 0; //состояние мигания кнопки отложенного вызова
var blink_otlozh_time; //Идентификатор таймаута blink_otlozh
var blinkT; //Идентификатор таймаута blink_function
var serviceTime = 0; //service time
var serviceTimeLimit = 0; //service time limit
var ProgressInx = 0; //Ширина прогрессбара
var Progeress_interval = 1000; //Интервал заполнения прогрессбара
var TT_timeout; //Идентификатор таймаута TransactionTimer
var TTP_timeout; //Идентификатор таймаута TransactionTimeProgress
var ajaxExecutionTimer = null; //Идентификатор таймаута времени выполнения AJAX запроса
var ajaxLongRequestTimer = null; //Идентификатор таймаута времени выполнения AJAX запроса, если больше минуты, то окно закрыть
var priorityLevel=0;
var loginWasAttempted = false;
var perlist; //трм для перевода
var isClose = false;
var markGrayProgress = false; //метка перехода серого прогресса в зеленый
var current_style = "progress_in_grey"; //текущий стиль прогрессбара
var groupletters; //Буквы кнопок
//this code will handle the F5 or Ctrl+F5 key
//need to handle more cases like ctrl+R whose codes are not listed here
var SystemClose = false;

if (!window.console)
	console = {
		log : function () {},
		info : function () {},
		error : function () {},
		warn : function () {}

	}; //Если нет консоли то не обращаем внимание...


$( document ).ready(function() {
 $(document).bind('keydown', 'return', function(){next_click();});  
});
	
function windowClose() {
	console.log("close");
	SystemClose = true;
	window.forceClose = true;
	window.open('/logout.action','_self').close();
}

function displayAjaxLoadingDiv(show) {
	$('#ajaxLoading').css('display', (show === true ? 'block' : 'none'));
}
	
$(document).ajaxStart(function() {
	if (ajaxExecutionTimer === null) {
		ajaxExecutionTimer = window.setTimeout(function() {
			displayAjaxLoadingDiv(true);
			ajaxExecutionTimer = null;
		}, 2 * 1000);
	}
	if ( ajaxLongRequestTimer === null ) {
		ajaxLongRequestTimer = window.setTimeout(function() {
			console.log('Too long to wait response from server. Good bye');
			windowClose();
		}, 60 * 1000);
	}
});

$(document).ajaxComplete(function(e, $xhr) {

	displayAjaxLoadingDiv($xhr.status !== 200 && $xhr.status !== 500 && $xhr.status !== 404);
	
	if (ajaxLongRequestTimer) {
		window.clearTimeout(ajaxLongRequestTimer);
		ajaxLongRequestTimer = null;
	}
	
	if ( $xhr.status === 200 ) {
		clearBug();
		if (ajaxExecutionTimer) {
			window.clearTimeout(ajaxExecutionTimer);
		}
	}
	else if ( ($xhr.status === 503) || ($xhr.status === 12007) || ($xhr.status === 12009) )  {
		window.setTimeout(function() {
			$.get('/login/ping.qsp');
		}, 3 * 1000);
	}
	else if ( $xhr.status === 500 ) {
		bugAddPult();
		
	}
});

window.onbeforeunload = function (evt) { // при обновлении или закрытии пульта
	if (!window.forceClose && !isClose) {
		if ($("#next").html() == "Завершить обслуживание" && SystemClose==false) {
			var message = "Сейчас идет обслуживание клиента. Если вы закроете пульт, то обслуживание прервется.";
			if (typeof evt == "undefined") {
				evt = window.event;
			}
			if (evt) {
				evt.returnValue = message;
			}
			return message;
		}
		else
			{
			opener.workstationLogout();
			}
	}
		
}


function parseGetParam(param) //Чтение параметров из URL
{
	var get_param = 0;
	var url = window.location.search.substring(1).split("&");

	if (url.length > 0) {
		for (var i = 0; i < url.length; i++) {
			var getVar = url[i].split("=");

			if (getVar[0] == param)
				get_param = getVar[1] * 1;
		}
	}

	return get_param;
}


document.onkeydown = checkKeycode
function checkKeycode(e) {
var keycode;
if (window.event)
keycode = window.event.keyCode;
else if (e)
keycode = e.which;
if(keycode == 116)
{
isClose = true;
}
}

//Загрузка страницы
var SyncTry = 0;//Попытки синхронизироваться с базой

function StartLoad(marker) {
	if(marker == undefined || marker == null)
		marker = false;
	if(opener)
		{
		opener.blur();
		window.onunload = function () {if(!isClose){opener.workstationLogout();}};
		}
	console.log(document.cookie);

	counter = parseGetParam('workstation');
	login = parseGetParam('login');
	if(login == 0) login = 1;
	if(counter == 0) counter = 1;
	priorityLevel = parseGetParam('priority');
	
	var tmp = new Date();
	tmp = tmp.getHours() + tmp.getMinutes() + tmp.getSeconds();
	
	document.title = "СУО: Окно " + counter;
	//$('title').html('Пульт СУО - Окно '+counter);
	var oneUrl = "/workstation/includes/one.qsp?workstation=" + counter + "&login=" + login + '&priority=' + priorityLevel+"&tmp="+tmp+((marker==true)?'&NotAjaxReload=1':'');

	if(DisconnectMarker==false)
	$.ajax({
		url : oneUrl,
		type : 'GET',
		success : function (a) {

			a = a.split('||');
			console.log(a);
			a[0] = a[0].split("<br>");
			groupletters = a[13].trim();
			console.log(groupletters);
			var trmName = a[0][2].split("|");
			if(trmName[0]=="0")
				{
				DisconnectPultTRM();	
				}
			else
				{	
				$('#rezhim').html("<p>"+trmName[0]+"</p>");
				var Sotrudnik = a[0][0];
				if(Sotrudnik.length>0 || SyncTry > 4)
					{
					if(SyncTry>4)
						Sotrudnik = "-";	
					$('#sotrudnik').html("<p>"+Sotrudnik+"</p>");
					
					}
				else
					{
					var syncUrl = "/login/sync.jsp";
					SyncTry++;
					$.ajax({url : syncUrl,type : 'GET',success : function (a) {StartLoad()}});
					return 0;
					}
				TRM_Number = a[0][1] * 1;
				serviceTimeLimit = Number(a[10]);
				if ( isNaN(serviceTimeLimit) ) {
					serviceTimeLimit = 15;
				}
				//$('title').html(a[0][2]+' - Окно '+counter);
				STANDARD_TIME_OF_SERVICE = a[7] * 1;
				console.log("STANDARD_TIME_OF_SERVICE", STANDARD_TIME_OF_SERVICE);
				
				if ( a[1].split('<br>')[0].split('|').length >= 3 ) {
					default_MMTimerValue = Number(a[12]);
				}
				
				nextTimerValue = Number(a[9]);
				
				if (isNaN(nextTimerValue)) {
					nextTimerValue = 30;
				}
				
				default_nextTimerValue = nextTimerValue;
				
				if (a[2] != "") {
					//change_state(2);
					change_state(4);
					$('#ticketNumber').html(a[2]);
					$('#display_text').html(a[3]);
					$('#display_text').attr("title", a[3]);
					TransactionTime(a[6] * 1);
				}
				else {
					nextTimerValue = Number(docCookies.getItem('nextTime'));
					
					change_state(1, true);
					
					if (a[8] * 1 > 0) {
						blink_otlozh();
					}
				}
				
				$('#obsluzheno').html(a[4]);
				sumservtime = a[5] * 1;
				
				if (a[4] * 1 > 0)
					$('#srvremobsl').html(secondsToTimeFormat(Math.round((a[5] * 1) / (a[4] * 1))));
				else
					$('#srvremobsl').html(secondsToTimeFormat(0));
		
				
				//perlist = a[11].split("<br>");
				load_rezhims(a[1]);
				
				
				}
		},
		error : function () {
			console.log("/workstation/includes/one.qsp?workstation=" + counter + "&login=" + login);
			

		}
	});
};

function autoCloseLog(event) {
	if(event)
		$.ajax({
			url : "/servletData/autoCloseWorkstation?workstation=" + counter + '&priority=' + priorityLevel + '&event=true',
			type : 'POST'});
	else
		$.ajax({
			url : "/servletData/autoCloseWorkstation?workstation=" + counter + '&priority=' + priorityLevel,
			type : 'POST'});
}


function refresh_rezhims() //Обновление информации на кнопках режимов
{
	var d = new Date(),
		h = d.getHours();
		
	if ( (h <= 7) & (h >= 23) ) {
		console.log('PULT will be closed, cause time violation ', d);
		windowClose();
		return 0;
	}
	
	clearTimeout(refresh_rezhims_timeout);
	
	if(DisconnectMarker==false)
	$.ajax({
		url : "/workstation/includes/get.qsp?workstation=" + counter + '&priority=' + priorityLevel,
		type : 'GET',
		success : function (a) {
			var getStr = a.split('<hr>');
			
			a = getStr[0].split('<br>');
			for (var i = 0; i < a.length; i++) {
				a[i] = a[i].split('||');
				if (rezhims[i] != null) {
					$("#r_" + (i + 1)).html(rezhims[i] + " <span"+((a[i][0]*1 > 0)?" class='notNull'":"")+">" + a[i][0] + "</span><br>" + a[i][1]);
				}
			}
			var state = /(red)|(yellow)|(green)+/.exec(getStr[1]);
			if (state) {
				if (state[0] === 'red') {
					$('#ticketNumber').css('color', '#e53138');
				} else if (state[0] === 'yellow') {
					$('#ticketNumber').css('color', '#ffab00');
				} else {
					$('#ticketNumber').css('color', '#1758ae');
				}
			}
			var Obsl = getStr[2];
			if(Obsl) $('#obsluzheno').text(Obsl);
			refresh_rezhims_timeout = setTimeout(function () {
					refresh_rezhims();
				}, 5000);
			perlist = getStr[3].split("<br>");
			perlist.length--;
			if(getStr.length>=5)
			{
				close_sec = getStr[4]*1;
				//console.log("close_sec=",close_sec);
				if(close_sec==0)
				{
					console.log("close_sec=",close_sec);
					autoCloseLog(false);
				}
			}
		},
		error : function () {
			console.log("refresh_rezhims bad");
			refresh_rezhims_timeout = setTimeout(function () {
					refresh_rezhims();
				}, 5000);
		}
	});
}

function load_rezhims(txt) {
	txt = txt.split('<br>');
	rezhims = txt[0].split('|');
	var j = 0;
	var k = 0;
	
		if(rezhims[0]="0") rezhims[0]="Нормальный режим";
		for (var i=1; i < txt[0].length - 1; i ++) {
			if (rezhims[i] != null) {
				k++;
				$("#r_"+i).attr("title", rezhims[i-1]);
				$("#r_"+i).show();
			}	
		}

	var prec = Math.floor(100 / k);
	for (var i = 1; i <= 3; i++)
		$("#r_" + i).attr("width", prec + "%");
	txt[1] = txt[1] * 1;

	if (txt[1] == 0)
		txt[1] = 1;
	console.log(rezhims);
	for (var i = 1; i <= 3; i++) {
		$("#r_" + i).removeClass("rezhim_activ");
	}
	document.getElementById("r_" + txt[1]).className = "rezhim_activ";
	//$('#rezhim').html(rezhims[txt[1] - 1]);
	refresh_rezhims();
}

function blink_otlozh() //мигание кнопки "вызвать отложенного"
{
	clearTimeout(blink_otlozh_time);
	if (document.getElementById("next").innerHTML != "Завершить обслуживание") {
		if (blink_otlozh_state == 0) {
			$("#call_otlozh").css("background-position", "0px -198px");
			blink_otlozh_state = 1;
		} else {
			$("#call_otlozh").css("background-position", "0px 0px");
			blink_otlozh_state = 0;
		}
		//hover_ie6(document.getElementById('call_otlozh'),blink_otlozh_state);
		blink_otlozh_time = setTimeout(function () {
				blink_otlozh()
			}, 500);
	} else {
		$("#call_otlozh").css("background-position", "0px 0px");
	}
}

function change_state(st, mark) //Смена состояния кнопок, mark - брать таймер из куков
{

	if (st == 1) //Завершено обслуживание
	{
		document.getElementById("display_text").style.paddingTop = "50px";
		document.getElementById("clockbg").style.display = "block";
		document.getElementById("ticketNumber").style.display = "none";
		document.getElementById("next").innerHTML = "Следующий";
		document.getElementById("recall").className = "button_disabled";
		document.getElementById("goto").className = "button_disabled";
		document.getElementById("cassa").className = "button_disabled";
		document.getElementById("cassa_back").className = "button_disabled";
		document.getElementById("otlozh").className = "button_disabled";
		document.getElementById("display_text").style.display = "none";
		document.getElementById("next").className = "button-red";
		document.getElementById("call_otlozh").className = "button";
		if (mark == undefined || mark == null) {
			nextTimerValue = default_nextTimerValue;
		}
		markGrayProgress = true;
		timer_obsl = -10;
		nextTimer();
	}
	if (st == 2) //Клиент вызван
	{
		clearTimeout(nextTimeout);
		clearTimeout(NullClientTimer);
		document.getElementById("next").className = "button-red";
		document.getElementById("clockbg").style.display = "none";
		document.getElementById("display_text").style.display = "block";
		document.getElementById("ticketNumber").style.display = "block";
		document.getElementById("display_text").style.paddingTop = "0px";
		document.getElementById("next").innerHTML = "Завершить обслуживание";
		document.getElementById("call_otlozh").className = "button_disabled";
		document.getElementById("recall").className = "button";
		document.getElementById("goto").className = "button";
		if (TRM_Number != 11) {
			document.getElementById("cassa").className = "button";
			document.getElementById("cassa_back").className = "button";
		}
		document.getElementById("otlozh").className = "button";
	}
	if (st == 3) //Нет клиента (повисший вызов)
	{
		markGrayProgress = true;
		clearTimeout(nextTimeout);
		if (document.getElementById("next").innerHTML != "Завершить обслуживание") {
			document.getElementById("display_text").style.paddingTop = "50px";
			document.getElementById("clockbg").style.display = "none";
			document.getElementById("ticketNumber").style.display = "block";
			document.getElementById("next").className = "button_disabled";
			document.getElementById("next").innerHTML = "Следующий";
			document.getElementById("recall").className = "button_disabled";
			document.getElementById("goto").className = "button_disabled";
			document.getElementById("cassa").className = "button_disabled";
			document.getElementById("call_otlozh").className = "button";
			document.getElementById("cassa_back").className = "button_disabled";
			document.getElementById("otlozh").className = "button_disabled";
			document.getElementById("display_text").style.display = "none";
			docCookies.removeItem('nextTime');
			$('#ticketNumber').html("0");
			storeTimeout = setTimeout(function () {
					console.log("Пробуем вызвать еще раз...");
					next_click("Следующий");
				}, 3000);
		}
	}
	if (st == 4) //Клиент вызван, минимальное время обслуживания
	{
		clearTimeout(nextTimeout);
		clearTimeout(NullClientTimer);
		document.getElementById("next").className = "button_disabled";
		document.getElementById("clockbg").style.display = "none";
		document.getElementById("display_text").style.display = "block";
		document.getElementById("ticketNumber").style.display = "block";
		document.getElementById("display_text").style.paddingTop = "0px";
		document.getElementById("next").innerHTML = "Завершить обслуживание";
		document.getElementById("call_otlozh").className = "button_disabled";
		document.getElementById("cassa").className = "button_disabled";
		document.getElementById("cassa_back").className = "button_disabled";
		document.getElementById("recall").className = "button_disabled";
		document.getElementById("goto").className = "button_disabled";
		document.getElementById("otlozh").className = "button_disabled";
		
		
	}
}

function plusZero(a) //Прибавляем 0 в числах меньше 10
{
	if (a * 1 < 10)
		return "0" + (a * 1);
	else
		return a * 1;
}

function nextTimer(mark) { //Таймер на кнопке "Следующий"
	var defaultTimerValue;
	if(mark == undefined)
		mark = false;
	if ( $('td.rezhim_activ').prop('id').split('_')[1] === '1' ) {
		defaultTimerValue = default_nextTimerValue;
	}
	else {
		defaultTimerValue = default_MMTimerValue;
	}
	if(mark == true)
		defaultTimerValue = 30;
	if ( nextTimerValue > defaultTimerValue) {
		nextTimerValue = defaultTimerValue;
	}
	console.log(nextTimerValue, defaultTimerValue,mark);
	if ( (nextTimerValue > 0) & (nextTimerValue <= defaultTimerValue)) {
		document.getElementById("clock").innerHTML = plusZero(nextTimerValue--);
		docCookies.setItem('nextTime', nextTimerValue, nextTimerValue);
		clearTimeout(nextTimeout);
		nextTimeout = setTimeout("nextTimer("+mark+")", 1000);
	} else {
		console.log("timer event");
		next_click("Следующий");
	}
}

function blink_function(text, b_num) //Мерцание номера талона
{
	clearTimeout(blinkT);
	
	b_num++;
	var space = "";
	var tout = 400;
	if (b_num < 9) {
		if (b_num % 2 == 0) {
			space = text;
			tout = 700;
		} else {
			space = "";
			for (var i = 1; i <= text.length; i++)
				space += "&nbsp;";
		}
		$('#ticketNumber').html(space);
		blinkT = setTimeout(function () {
				blink_function(text, b_num)
			}, tout);
	}
}
function show_block(type) //Показывание сообщение о блокировке
{
	var message = "Ожидается вызов на окне "+type;
	if(type==0)
		message = "Ожидание вызова на другом окне";
	if($('#block-message').length == 0)
		$('body').append('<div id="block-message" class="info-message"><img src="images/info.png"/><span>Блокировка вызова. '+message+'</span></div>');
	else
	{
		$('#block-message').removeClass();
		$('#block-message').addClass('info-message');
		$('#block-message img').attr('src','images/info.png');
		$('#block-message span').text('Блокировка вызова. '+message);
		$('#block-message').show();
	}
}

function next_click(status) //Кнопка "Следующий"
{
	
	if ($("#next").hasClass("button-red") || (storeTimeout != null && status == "Следующий")) {
		console.log('next Click good');
		clearTimeout(nextTimeout);
		clearTimeout(storeTimeout);
		if (status == "Следующий" || (status == null && $("#next").text() == "Следующий")) {

			document.getElementById("clockbg").style.display = "none";
			
			
			if(DisconnectMarker==false)
			$.ajax({
				url : "/workstation/includes/run.qsp?workstation=" + counter + "&action=1" + '&priority=' + priorityLevel + '&login=' + login,
				type : 'GET',
				success : function (a) {
					if(a.indexOf('HAVE_CLIENT') >= 0)
					{
						console.log('У Вас уже есть клиент!');
						StartLoad(true);
					}
					console.log("good_next", "/workstation/includes/run.qsp?workstation=" + counter + "&action=1" + '&priority=' + priorityLevel + '&login=' + login);
					NullClientTimer = setTimeout(function () {
							if ( $('#r_1').hasClass('rezhim_activ') === false ) {
								$('#r_1').click();
								console.log("Никого нет. Переход в основной режим и проверка очереди...");
								next_click('Следующий');
							}
							else {
								
								change_state(3);
								console.log("Никого нет...");
							}
							
						}, 3000);
				},
				error : function () {
					console.log("next");
						
				}
			});
		} else {
			var obsl = $('#obsluzheno').html() * 1;
			if (serviceTime >= 0) //Учитываем обслуженных и суммарное время обслуживание клиентов с временем обсл >= 0 сек
			{
				obsl++;
				var d = new Date();
				var n = d.getDate();

				var arr_v = obsl + "|" + (sumservtime + serviceTime) + "|" + n;
				console.log(sumservtime, serviceTime, arr_v);
				sumservtime = sumservtime + serviceTime;
				if (obsl > 0)
					$('#srvremobsl').html(secondsToTimeFormat(Math.round(sumservtime / obsl)));
				else
					$('#srvremobsl').html(secondsToTimeFormat(0));
			}
			//$('#obsluzheno').html(obsl);

			clear_TransactionTime();
			document.getElementById('progress_clock').innerHTML = "";
			if(DisconnectMarker==false)
				$.ajax({
				url : "/workstation/includes/run.qsp?workstation=" + counter + "&action=2" + '&priority=' + priorityLevel + '&login=' + login + '&ticket=' + $('#ticketNumber').text(),
				type : 'GET',
				success : function (a) {
					console.log("good_end", "/workstation/includes/run.qsp?workstation=" + counter + "&action=2" + '&login=' + login);
				},
				error : function () {
					console.log("end");
					
				}
			});
			change_state(1);
		}
	}
}

function run_recall() //Кнопка "Повторный вызов"
{
	if(DisconnectMarker==false)
	$.ajax({

		url : "/workstation/includes/run.qsp?workstation=" + counter + "&action=3" + '&priority=' + priorityLevel + '&login=' + login + '&ticket=' + $('#ticketNumber').text(),
		type : 'GET',
		success : function (a) {
			blink_function($('#ticketNumber').text(), 1);
		},
		error : function () {
			console.log("bad_recall");
			

		}
	});
}

function otlozhit() //отложить
{
	var obsl = $('#obsluzheno').html() * 1;
	var d = new Date();
	var n = d.getDate();

	var arr_v = obsl + "|" + (sumservtime + serviceTime) + "|" + n;
	console.log(sumservtime, serviceTime, arr_v);
	sumservtime = sumservtime + serviceTime;
	if (obsl > 0)
		$('#srvremobsl').html(secondsToTimeFormat(Math.round(sumservtime / obsl)));
	else
		$('#srvremobsl').html(secondsToTimeFormat(0));
	$('#obsluzheno').html(obsl);

	clear_TransactionTime();
	document.getElementById('progress_clock').innerHTML = "";
	if(DisconnectMarker==false)
	$.ajax({

		url : "/workstation/includes/run.qsp?workstation=" + counter + "&action=7" + '&priority=' + priorityLevel + '&login=' + login + '&ticket=' + $('#ticketNumber').text(),
		type : 'GET',
		success : function (a) {
			console.log("good_otlozh");
		},
		error : function () {
			console.log("bad_otlozh");

		}
	});
	change_state(1);
}

function CallOtlozh(visitinx) //Вызов из отложенных
{
	if(DisconnectMarker==false)
	$.ajax({

		url : "/workstation/includes/run.qsp?workstation=" + counter + "&action=10&value=" + visitinx + '&priority=' + priorityLevel + '&login=' + login,
		type : 'GET',
		success : function (a) {
			//blink_function(a,1);
			console.log("good_call_otlozh");
			document.getElementById('otlozh_list').style.display = 'none';
		},
		error : function () {
			console.log("bad_call_otlozh");

		}
	});

}

function ColorLine(el, a) //подсветка строк в таблице (отложенных,перевода)
{
	if (a == 0) {
		var elid = el.id.split('-')[2] * 1;
		if (elid % 2 == 0)
			el.style.backgroundColor = '#eeeeee';
		else
			el.style.backgroundColor = '#ffffff';
	} else
		el.style.backgroundColor = '#fffaac';

}

function v_kassu(voz) //В кассу/в кассу с возвратом
{

	var obsl = $('#obsluzheno').html() * 1;

	obsl++;
	var d = new Date();
	var n = d.getDate();

	var arr_v = obsl + "|" + (sumservtime + serviceTime) + "|" + n;
	console.log(sumservtime, serviceTime, arr_v);
	sumservtime = sumservtime + serviceTime;
	if (obsl > 0)
		$('#srvremobsl').html(secondsToTimeFormat(Math.round(sumservtime / obsl)));
	else
		$('#srvremobsl').html(secondsToTimeFormat(0));
	
	$('#obsluzheno').html(obsl);

	clear_TransactionTime();
	document.getElementById('progress_clock').innerHTML = "";
	if(DisconnectMarker==false)
	$.ajax({

		url : "/workstation/includes/run.qsp?workstation=" + counter + "&action=" + voz + '&priority=' + priorityLevel + '&login=' + login + '&ticket=' + $('#ticketNumber').text(),
		type : 'GET',
		success : function (a) {
console.log("/workstation/includes/run.qsp?workstation=", counter,"&action=" , voz, "&priority=" , priorityLevel);
			console.log("good_perevod_kassa", voz);
			change_state(1);
		},
		error : function () {
			console.log("bad_perevod_kassa", voz);

		}
	});

}

function perevod_click(el) //перевод в ТРМ
{
	var val = el.id.split('-')[2] * 1;
	var obsl = $('#obsluzheno').html() * 1;
	
	obsl++;
	var d = new Date();
	var n = d.getDate();

	var arr_v = obsl + "|" + (sumservtime + serviceTime) + "|" + n;
	console.log(sumservtime, serviceTime, arr_v);
	sumservtime = sumservtime + serviceTime;
	if (obsl > 0)
		$('#srvremobsl').html(secondsToTimeFormat(Math.round(sumservtime / obsl)));
	else
		$('#srvremobsl').html(secondsToTimeFormat(0));
	
	$('#obsluzheno').html(obsl);

	clear_TransactionTime();
	document.getElementById('progress_clock').innerHTML = "";
	if(DisconnectMarker==false)
	$.ajax({

		url : "/workstation/includes/run.qsp?workstation=" + counter + "&action=4&value=" + val + '&priority=' + priorityLevel + '&login=' + login + '&ticket=' + $('#ticketNumber').text(),
		type : 'GET',
		success : function (a) {
			console.log("good_perevod");
			document.getElementById('perevod_list').style.display = 'none';
			change_state(1);
		},
		error : function () {
			
			console.log("bad_perevod","/workstation/includes/run.qsp?workstation=" + counter + "&action=4&value=" + val + '&priority=' + priorityLevel + '&login=' + login);
		}
	});

}

function LoadPerevod(a) //Загрузка перевода
{
	var table = document.getElementById('perevod_table'),
	dataLine, k = 0;
	
	$("#perevod_table").html("");
	for (var i = 0; i < perlist.length; i++) {
		
		console.log(perlist);
		dataLine = perlist[i].split('|');
		if ( (dataLine[3]*1 === TRM_Number) || (perlist[i].length === 0) ) {
			continue;
		}
		var tr_id = 'perevod-tr-' + dataLine[3];
		var current_tr;
		if (document.getElementById(tr_id))
			current_tr = document.getElementById(tr_id);
		else {
			current_tr = document.createElement('tr');
			current_tr.id = tr_id;
			table.appendChild(current_tr);
		}
		if ((k % 2) === 0) {
			current_tr.style.backgroundColor = '#eeeeee';
		}
		else  {
			current_tr.style.backgroundColor = '#ffffff';
		}
		k++;

		current_tr.onmouseover = function () {
			ColorLine(this, 1)
		};
		current_tr.onmouseout = function () {
			ColorLine(this, 0)
		};
		current_tr.onclick = function () {
			perevod_click(this)
		};
		var body_td;

		var td_id = 'perevod-td-' + (i + 1);
		if (document.getElementById(td_id))
			body_td = document.getElementById(td_id);
		else {
			body_td = document.createElement('td');
			body_td.id = td_id;
			current_tr.appendChild(body_td);
		}
		
		
		if (dataLine.length > 1) {
			if (dataLine[0].length <= 20) {
				body_td.innerHTML = dataLine[0];
			} else {
				body_td.innerHTML = dataLine[1];
			}
		} else {
			body_td.innerHTML = dataLine;
		}
	}
}
function LoadOtlozh(a) //загрузка отложенных
{
	a = a.split("<br>");
	var currtr = document.getElementById("otlozh-tr-1");

	var currtrid = 1;
	while (currtr != null) //Чистим таблицу
	{
		$("#otlozh-tr-" + currtrid).empty();
		currtrid++;
		currtr = document.getElementById("otlozh-tr-" + currtrid);
	}
	var table = document.getElementById('otlozh_table');
	console.log(a);
	if (a[0].length > 3)
		for (var i = 1; i < a.length; i++) {
			a[i - 1] = a[i - 1].split("|")
				var tr_id = 'otlozh-tr-' + i;
			var current_tr;
			if (document.getElementById(tr_id))
				current_tr = document.getElementById(tr_id);
			else {
				current_tr = document.createElement('tr');
				current_tr.id = tr_id;
				table.appendChild(current_tr);
			}
			if (i % 2 == 0)
				current_tr.style.backgroundColor = '#eeeeee';
			else
				current_tr.style.backgroundColor = '#ffffff';
			current_tr.value = a[i - 1][1];
			current_tr.onmouseover = function () {
				ColorLine(this, 1)
			};
			current_tr.onmouseout = function () {
				ColorLine(this, 0)
			};
			current_tr.onclick = function () {
				CallOtlozh(this.value)
			};
			var body_td;

			var td_id = 'otlozh-td-' + i;
			if (document.getElementById(td_id))
				body_td = document.getElementById(td_id);
			else {
				body_td = document.createElement('td');
				body_td.id = td_id;
				current_tr.appendChild(body_td);
			}
			body_td.innerHTML = a[i - 1][0];
		}

}

function button_click(elem) //Нажатие на кнопки
{
	if (elem.className.search('disabled') == -1) {
		if (elem.id == 'recall') //повторный вызов
		{
			run_recall();
		}

		if (elem.id == 'otlozh') //Отложить
		{
			otlozhit();
		}
		if (elem.id == 'goto') //Перевод
		{
			LoadPerevod();
			document.getElementById('perevod_list').style.display = 'block';
		}
		if (elem.id == 'cassa') //В кассу
		{
			v_kassu(5);
		}
		if (elem.id == 'cassa_back') //В кассу с возвратом
		{
			v_kassu(6);
		}
		if (elem.id == 'call_otlozh') //вызов отложенного
		{

			$.ajax({
				url : "/workstation/includes/otlozh.qsp?workstation=" + counter,
				type : 'GET',
				success : function (a) {
					LoadOtlozh(a);
					document.getElementById('otlozh_list').style.display = 'block';
				},
				error : function () {
					console.log("bad call otlozh");

				}
			});
		}

		if (elem.id == 'back_otlozh') //Назад из отложенных
		{
			document.getElementById('otlozh_list').style.display = 'none';
		}
		if (elem.id == 'back_perevod') //Назад из перевода
		{
			document.getElementById('perevod_list').style.display = 'none';
		}
	}
}

function TransactionTime(a) //Запуск времени обслуживания
{

	$("#progress_in").css('width', "9px");
	if (STANDARD_TIME_OF_SERVICE > 0)
		document.getElementById("progress_in").className = "progress_in_grey";
	else
		document.getElementById("progress_in").className = "progress_in";
	$("#progress_in").show();
	$("#progress_clock").show();
	var progressW = $('#progress').width()*1;
	$("#progress_in").css('text-indent',(progressW/2-35)+'px');
	Progeress_interval = (STANDARD_TIME_OF_SERVICE / progressW) * 1000;
	if (a != undefined && a != null) {
		serviceTime = a;
		ProgressInx = Math.round(a / STANDARD_TIME_OF_SERVICE * progressW);
		console.log(progressW,ProgressInx);
	}
	if (STANDARD_TIME_OF_SERVICE > 0)
		TransactionTimeProgress();
	else
		$("#progress_in").css('width', progressW + "px");
	TransactionTimer();
}

function TransactionTimeProgress() //Заполнение прогрессбара
{
	clearTimeout(TTP_timeout);
	
	/*if (ProgressInx >= progressW) {
		document.getElementById("progress_in").className = current_style;
		$("#progress_in").css('width', progressW + "px");
		
		
	} else {
		if (ProgressInx > 9) {
			$("#progress_in").css('width', ((ProgressInx*100)/progressW) + "%");
			
		}
		document.getElementById("progress_in").className = current_style;
*/
	if(!$("#progress_in").hasClass(current_style))
	{
		$("#progress_in").removeAttr('class');
		$("#progress_in").attr('class', '');
		$("#progress_in").addClass(current_style);
		
	}
	if(serviceTime < STANDARD_TIME_OF_SERVICE)
	{
		ProgressInx = (serviceTime * 100)/STANDARD_TIME_OF_SERVICE;
		$("#progress_in").css('width',ProgressInx + '%');

		TTP_timeout = setTimeout(function () {
				//ProgressInx++;
				TransactionTimeProgress();
			}, 1000);
	}
	
		
	
	
}

function TransactionTimer() //Счетчик времени обслуживания
{
	clearTimeout(TT_timeout);
	$('#progress_in').text(secondsToTimeFormat(serviceTime) + "/" + secondsToTimeFormat(STANDARD_TIME_OF_SERVICE));
	$('#progress_clock').text(secondsToTimeFormat(serviceTime) + "/" + secondsToTimeFormat(STANDARD_TIME_OF_SERVICE));

	if (STANDARD_TIME_OF_SERVICE > 0) {
		if (serviceTime < serviceTimeLimit)
			current_style = "progress_in_grey";
		else {
			if (serviceTime < STANDARD_TIME_OF_SERVICE)
				current_style = "progress_in";
			else {
				current_style = "progress_in_red";
				document.getElementById("progress_in").className = current_style;
			}
		}
	} else {
		if (serviceTime < serviceTimeLimit)
			current_style = "progress_in_grey";
		else
			{
			current_style = "progress_in";		
			}
		document.getElementById("progress_in").className = current_style;
	}
	if(serviceTime >= serviceTimeLimit && markGrayProgress == false)
		{
		change_state(2);
		markGrayProgress = true;
		}
	else
		{
		markGrayProgress = false;	
		}


	TT_timeout = setTimeout(function () {
			serviceTime++;
			TransactionTimer();
		}, 1000);
}

function secondsToTimeFormat(sec) //Преобразование секунд в время
{
	var min = Math.floor(sec / 60);
	if (min > 0) {
		sec = sec - min * 60;
	}
	sec = checkTime(sec);
	min = checkTime(min);
	return (min + ":" + sec);
}

function checkTime(i) //Дописываем 0 если меньше 10
{
	if (i < 10) {
		i = "0" + i;
	}
	return i;
}

function clear_TransactionTime() //Очистка времени обслуживания
{
	clearTimeout(TT_timeout);
	clearTimeout(TTP_timeout);
	serviceTime = 0;
	ProgressInx = 0;
	document.getElementById('progress_in').innerHTML = "";
	document.getElementById('progress_clock').innerHTML = "";
	document.getElementById("progress_in").style.display = "none";
	document.getElementById("progress_in").style.width = "0px";
}

function response_next(txt) //Ответ от события вызова клиента
{
	clearTimeout(NullClientTimer);
	$('#block-message').hide();
	change_state(4);
	window.focus();
	txt = txt.split('|');
	console.log(txt);
	letter = (txt[0]*1-824)/(-2);
	letter = groupletters.substr(letter-1,1);
	blink_function(letter+txt[1], 1);
	$('#display_text').html(txt[2]);
	$.ajax({
		url : "/servletData/ResponseNext?workstation=" + counter + '&priority=' + priorityLevel + '&ticket=' + (letter+txt[1]),
		type : 'POST'});
	$('#display_text').attr("title", txt[2]);
	TransactionTime();
}

function setrezhim(el) //Смена режима
{

	var inx = el.id.split("_")[1] * 1;
	if(DisconnectMarker==false)
	$.ajax({
		url : "/workstation/includes/run.qsp?workstation=" + counter + "&action=9&value=" + inx + '&priority=' + priorityLevel + '&login=' + login,
		type : 'GET',
		success : function (a) {
			console.log("good_setRezhim");
			for (var i = 1; i <= 3; i++) {
				$("#r_" + i).removeClass("rezhim_activ");
			}
			el.className = "rezhim_activ";
			clearTimeout(NullClientTimer);
			clearTimeout(storeTimeout);
			if($('#ticketNumber').html()=="0")
				{
				storeTimeout = setTimeout(function () {
					console.log("Пробуем вызвать еще раз...");
					next_click("Следующий");
				}, 500);
				}
			//$("#rezhim").html($("#r_" + inx).attr("title"));
			
		},
		error : function () {
			console.log("bad_setRezhim");
			
		}
	});
}

function resize() {
	$('#progress').css('width',$('.info').width()-10);
	var progressW = $('#progress').width()*1;
	$("#progress_in").css('text-indent',(progressW/2-35)+'px');
}