﻿if (!window.console) console = {log: function() {},info: function() {},error: function() {},warn: function() {}}; // Если нет консоли игнорируем console

  $(function(){
$.ajax({
		url: "includes/runString.qsp",                 
		success: function(json) {
		json = json.split("||");
		json.length = json.length-1;
		for(var i=1;i<=json.length;i++)
			{
			$("#runText-"+i).val(json[i-1]);
			}
		console.log(json);		
		}
	});
$( ".button" ).click(function() {
	var strings = {};
	var params = "includes/runStringSave.qsp?";
	for(var i=1;i<6;i++)
	{
		strings["text"+i] = $("#runText-"+i).val();
		if(strings["text"+i]=="")	strings["text"+i] = "0";
		if(i>1)
			params+="&";
		params+="text"+i;
		params+="=\""+encodeURIComponent(strings["text"+i])+"\"";
	}
	console.log(params);
	$.ajax({
		url: params, 
		type: "POST",		
		data: strings,
		success: function(json) {
		alert("Данные сохранены!");		
		
		},
		error: function() {
		alert("Ошибка сохранения!");		
		
		}
	});
});	

});