﻿var DisconnectTimeout;
var DisconnectMarker = false;
var bugNum = 0;

function bugAdd()
{
bugNum++;
if(bugNum>3)
	Disconnect();
}

function bugAddHead()
{
bugNum++;
if(bugNum>3)
	top.mainFrame.Disconnect();
}

function bugAddPult()
{
bugNum++;
console.log("bug",bugNum);
if(bugNum>3)
	DisconnectPult();
}


function clearBug()
{
bugNum =0;
}

function Disconnect()
{
console.log("Disconnect");
if(DisconnectMarker == false)
	{
	console.log("Disconnect 2");
	DisconnectMarker = true;
	$("#login div h4").text("Ошибка соединения");
	$("#login-error").text("Пульт закроется через 5 секунд...");
	$("#login-loading").hide();
	$("#login-error").show();
	$('#login').openModal({
      dismissible: false, // Modal can be dismissed by clicking outside of the modal
      opacity: .5, // Opacity of modal background
      in_duration: 300, // Transition in duration
      out_duration: 200 // Transition out duration
    });
	//$("body").append( "<div id='disconnect' class='disconnect'><img src='/images/disconnect.png'/><br>Ошибка соединения!<br><span id='disconnect-text'>Пульт закроется через 5 секунд...</span></div>" );
	//top.menuFrame.DisconnectJustBlock();
	
	DisconnectTimeout = setTimeout(function(){DisconnectTimer(5);},1000);
	}
}


function DisconnectPult()
{
DisconnectMarker = true;
if($('#disconnect').length <= 0)
	{
	$("body").append( "<div id='disconnect' class='disconnect-pult'><img src='/images/disconnectPult.png'/><br>Ошибка соединения!<br>Пульт закроется через<br><span id='disconnect-text'>5 секунд...</span></div>" );
	
	DisconnectTimeout = setTimeout(function(){DisconnectTimerPult(5);},1000);
	}
}

function DisconnectPultTRM()
{
DisconnectMarker = true;
if($('#disconnect').length <= 0)
	{
	$("body").append( "<div id='disconnect' class='disconnect-pult'><img src='/images/disconnectPult.png'/><br>Ошибка!<br>Не задан ТРМ!<br>Пульт закроется через<br><span id='disconnect-text'>10 секунд...</span></div>" );
	
	DisconnectTimeout = setTimeout(function(){DisconnectTimerPult(10);},1000);
	}
}


function DisconnectJustBlock()
{
DisconnectMarker = true;
console.log("DisconnectJustBlock");	
if($('#disconnect').length <= 0)
	{
	$("body").append( "<div id='disconnect'></div>" );
	}
}
function DisconnectTimer(dtimer)
{
clearTimeout(DisconnectTimeout);

dtimer--;
if(dtimer>0)
	{
	$("#login-error").text("Пульт закроется через "+dtimer+" секунд...");

	}
else
	parent.location.href='/logout.action';
DisconnectTimeout = setTimeout(function(){DisconnectTimer(dtimer);},1000);
}

function DisconnectTimerPult(dtimer)
{
clearTimeout(DisconnectTimeout);

dtimer--;
if(dtimer>0)
	{
	$("#disconnect-text").text(dtimer+" секунд...");
	}
else
	windowClose();
DisconnectTimeout = setTimeout(function(){DisconnectTimerPult(dtimer);},1000);
}