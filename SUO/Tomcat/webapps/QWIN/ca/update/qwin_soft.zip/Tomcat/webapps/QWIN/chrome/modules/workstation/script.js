var module = new module();

function module()
{
var _instance = this;
this.name = 'workstation';
this.title = 'Фронт-линия';
this.workstation = 0;
this.role = 0;
this.notonly = true;
this.stop = function ()
	{
	console.log("stop module "+_instance.name+"...");
	//clearTimeout(_instance.timers[0]);
	};
this.data = function() 
	{
	$.ajax({
		url : "modules/"+_instance.name+"/data.qsp",
		success : function (txt) {
		txt = txt.split("<hr>");
		txt[0] = txt[0].split("<br>");
		txt[1] = txt[1].split("<br>");
		console.log(txt);
		for(var i = 0;i < txt[0].length -1;i++)
			{
			txt[0][i] = txt[0][i].split("|");
			if(txt[0][i][2]*1==1) txt[0][i][1] = txt[0][i][1] + ' (Открыто)';
			$('#worstation-couterList select').append('<option value="'+txt[0][i][0]+'">'+txt[0][i][1]+'</option>');
			}
		for(var i = 0;i < txt[1].length -1;i++)
			{
			txt[1][i] = txt[1][i].split("|");
			if(txt[1][i].length<3) break;
			$('#worstation-roleList select').append('<option value="'+(i+1)+'">'+txt[1][i][0]+'</option>');
			}
		_instance.workstation = docCookies.getItem("suo_workstation");	
		
		if(_instance.workstation>0)
			{
			$( "#worstation-couterList select [value='"+_instance.workstation+"']" ).attr("selected", "selected");
			$( "#workstation-run" ).removeClass("disabled");
			}
		$('select').material_select();
		$( "#workstation-run" ).click(function() {
			if(!$(this).hasClass("disabled"))
				{
				docCookies.setItem("suo_workstation",_instance.workstation);
				var LoginCode = docCookies.getItem("suo_login");	
				console.log(LoginCode);
				if(!LoginCode)
					{
					$(this).addClass("disabled");
					alert("Ошибка открытия пульта!\nОтсутствует логин.\nПожалуйста перезайдите в систему.");
					}
				else
					{

					pultURL = "modules/workstation/pult.html?workstation="+_instance.workstation+"&login="+LoginCode;
					if(_instance.role>0)
						pultURL = pultURL + "&priority="+_instance.role;
					var leftPos = screen.width*1 - 338 - 10;	
					var topPos = Math.round(screen.height/2) - Math.round(571/2);	
					pult = window.open(pultURL, "Пульт", "menubar=no,location=no,titlebar=no,resizable=no,scrollbars=no,status=0,toolbar=0,height=571px,width=338px,left="+leftPos+",top="+topPos);
					}
				open(location, '_self').close();
				}

			});
		$( "#worstation-couterList .initialized" ).change(function() {
			_instance.workstation = $(this).val();
			docCookies.setItem("suo_workstation",_instance.workstation);
			$( "#workstation-run" ).removeClass("disabled");
			});
		$( "#worstation-roleList .initialized" ).change(function() { _instance.role = $(this).val(); });
		if(CurPermissions['counters']==0)
			_instance.notonly = false;
		console.log(CurPermissions,_instance.notonly);
		 $('#countersModal').openModal({
			  dismissible: _instance.notonly, // Modal can be dismissed by clicking outside of the modal
			  opacity: .5, // Opacity of modal background
			  in_duration: 300, // Transition in duration
			  out_duration: 200, // Transition out duration
			  ready: function() {
				  
				  var cmh = $('#countersModal').height();
				  cmh = cmh*1;
				  var cmh2 = 100;
				  cmh = cmh-130;
				  cmh2 = cmh-173;
				  if(cmh<100) cmh = 100;
				  if(cmh2<100) cmh2 = 100;
				  cmh = cmh + 'px';
				  cmh2 = cmh2 + 'px';
				  //console.log(cmh,$('#worstation-couterList div ul'));
				  
				  //$('#worstation-couterList select').material_select();
				  $("<style type='text/css'> #worstation-couterList div ul{ max-height:"+cmh+" !important;} #worstation-roleList div ul{ max-height:"+cmh2+" !important;}</style>").appendTo("head");
				  //$('#worstation-couterList div ul').css('max-height',cmh);
				  }, // Callback for Modal open
			 complete: function() { $("#menu-counters").click(); } // Callback for Modal close
		});
		 	
		},
		error : function ($xhr) {console.log($xhr,"err");}
	});
	}	
this.load = function() 
	{

	$.ajax({
		url : "modules/"+_instance.name+"/module.html",
		success : function (txt) {
		$('.container').html(txt);
		_instance.data();
		
		},
		error : function ($xhr) {console.log($xhr,"err");}
	});

	}

this.load();
}