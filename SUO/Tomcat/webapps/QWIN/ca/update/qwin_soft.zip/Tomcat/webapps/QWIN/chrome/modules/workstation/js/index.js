﻿var workstation = 1;
var login = 1;
var state = 2;
var nextTimerValue = 30;
var StartServ = 0;

function parseGetParam(param){
	var get_param = 1;
	var url = window.location.search.substring(1).split("&");
	if(url.length > 0){
		for(var i = 0; i < url.length; i++){
			var getVar = url[i].split("=");
			if(getVar[0] == "cat" && (getVar[1].substring(0,3) == "%22" || getVar[1].substring(0,1) == "\"")){
				get_param = getVar[1];
			}
			else{
				if(getVar[0] == param)
					get_param = getVar[1] * 1;
			}
		}
	}
	return get_param;
}

//Загрузка данных в элемент
function loadinner(el, data){
	document.getElementById(el).innerHTML = data;
}

function setrezhim(el,a){
	if(el.className!="rezhim_activ"){
		document.getElementById("r_1").className = "";
		document.getElementById("r_2").className = "";
		document.getElementById("r_3").className = "";
		el.className = "rezhim_activ";
		document.getElementById("rezhim").innerHTML = el.title;
		
		if(a==1)
			therun(9,el.id.substr(2,1)*1-1);
	}
}

//Меняем режим (цвет кнопок)
function change_state(st){
	if(st=="1"){
		document.getElementById("display_text").style.paddingTop = "50px";
		document.getElementById("clockbg").style.display = "block";
		document.getElementById("display_num").style.display = "none";
		document.getElementById("next").innerHTML = "Следующий";
		document.getElementById("recall").className = "button_disabled";
		document.getElementById("call_otlozh").className = "button";
		document.getElementById("goto").className = "button_disabled";
		document.getElementById("cassa").className = "button_disabled";
		document.getElementById("cassa_back").className = "button_disabled";
		document.getElementById("otlozh").className = "button_disabled";
		document.getElementById("display_text").style.display = "none";

		nextTimerValue = 30;
		timer_obsl = -10;
		nextTimer();
	}
	else{
		document.getElementById("clockbg").style.display = "none";
		document.getElementById("display_text").style.display = "block";
		document.getElementById("display_num").style.display = "block";
		document.getElementById("display_text").style.paddingTop = "0px";
		document.getElementById("next").innerHTML = "Завершить обслуживание";
		document.getElementById("call_otlozh").className = "button_disabled";
		document.getElementById("recall").className = "button";
		document.getElementById("goto").className = "button";
		document.getElementById("cassa").className = "button";
		document.getElementById("cassa_back").className = "button";
		document.getElementById("otlozh").className = "button";

		nextTimerValue =-10;
	}
}

var STANDARD_TIME_OF_SERVICE = 150; //Нормативное время обслуживания
var serviceTime = 0;//service time
var time_red = 0;
var timer_obsl = 9;

function getStartServTime(ServT)
{
var date = new Date();
var out = DateToSeconds(date)-ServT;
if(out<0)
	out=0;

return out;
}



function one_result(req)
{
req = req.split("||");

loadinner("sotrudnik",req[0]);
if(req[2].length>0)
	{
	loadinner("display_num",req[2]);
	loadinner("display_text",req[3]);
	nextTimerValue=90;
	change_state("2");
	timer_obsl=9;
	}
else
	{
	
	change_state("1");
	}
loadinner("served_customers",req[4]);
if(req[1].length!=11) req[1]="<nor000000>";
var rezh_id = 1;

for(var i=1;i<10;i=i+3)
	{
	var this_rezh = req[1].substr(i,3);

	if(this_rezh=="000")
		document.getElementById('r_'+rezh_id).style.display = "none";
	else
		{
		var title_rezh="Нормальный режим";
		if(this_rezh=="nor")	title_rezh="Нормальный режим";
		if(this_rezh=="sef")	title_rezh="Сейфовые ячейки";
		if(this_rezh=="wes")	title_rezh="WesternUnion";
		if(this_rezh=="kul")	title_rezh="В кассу ЮЛ";
		if(this_rezh=="ctx")	title_rezh="Чеки Tax-Free";
		if(this_rezh=="zpr")	title_rezh="Зарплатные проекты";
		if(this_rezh=="upf")	title_rezh="ЮЛ+ФЛ низ.приоритет";
		if(this_rezh=="sde")	title_rezh="Специалисты депозитария";
		document.getElementById('r_'+rezh_id).setAttribute("title",title_rezh);
		document.getElementById('r_'+rezh_id+'_name').innerHTML = title_rezh;
		}
	rezh_id++;
	}
var srvr = new Date(1,1,1,0,0,req[5]*2);

loadinner("srvremobsl",srvr.getHours() + ":" + checkTime(srvr.getMinutes()) + ":" + checkTime(srvr.getSeconds()));
serviceTime = req[6]*1;
if(serviceTime>0) timer_obsl=10;
StartServ = getStartServTime(serviceTime);
//loadinner("srvremobsl",data.srvremobsl);
calc_progress_interval(STANDARD_TIME_OF_SERVICE);
time_red=secondsToTimeFormat(STANDARD_TIME_OF_SERVICE);
obsl_nextTimer();
vremya_obsluzh();
}
function get_result(req)
{
req = req.split("||");
var rezhim_body = req[0].split("#");
for(var i=1;i<4;i++)
	{
	try {
		rezhim_body[i-1] = rezhim_body[i-1].split('-');
		document.getElementById('r_'+i+'_count').innerHTML = rezhim_body[i-1][0];
		document.getElementById('r_'+i+'_time').innerHTML = rezhim_body[i-1][1];
		}
		catch(e) {
		console.log("Ошибка загрузки данных в режим #"+i);
		}
	}

setrezhim(document.getElementById('r_'+(req[1]*1+1)),0);
}
function update_get()
{
httpRequest("/workstation/includes/get.qsp?workstation="+workstation,  function(req) { get_result(req.responseText) }, null, null, 3000);
setTimeout(function(){update_get()},4000);
}
function start(){
	
	workstation = parseGetParam("workstation");
	login = parseGetParam("login");
	state = parseGetParam("state");
	httpRequest("/workstation/includes/one.qsp?login="+login+"&workstation="+workstation,  function(req) { one_result(req.responseText) }, null, null, 3000);
	update_get();
}
var TimerId = 1;
function nextTimer(thisid){
if(nextTimerValue>=30)
	{
	TimerId = Math.random()*Math.random();
	thisid = TimerId;
	}
	if(thisid == TimerId)
	{
		if(nextTimerValue > 0 && nextTimerValue <= 30){
			document.getElementById("clock").innerHTML=nextTimerValue--;
			setTimeout(function(){nextTimer(thisid)}, 1000);
		}
		else{
		if(nextTimerValue >= 0)
			next_click("Следующий");
		}
	}
}

 //Clock

function DateToSeconds(date)
{
var sec=0;
sec=date.getSeconds()+date.getMinutes()*60+date.getHours()*3600;
return sec;
}
function secondsToTimeFormat(sec){
	var min = Math.floor(sec / 60);
	if(min > 0){
		sec = sec - min * 60;
	}
	sec = checkTime(sec);
	min = checkTime(min);	
	return (min + ":" + sec);
}



function getServTime()
{
var date = new Date();
var out = DateToSeconds(date)-StartServ;
if(out<0)
	out=0;

return out;
}

var vremya_obsluzhId = 0;
function vremya_obsluzh(thisid){
if(thisid==undefined || thisid==null)
	{
	vremya_obsluzhId = Math.random()*Math.random();
	thisid = vremya_obsluzhId;
	}
	if(thisid == vremya_obsluzhId)
		{
		if(serviceTime >= 0){
			//serviceTime++;
			serviceTime = getServTime(); 
			this_time = secondsToTimeFormat(serviceTime);
			document.getElementById('progress_in').innerHTML = this_time + "/" + time_red;
			if(timer_obsl < 200){
				document.getElementById('progress_clock').innerHTML = this_time + "/" + time_red;
			}
			if(serviceTime >= STANDARD_TIME_OF_SERVICE){
				document.getElementById("progress_in").className = "progress_in_red";
				document.getElementById("progress_in").style.width = "300px";
			}
			else
				document.getElementById("progress_in").className = "progress_in";
		}
		setTimeout(function(){vremya_obsluzh(thisid)}, 300);
		}
}

function checkTime(i)
{
if (i<10)
  {
  i="0" + i;
  }
return i;
}
/////////////////////// 
var progress_interval=1000;
function calc_progress_interval(a)
{
var res= (a/291)*1000;
progress_interval=Math.round(res);

}
  var obsl_nextTimerId = 0;
 function obsl_nextTimer(thisid)
 {
if(thisid==undefined || thisid==null)
	{
	obsl_nextTimerId = Math.random()*Math.random();
	thisid = obsl_nextTimerId;
	}
if(obsl_nextTimerId ==thisid)
	{
	 if(timer_obsl==9)
		{
		document.getElementById("progress_in").className="progress_in";
		document.getElementById("progress_in").style.display="block";
		serviceTime=0;
		document.getElementById('progress_clock').style.display="block";
		}
	 if(timer_obsl>=9)
		{
		
		timer_obsl++;
		if(timer_obsl<=300 && serviceTime<STANDARD_TIME_OF_SERVICE)
			{
			var w= timer_obsl+"px";
			document.getElementById("progress_in").style.width=w;
			}
		

		
		
		
		}
	if(timer_obsl<0)
		{
		
		serviceTime=-10;
		document.getElementById('progress_in').innerHTML="";
		document.getElementById('progress_clock').innerHTML="";
		document.getElementById("progress_in").style.display="none";
		document.getElementById("progress_in").style.width="0px";
		}
	setTimeout(function(){obsl_nextTimer(thisid)},progress_interval);
	 }
 }
 
function therun(action,value)
{
console.log("run action:",action,value);
var val = "";
if(value!=undefined && value!=null)
	val = "&value="+value;
console.log("/workstation/includes/run.qsp?action="+action+"&workstation="+workstation+val);
httpRequest("/workstation/includes/run.qsp?action="+action+"&workstation="+workstation+val, null, null, null, 3000);

}
function go_reload(a)
{
var url = "/workstation/pult.html?workstation="+workstation+"&state="+a;

} 


 function next_click(status) //Кнопка "Следующий"
 {
 if(status=="Следующий")
	{
	loadinner("display_num","0");
	therun(1);
	setTimeout(function(){document.getElementById("display_num").style.display = "block";},500)
	}
else
	{
	therun(2);
	}
 }
 
 function recall_click(el) //Кнопка "Повторный вызов"
 {
if(el.className=="button")
	therun(3);
 }

 function kassa_click(el) //Кнопка "В кассу"
 {
if(el.className=="button")
	therun(5);
 }


  function hover_ie6(el,a)
{
if(BrowserDetect.browser =="Explorer" && BrowserDetect.version<6)
	{
	buf = el.className.split("_");
	if(buf[1]!="disabled")
	{
	if(a==1)
		{
		el.className = buf[0];
		el.className=el.className+"_hover";
		}
	if(a==2)
		{
		el.className = buf[0];
		el.className=el.className+"_active";
		}
	if(a==0)
		{
		el.className = buf[0];
		}
	}
	}
}
