var module = new module();

function module()
{
var _instance = this;
this.name = 'statistic';
this.title = 'Статистика';
this.ip = 'elqueue-03'; //elqueue-03
this.port = '8081';
this.stop = function ()
	{
	console.log("stop module "+_instance.name+"...");
	};	
this.getIP = function() 
	{
	$.ajax({
		url : "/getName",
		dataType: 'json',
		success : function (txt) {
		console.log(txt);
		var ip = window.location.host;
		if(txt.ip && txt.ip!=null && txt.ip.length>=7)
			ip = txt.ip;
		 $("#frame").attr("src", "http://"+_instance.ip+":"+_instance.port+"/?IP="+ip);
		 $("#frame").load(function(){
			$("#frame").css('visibility','visible');
			$('#statistic-loading').closeModal();
			$("#frame").css("width","100%");
			var iframeH = $(window).height()*1;
			iframeH = iframeH - $('nav').height()*1; 
			iframeH = iframeH - 23;
			iframeH = iframeH + 'px';
			$("#frame").css("height",iframeH);
			});
		},
		error : function ($xhr) {console.log($xhr,"err");}
	});
	}
this.load = function() 
	{
	$("#frame").css('visibility','hidden');
	$.ajax({
		url : "modules/"+_instance.name+"/module.html",
		success : function (txt) {
		$('.container').html(txt);
		
		
		$('#statistic-loading').openModal({
		  dismissible: false, // Modal can be dismissed by clicking outside of the modal
		  opacity: .5, // Opacity of modal background
		  in_duration: 300, // Transition in duration
		  out_duration: 200 // Transition out duration
		});
		
		_instance.getIP();
		

		},
		error : function ($xhr) {console.log($xhr,"err");}
	});

	}

this.load();
}