if (!window.console) console = {log: function() {},info: function() {},error: function() {},warn: function() {}}; //Если нет конслои то не обращаем внимание...
var LoginName = null; //Имя пользователя
var admin = 0; //InstallAdmin

var UserGroups = new Array();
var network;
var ErrCodeFour = 0;
LoginName; //Подтягиваем имя из AD
var LoginCode = 0; //Логин код
var chromeVal = 0; //Хром или нет
var LogoutTimeout;
var code = 0;
var pswCheck = false;
$( document ).ready(function() {
    $("#code-1").click(function(){code = code+1;setLogon();});
	$("#code-2").click(function(){code = code*3;setLogon();});
	$("#code-3").click(function(){code = code*code;setLogon();});
});

function setLogon()
{
if(code == 282429536481)
{
	$("#login").prop("readOnly", false);
	$("#space-1").show();
	$("#pass").show();
	pswCheck = true;
}
}
function getLogout(res) // Если открыта сессия, закрываем ее
{
$('#roleForm').hide();
$('.ltable').css("height","235px");
$('.rtable').css("height","235px");
$("#loginForm").show();

if( res.search("good")>=0)
	{
	$.ajax({
		url : "/logout.action",
		type : 'GET',	
		success : function (txt) {
			console.log("Сессия закрыта!");	
		},
		error : function ($xhr) {
			console.log($xhr,"err");
			console.log("Ошибка закрытия сессии, повтор через 5 секунд!");
			LogoutTimeout = setTimout("checkLogout()",5000); 
		}
	});	
	}
}

function loadName()
{
$.ajax({
	url : "/getName",
	type : 'GET',
	dataType: 'json',
	success : function (txt) {
		console.log(txt);
		//alert(txt);
		var machine = window.location.host;
		try{machine = txt[txt.connectionType];}catch(e){}
		console.log(machine);
		if(window.location.host.toLowerCase() != machine.toLowerCase())
			document.location.href = "http://"+machine+"/login/index.html";
		else
			getActiveLogin();
	},
	error : function ($xhr) {
		console.log($xhr,"err");
		getActiveLogin();
	}
});	

}

function getActiveLogin()	//Подставляем пользователя AD 
{
checkChrome();
try{network = new ActiveXObject('WScript.Network');}
catch(e){network = null;}
if(network && network!=null)
	{
	LoginName=network.UserName;
	$("#login").val(LoginName);
	$(document).bind('keydown', 'return', tryLogin);
	}
else
	{
	
	$("#button-1").hide();
	if(IEver == false)
	{
		$(".loginform").hide();
		$(".logoutCard").show();
	}
	else
	{
		
	}
	}
}

function open_page(ad) { //Открытие страниц
	
	window.location=ad;
};

function checkLogout()	//Смотрим есть ли открытая сессия
{

$.ajax({
	url : "/touchscreens/ping.qsp",
	type : 'GET',	
	success : function (txt) {
		getLogout(txt);
	},
	error : function(txt) {
		console.log("err",txt);
	}
});	
}

function LoginChrome() //Запуск через хром
{
var psw = "";
if($("#password").val().length>0)
	psw = "&password="+$("#password").val();
if(pswCheck==false || (pswCheck==true && $("#password").val().length>0))
{
	 var WshShell = new ActiveXObject("WScript.Shell");
	 WshShell.Run ("chrome \"http://"+window.location.host+"/chrome/index.html?user="+LoginName+psw+"\"",1);
	 window.open('','_self').close();
	 console.log(LoginName);
}		 
}

function checkChromeRes(txt) //Смотрим хром запускать или нет
{
console.log(txt);
txt = txt.split(":");
if(txt.length==2 && txt[0]=="chrome")
	{
	chromeVal = txt[1]*1;
	}
}

function checkChrome()	//Опрос файла хрома
{
var tmp = new Date();
tmp = tmp.getHours().toString()+tmp.getMinutes().toString()+tmp.getSeconds().toString();
$.ajax({
	url : "/login/chromeValue.txt?tmp="+tmp,
	type : 'GET',
	success : function (txt) {checkChromeRes(txt);},
	error : function(txt) {	checkChromeRes(txt);}
});
}


function tryLogin()	//Нажатие на Вход
{
if(chromeVal == 0)
	{
	if(IEver==true)
	{
		$("#loginForm").hide();
		$('#roleForm').hide();
		$("#loader").show();
		var tmp = new Date();
		tmp = tmp.getHours().toString()+tmp.getMinutes().toString()+tmp.getSeconds().toString();
		var psw = "";
		if($("#password").val().length>0)
			psw = "&password="+$("#password").val();
		if(pswCheck==false || (pswCheck==true && $("#password").val().length>0))
		{
			$.ajax({
				url : "/UserLogin?username="+$("#login").val()+psw+"&tmp="+tmp,
				dataType: 'json',
				contentType: "application/x-www-form-urlencoded;charset=windows-1251",
				success : function (json) {
					console.log(json);
					checkRoles(json['Groups']);
					admin = json['Admin'];
					LoginCode = json['Code'];
				},
				error : function ($xhr) {console.log($xhr,"err"); alert("Ошибка входа! Невозможно войти.");}
			}); 
		}
		else
			alert("Ошибка входа! Введите пароль!");
	}
	else
		alert("Ошибка входа! Ваш браузер устарел, обратитесь к IT-спецциалисту (Код ошибки: 97)");
	}
else
	{
	LoginChrome();	
	
	}
}

function LoginNow()
{
	$("#loginForm").hide();
	$('#roleForm').show();
	$("#loader").hide();
}

function showRole(role)	//Показ нужной кнопки в зависимости от роли
{
	
switch(role)
	{
	case 0: {$('#role-button-1').show();UserGroups[UserGroups.length] = 0; break;}
	case 1: {$('#role-button-2').show();UserGroups[UserGroups.length] = 1; break;}
	case 2: {$('#role-button-3').show();UserGroups[UserGroups.length] = 2; break;}
	case 3: {$('#role-button-4').show();UserGroups[UserGroups.length] = 3; break;}
	case 4: {$('#role-button-5').show();UserGroups[UserGroups.length] = 4; break;}
	case 5: {$('#role-button-6').show();UserGroups[UserGroups.length] = 5; break;}
	}
}

function checkRoles(roles) //Проверка ролей
{
var mark=false;
if(roles!=null)
	{
	for(var i=0;i<roles.length;i++)
		{
		for(var j=0;j<ADGroups.length;j++)
			{
			if(roles[i]['Name'].toLowerCase()==ADGroups[j].toLowerCase())
				{
				mark=true;
				showRole(j);
				}
			}
		}
	}
if(mark==true)
	{

	LoginNow();
	var UserGroupsTxt = "";
	for(var i=0;i<UserGroups.length;i++)
		UserGroupsTxt+=ADGroups[UserGroups[i]]+",";
	UserGroupsTxt = UserGroupsTxt.substr(0, UserGroupsTxt.length-1);
	console.log(UserGroupsTxt);
	var dat = new Date();
	var liveTime = 23*3600+59*60-(dat.getSeconds()+dat.getMinutes()*60+dat.getHours()*3600);
	docCookies.setItem('suoPermissions', UserGroupsTxt, liveTime, "/");
	}
else
	{
	$("#loader").hide();
	$('#roleForm').hide();	
	$("#loginForm").show();
	alert("Ошибка! У Вас нет прав на использование СУО. Обртитесь за помощью к Вашему Системному администратору.");
	}
}

