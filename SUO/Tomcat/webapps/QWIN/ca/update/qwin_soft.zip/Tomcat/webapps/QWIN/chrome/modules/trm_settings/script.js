var module = new module();

function module()
{
var _instance = this;
this.name = 'trm_settings';
this.title = 'Настройки режимов вызова';
this.trLen = 0;
this.trm = 11;
this.selected_button = 0;
this.selected_rezhim = 1;

this.stop = function ()
	{
	console.log("stop module "+_instance.name+"...");
	//clearTimeout(_instance.timers[0]);
	};	
this.load = function() 
	{

	$.ajax({
		url : "modules/"+_instance.name+"/module.html",
		success : function (txt) {
		$('.container').html(txt);
		
		$('.collapsible').collapsible({ accordion : false });
		_instance.LoadData();
		
		
		},
		error : function ($xhr) {console.log($xhr,"err");}
	});

	}

	
this.saveRezhims = function () {
var rezhims = "";
for(var i=1;i<4;i++)
	{
	if($("#rezhim-"+i+"-turn").prop("checked")==true)
		rezhims = rezhims + $("#rezhim-"+i+" input").val()+"|";
	}
rezhims = encodeURI("\""+rezhims+"\"");
var params = "modules/"+_instance.name+"/save_rezhims.qsp?";

	params+="trm="+_instance.trm+"&rezhim="+rezhims;
console.log(params);

$.ajax({
	url: params, 		
	success: function(json) {alert("Режимы сохранены!");},
	error: function() {alert("Ошибка сохранения!");		
	}
});	
}

this.saveGroup = function () {

var group = $('#trm-group-select').val();
console.log(group);
var params = "modules/"+_instance.name+"/save_group.qsp?";
params+="trm="+_instance.trm+"&group="+group;
console.log(params);

$.ajax({
	url: params, 		
	success: function(json) {alert("Группа сохранена!");},
	error: function() {alert("Ошибка сохранения!");		
	}
});	
}


this.LoadTRM = function (trm) {
$.ajax({
	url: "modules/"+_instance.name+"/trm.qsp?trm="+trm,                 
	success: function(json) {
	clearBug();
	json = json.split("<p>");
	json[1] = json[1].split("<br>");
	json[0] = json[0].split('|');
	if(json[0].length>1)
		json[0].length--;
	for(var i=1;i<json[0].length;i++)
		{
		$("#rezhim-"+(i+1)+" input").val(json[0][i]);
		$("#rezhim-"+(i+1)+" label").addClass("active");
		$("#rezhim-"+(i+1)+"-turn").prop("checked","checked");
		$("#rezhim-"+(i+1)+" input").prop("disabled",false);
		}
	for(var i=json[0].length;i<3;i++)
		{
		$("#rezhim-"+(i+1)+" input").val("");
		$("#rezhim-"+(i+1)+" label").removeClass("active");
		$("#rezhim-"+(i+1)+"-turn").prop("checked",false);
		$("#rezhim-"+(i+1)+" input").prop("disabled","disabled");
		}
	$(".rezhim-turn").change(function(){
		var ids = $(this)[0].id.split('-');
		var val = $(this).prop("checked");
		if(val==false)
			{
			$("#rezhim-"+ids[1]+" input").val("");
			$("#rezhim-"+ids[1]+" input").prop("disabled","disabled");
			if(ids[1]*1 == 2 && $("#rezhim-3-turn").prop("checked") == true)
				$("#rezhim-3-turn").click();
			
			}
		else
			$("#rezhim-"+ids[1]+" input").prop("disabled",false);
		console.log(val,ids);
		});
	
	$('#trm-group-select').val(json[2]*1);
	
	$('#trm-group-select').material_select();
	console.log(json);
	_instance.createValues(json[1]);
	//_instance.createTable(json);

	
	},
	error : function ($xhr) {
		console.log($xhr,"err");
		bugAdd();
		
	}
	});
}

this.LoadData = function () {
$.ajax({
	url: "modules/"+_instance.name+"/data.qsp",                 
	success: function(json) {
	clearBug();
	json = json.split("<hr>");
	json[0] = json[0].split("<br>");
	json[1] = json[1].split("<br>");
	json[0].length--;
	json[1].length--;
	json[0].sort();
	console.log(json);
	for(var i=0;i<json[0].length;i++)
		{
		json[0][i] = json[0][i].split("|");	
		if(json[0][i].length == 4)
			{
			if(json[0][i][3]*1<11) 
				{
				json[0][i][0] = json[0][i][0].substr(1,json[0][i][0].length -1);	
				json[0][i][0] = "Роль "+json[0][i][0];
				}
			var sel ="";
			if(json[0][i][3]*1 == 11)
				sel = "selected";
			$("#trm-select").append("<option "+sel+" value='"+json[0][i][3]+"'>"+json[0][i][0]+"</option>");
			}
		}
	$("#trm-select").change(function()
		{ 
		_instance.trm = $(this).val()*1;
		console.log("load TRM ",_instance.trm);
		_instance.LoadTRM(_instance.trm);
		
		});	
	for(var i=0;i<json[1].length;i++)
		{
		json[1][i] = json[1][i].split("|");	
		}
	
	$('#trm-select').material_select();
	trLen = 0;
	_instance.createTable(json[1]);
	$('.dropdown-button').dropdown({
      inDuration: 300,
      outDuration: 225,
      constrain_width: false, // Does not change width of dropdown to that of the activator
      hover: false, // Activate on hover
      gutter: 0, // Spacing from edge
      belowOrigin: true, // Displays dropdown below the button
      alignment: 'left' // Displays dropdown with edge aligned to the left of button
    }
  );
	_instance.LoadTRM(11);
	_instance.trm = 11;
	$("#vr-save-rezhims").click(function(){_instance.saveRezhims();});
	$("#vr-save-trm-group").click(function(){_instance.saveGroup();});
	console.log(json);
	

	
	},
	error : function ($xhr) {
		console.log($xhr,"err");
		bugAdd();
		
	}
	});
}

this.createElement = function (typeElement,classElement,idElement,parentElement)
	{
	var element;
	if(document.getElementById(idElement) && typeElement!="i")
		element = document.getElementById(idElement);
	else
		{
		element = document.createElement(typeElement);
		if(classElement)
			element.className = classElement;
		if(idElement)
			element.id = idElement;
		parentElement.appendChild(element);	
		}
	return element;
	}

this.dropDown = function(id)
{
var ids = id.split('-');
var text = $("#"+id+" i").text();
console.log(ids,text);
$("#rvsettings-states li").removeClass('rv-active');
_instance.selected_button = ids[2]*1;
_instance.selected_rezhim = ids[3]*1-3;
$("#rvsettings-states .rv-text-"+text).addClass('rv-active');
}

this.saveButton = function (val)
{
console.log(val);
var id = "#td-rvsettings-"+_instance.selected_button+"-"+(_instance.selected_rezhim+3)+" i"
$(id).removeClass('rv-close').removeClass('rv-add').removeClass('rv-check').removeClass('rv-remove').addClass('rv-'+val).text(val)
var params = "modules/"+_instance.name+"/save.qsp?";
var outVal = 0;
if(val == "add") 	outVal = 1;
if(val == "check") 	outVal = 2;
if(val == "remove") outVal = 3;
	params+="button="+(_instance.selected_button+1)+"&rezhim="+_instance.selected_rezhim+"&set="+outVal+"&trm="+_instance.trm;
console.log(params);
$.ajax({
	url: params, 
	type: "POST",		
	success: function(json) {
	console.log("Изменения для кнопки №"+(_instance.selected_button+1)+" сохранены!");
	//_instance.LoadData();
	
	},
	error: function() {
	console.log("Ошибка сохранения!");		
	
	}
});	

};

this.createValues = function (valuesList)
	{
	var values = new Array("close","add","check","remove");
	//<i class="material-icons">close</i>
	for(var i=0;i<_instance.trLen;i++)
		{
		if(document.getElementById('tr-rvsettings-'+i))
		for(var j=4;j<7;j++)
			{
			
			var rvsettingsTD = document.getElementById('td-rvsettings-'+i+'-'+j);
			rvsettingsTD.innerHTML = "";
			var curVal = values[valuesList[j-4].charAt(i+1)*1]
			rvsettingsInput = _instance.createElement('i',"material-icons rv-"+curVal,'i-rvsettings-'+i+'-'+j,rvsettingsTD);
			rvsettingsInput.innerHTML = curVal;
			
			}
		}
	}

this.createTable = function (buttonList)
	{

	for(var i=0;i<buttonList.length;i++)
		{
		if(buttonList[i][2]!='-')
			{
			var idTR = "tr-rvsettings-"+i;	
			var rvsettingsTR = _instance.createElement('tr','table-white',idTR,document.getElementById('rvsettings-tbody'));
			var rvsettingsTD = new Array();
			for(var j=0;j<3;j++)
				{
				rvsettingsTD[j] = _instance.createElement('td','td-rvsettings-'+(j+1),'td-rvsettings-'+i+'-'+(j+1),rvsettingsTR);
				rvsettingsTD[j].innerHTML = buttonList[i][j];
				}
			for(var j=3;j<6;j++)
				{
					
				rvsettingsTD[j] = _instance.createElement('td','td-rvsettings-'+(j+1)+' dropdown-button','td-rvsettings-'+i+'-'+(j+1),rvsettingsTR);
				rvsettingsTD[j].setAttribute("data-activates","rvsettings-states");
				rvsettingsTD[j].onclick = function () {_instance.dropDown(this.id)}; 
				}
			
			_instance.trLen++;
			}
		}

	_instance.width();
	};
this.height = function ()
	{
	var sh = $( window ).height()*1;
	sh = sh-220;
	var lentr = $('#rvsettings-tbody tr').length;
	var tbodyH = $('#rvsettings-tbody tr:first-child').height()*lentr;
	//console.log(tbodyH);
	
	var fh = 0;
	tbodyH = tbodyH +fh+73+2;
	if(tbodyH<sh)
		sh = tbodyH;
	sh = sh+"px"
	var tbsh = sh.replace("px", "")*1;
	
	tbsh = tbsh -73-fh;
	
	tbsh = tbsh+"px";
	//$('#rvsettings-buttons').css("height",sh);
	$('#rvsettings-tbody').css("height",tbsh);
	};
	
this.width = function() {
	var wh = $(".container .collapsible-accordion").width()*1-307;
	if(wh<100) wh=100;
	var wr = wh;
	wh = wh + "px";
	wr = wr - 10-5;
	wr = wr + "px";
	var row = 3;
	console.log("wh",wh);
	$(".td-rvsettings-"+row).css("width",wh);
	

	for(var i = 1; i < 7; i++)
		{
		var wd = $(".td-rvsettings-"+i).width();
		$("#rvsettings-table thead th:nth-child("+i+")").width(wd);
	
		}
	_instance.height();
};	

this.load();
}