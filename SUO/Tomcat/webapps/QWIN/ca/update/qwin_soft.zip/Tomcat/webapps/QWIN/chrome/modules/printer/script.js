var module = new module();

function module()
{
var _instance = this;
this.name = 'printer';
this.title = 'Выдача талонов';
this.stop = function ()
	{
	console.log("stop module "+_instance.name+"...");
	//clearTimeout(_instance.timers[0]);
	};	
this.load = function() 
	{

	$.ajax({
		url : "modules/"+_instance.name+"/module.html",
		success : function (txt) {
		$('.container').html(txt);
		
		$('.dropdown-button').dropdown({
			  inDuration: 300,
			  outDuration: 225,
			  constrain_width: true, // Does not change width of dropdown to that of the activator
			  hover: true, // Activate on hover
			  gutter: 0, // Spacing from edge
			  belowOrigin: false, // Displays dropdown below the button
			  alignment: 'left' // Displays dropdown with edge aligned to the left of button
			}
		  );
		  
		var count,
		option,
		def,
		btnFt = $('#btnFastTrack'),
		tsContainer = document.getElementById('tsContainer');
		btnFt.change(function () {setQwinFastTrack($(this).prop('checked')*1);});

		$.get('/admin/includes/counter-list.qsp', function (answer) {
			_instance.parseCounterAnswer(answer, $('#printers'), $('#windows'));
		}).done(function () {
			$('select').material_select();
			window.qwinFastTrackCallback = function (state) {
				if (state == 1) {
					/*btnFt.text('Отключить Приоритет')
					btnFt.toggleClass('pure-button-active', true);
					btnFt.data('state', 0);*/
					//btnFt.prop('checked')
				} else {
					/*btnFt.text('Включить Приоритет');
					btnFt.toggleClass('pure-button-active', false);
					btnFt.data('state', 1);*/
				}
			}
			setQwinFastTrack(0);
			
			tsContainer.src = '/touchscreens/index.qsp?printer=' + $('#printers').val()+"&monitoring=1";
			
			$('#printers').change(function (e) {
				tsContainer.src = '/touchscreens/index.qsp?printer=' + $(this).val()+"&monitoring=1";
				docCookies.setItem('qwin-admin-printer-id', $(this).val());
			});

		});

		},
		error : function ($xhr) {console.log($xhr,"err");}
	});

	}
	
window.setQwinFastTrack = function (state) {
	sessionStorage.setItem('QWIN_FAST_TRACK', state);
	$('#btnFastTrack').prop('checked',state);
	if (window.qwinFastTrackCallback) {
		window.qwinFastTrackCallback.call(this, state);
	}
}

window.getQwinFastTrack = function () {
	return sessionStorage.getItem('QWIN_FAST_TRACK');
}


window.onbeforeunload = function (e) {
	sessionStorage.setItem('QWIN_FAST_TRACK', 0);
}

this.parseCounterAnswer = function (data, $printerList, $windowsList) {
	var dataLine,
	printers,
	windows,
	selectedPrinterId;
	data = data.split('<hr>');
	printers = data[0].split('<br>');
	windows = data[1].split('<br>');

	if (docCookies.hasItem('qwin-admin-printer-id')) {
		selectedPrinterId = docCookies.getItem('qwin-admin-printer-id');
	}
	
	if (printers.length === 0) {
		printers.push('1|Принтер 1');
	}

	for (var i = 0; i < printers.length; i++) {
		dataLine = printers[i].split('|');
		if (dataLine.length === 2) {
			$printerList.append('<option ' + (selectedPrinterId === dataLine[0] ? 'selected' : '') +
				' value="' + dataLine[0] + '">' + dataLine[1] + '</option>');
		}
	}

	for (var i = 0; i < windows.length; i++) {
		dataLine = windows[i].split('|');
		if (dataLine.length === 3) {
			
			$windowsList.append('<li><a class="windows" id="wind-' + dataLine[0] + '">' + dataLine[1] + (dataLine[2] == 1 ? ' - Открыто' : '') + '</a></li>');
		}
	}
	$('.windows').click(function () {
				var printerId,
				windowId;
				printerId = $('#printers > option:selected').val();
				windowId = $(this).attr('id').split('-')[1];
				var opened = false;
				if($(this).text().split('-').length>1)
					opened = true;
				if(opened || confirm($(this).text()+' - закрыто.\nВы уверены что хотите напечатать VIP-талон в это окно?'))
					{
					$.get('/admin/includes/print.qsp', { 'printer' : printerId, 'counter' : windowId});
					setQwinFastTrack(0);
					Materialize.toast('Талон отправлен на печать', 3000,'rounded'); 
					//alert('Талон отправлен на печать');
					}
				});
}
this.load();
}