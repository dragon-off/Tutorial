var module = new module();




function module()
{
	var _instance = this;
	this.name = 'users';
	this.title = 'Информация по сотрудникам';
	this.timers = new Array();
	this.arrayTRM = new Array();//список названий трм
	this.stop = function ()
	{
	console.log("stop module "+_instance.name+"...");
	clearTimeout(_instance.timers[0]);
	};
	
	this.height = function ()
	{
	var sh = $( window ).height()*1;
	sh = sh-220;
	var lentr = $('#users-tbody tr').length;
	var tbodyH = $('#users-tbody tr:first-child').height()*lentr;
	//console.log(tbodyH);
	
	var fh = $( 'tfoot' ).height()*1;
	tbodyH = tbodyH +fh+50+2;
	if(tbodyH<sh)
		sh = tbodyH;
	sh = sh+"px"
	var tbsh = sh.replace("px", "")*1;
	
	tbsh = tbsh -50-fh;
	
	tbsh = tbsh+"px";
	$('.card').css("height",sh);
	$('#users-tbody').css("height",tbsh);
	}
	this.load = function ()
	{
	clearTimeout(_instance.timers[0]);
	
	if($('#users-table').length<=0)
		{
		$.ajax({
			url : "modules/"+_instance.name+"/module.html",
			success : function (txt) {
			$('.container').html(txt);
			_instance.LoadMain();	
			},
			error : function ($xhr) {console.log($xhr,"err");bugAdd();}
		});
		}

	};
this.FindFIO = function (name) //Фамилия и инициалы
{
var fio = name;
if(fio)
		{
		fio = fio.split(" ");
		var fioTmp = "";
		if(fio.length>=3)
			{
			fioTmp = fio[0].charAt(0).toUpperCase() + fio[0].substr(1)+" ";
			for(var i=1;i<fio.length;i++)
				{
				if(fio[i].substr(0, 1).match(/[а-я]/i))
					fioTmp = fioTmp + fio[i].substr(0, 1).toUpperCase()+".";
				else
					fioTmp = fioTmp + fio[i];
			
				}
			}
		else
			{
			for(var i=0;i<fio.length;i++)
				{
				if(i>0)
					fioTmp = fioTmp + " ";
				fioTmp = fioTmp + fio[i].charAt(0).toUpperCase() + fio[i].substr(1);
				}
			}
		fio = fioTmp;
		
				
		}
	else
		fio = name;

return fio;
}
this.findTRM = function (trm) 
{
trm = trm.replace(/^\s+|\s+$/g, '');

for(var i=0;i<_instance.arrayTRM.length;i++)
	{
	if(_instance.arrayTRM[i][0].indexOf(trm)>=0)
		return _instance.arrayTRM[i]; 
	}
}

this.LoadMain = function () {
	
	clearTimeout(_instance.timers[0]);
	if(DisconnectMarker==false)
	$.ajax({
		url : "/usersMonitoring",
		type : 'GET',
		success : function (a) {
			a = a.split("¤");
			if (a.length > 1) 
				{
				clearBug();
				_instance.arrayTRM = a[0].split("&&");
				_instance.arrayTRM.length--;
				for(var i=0;i<_instance.arrayTRM.length;i++)
					_instance.arrayTRM[i] = _instance.arrayTRM[i].split("|");
				_instance.responseUsers(a[1]);
					
				//console.log();
				}
			
				//responseCategorys(a[2]);
			 else
				{
				console.log("error LoadMain", a.length);
				bugAdd();
				}
		},
		error : function ($xhr) {
			if ($xhr.status === 500) {
				bugAdd();
			}

		}
	});
	if(DisconnectMarker==false)
		_instance.timers[0] = setTimeout(function () {_instance.LoadMain()}, 60000);
}
this.plusZero = function (num) //Добавлем ноль в числа меньше 10
{
	var out = "";
	if (num * 1 < 10)
		out = "0" + num;
	else
		out = num;
	return out;
}

this.users_len = 0; //Количество строк в таблице с пользователями
this.timeToInt = function (time)//Время в цифру
	{
	time = time.split(":");
	var out=0;
	out = time[2]*1+time[1]*60+time[0]*3600;
	return out;
	}
this.intToTime = function (txt) //Цифра во время
	{
	var time = new Date(0, 0, 0, 0);
	var out;
	time.setSeconds(txt);
	out = _instance.plusZero(time.getHours()) + ":" + _instance.plusZero(time.getMinutes()) + ":" + _instance.plusZero(time.getSeconds());
	return out;
	}
this.loadResults = function ()	//Результативные показатели
	{
		
	var SumZn = new Array(0,0,0,0,0,0,0,0,0,0,0);
	var SrZn = new Array(0,0,0,0,0,0,0,0,0,0,0);
	for(var i = 4; i < 11; i++)
		{
		for(var j = 1; j < _instance.users_len; j++)
			{
			if(i == 6)
				SumZn[i] += $("#td-"+j+"-"+i).text()*1;
			else
				SumZn[i] += _instance.timeToInt($("#td-"+j+"-"+i).text());
			
			}
		if(_instance.users_len > 1)
			{
			if(i == 6)
				SrZn[i] = Math.round(SumZn[i]/(_instance.users_len-1));
			else
				SrZn[i] = _instance.intToTime(Math.round(SumZn[i]/(_instance.users_len-1)));
			}		
		}

	SumZn[10] = _instance.intToTime(SumZn[10]);
	var Res = new Array();

	Res[0] = "<tr id='res-1'><th style=\"border-left:0px;text-align:right;\">Средние значения:</th><th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th>";
	for(var i = 4; i < 10; i++)
		{
		Res[0] += "<th>"+SrZn[i]+"</th>";
		}
	Res[0] += "<th>&nbsp;</th>";
	$("#users-table tfoot").html("");
	$("#users-table tfoot").append(Res[0]);

	Res[1] = "<tr id='res-2'><th style=\"border-left:0px;text-align:right;\">Всего за период:</th><th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th>";
	for(var i = 4; i < 11; i++)
		{
		if(i == 6)
			{
			
			Res[1] += "<th>"+SumZn[i]+"</th>";
			}
		else
			Res[1] += "<th>&nbsp;</th>";
		}
	$("#users-table tfoot").append(Res[1]);


	}

this.responseUsers = function (txt) //Обработка пользователей
{
	resp = txt;
	var line_split;
	var el_g;
	var system_type = '';
	line_split = resp.split('<br>');
	//console.log(line_split);
	var tr = new Array();
	var schet = 1;
	_instance.users_len = line_split.length;
	for (var r = 1; r < line_split.length; r++) {
	
		obj_split = line_split[r - 1].split('&&');
		if (document.getElementById('user-' + r)) {
			tr[r - 1] = document.getElementById('user-' + r);
			tr[r - 1].className = 'table-white';
			
		} else {
			tr[r - 1] = document.createElement('tr');
			tr[r - 1].className = 'table-white';
		}
		tr[r - 1].id = 'user-' + r;
		document.getElementById('users-tbody').appendChild(tr[r - 1]);

		if (obj_split.length > 1) {
			var td1 = new Array();
		
			for (var h = 0; h <= obj_split.length - 1; h++) {

				if (document.getElementById('td-' + r+'-'+h))
					td1[h] = document.getElementById('td-' + r+'-'+h);
				else
					td1[h] = document.createElement('td');
				td1[h].id = 'td-' + r+'-'+h;
				td1[h].className = 'td-user-' + h;
				td1[h].style.height = '26px';
				schet++;
				if(obj_split[h].indexOf("null")>=0)obj_split[h] = "0";
				switch (h) {
					case 0: {
							var title_man;
							if (document.getElementById("title_man-" + r))
								title_man = document.getElementById("title_man-" + r);
							else
								title_man = document.createElement('p');
							title_man.id = "title_man-" + r;
							title_man.innerHTML = _instance.FindFIO(obj_split[h]);
							title_man.style.height = "18px";
							title_man.style.whiteSpace = "nowrap";
							title_man.style.margin = "0px";
							title_man.style.overflow = "hidden";
							title_man.style.textOverflow = "ellipsis";
							td1[h].setAttribute('vlign', 'center');
							td1[h].appendChild(title_man);
						
							title_man.title = obj_split[h];
							break;
						}
					case 1: {
							var trmName = _instance.findTRM(obj_split[h]);
							if(trmName.length > 1)
							{
								td1[h].innerHTML = trmName[1];
							}
							else
								td1[h].innerHTML = trmName[0];
							td1[h].title = trmName[0];
							break;
						}
					case 2: {
							obj_split[h] = obj_split[h].split(" ");
							if(obj_split[h].length > 1)
								td1[h].innerHTML = obj_split[h][1];
							else
								td1[h].innerHTML = "&nbsp;";
							break;
						}
					case 3: {
							obj_split[h] = obj_split[h].split(" ");
							if(obj_split[h].length > 1)
								td1[h].innerHTML = obj_split[h][1];
							else
								td1[h].innerHTML = "&nbsp;";
							break;
						}
					case 4: {
							td1[h].innerHTML = _instance.intToTime(obj_split[h]*1);
							break;
						}
					case 5: {		
							console.log(obj_split[h].split("||"));
							obj_split[h] = obj_split[h].split("||");
							var pereriv = 0;
							for(var i=0;i<obj_split[h].length;i++)
								{
								pereriv += obj_split[h][i]*1;
								}
							console.log(pereriv);
							obj_split[h] = pereriv;
							td1[h].innerHTML = _instance.intToTime(obj_split[h]*1);
							break;
						}
					case 6: {
							td1[h].innerHTML = obj_split[h]*1;
							break;
						}
					case 7: {
							td1[h].innerHTML = _instance.intToTime(obj_split[h]*1);	
							break;
						}
					case 8: {
							//CloseOpen - vrobsl - pereryv
							var Prostoy = 0;
							Prostoy = obj_split[4]*1 - obj_split[7]*1 - obj_split[5]*1;
							if(Prostoy<0) Prostoy = 0;
							obj_split[h] = Prostoy;
							td1[h].innerHTML = _instance.intToTime(obj_split[h]*1);
							break;
						}
					case 9: {
							if(obj_split[6]*1>0)
								obj_split[h] = _instance.intToTime(Math.round(obj_split[7]/obj_split[6]*1));
							else
								obj_split[h] = _instance.intToTime(0);
							td1[h].innerHTML = obj_split[h];
							break;
						}
					case 10: {
							td1[h].innerHTML = _instance.intToTime(obj_split[h]*1);
							break;
						}
					default: {
							console.log("err");
							break;
						}
					}

				document.getElementById('user-' + r).appendChild(td1[h]);
			}
		}
		
	}
_instance.loadResults();
var wh = $(".card").width()*1-950;
if(wh<100) wh=100;
wh = wh + "px";
console.log(wh);
//$("#counters-table thead th:nth-child(4)").css("width",wh);


$(".td-user-0").css("width",wh);


for(var i = 0; i < 11; i++)
	{
	var wd = $(".td-user-"+i).width();
	$("#users-table thead th:nth-child("+(i+1)+")").width(wd);
	$("#users-table tfoot tr th:nth-child("+(i+1)+")").width(wd);
	}
_instance.height();
}

	

	console.log(this.name+" is initializated!");
	
	this.load();
}